package utils

import "strings"

func IsPath(path string, paths []string) bool {
	for _, safe := range paths {
		if strings.Contains(path, safe) {
			return true
		}
	}

	return false
}
