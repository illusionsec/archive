# Api CNC v1.0



Main features:
- API Support
- Qbot Support
- Mirai Support
- SSH Server Support
- CNC API Manager with username as username and key as password


Notable Features:
- Users can view there ongoing attacks, clear logs, check there own plan
- Admins can add users, delete users, ban users, add apis, add ssh servers, add qbots, add mirais
- remove mirais, remove qbots, remove ssh servers and remove apis
- they can also check every attack running and see how long left there is on them, they can view apis, ssh, qbot and mirais connected

Webserver Features: 
- Users Concurrents
- Method Validation Checking
- Auto Expire
- Banned Check
- Host validation Checking
- Fast Attack Sending (ran on go concurrents)
