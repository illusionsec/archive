package commands

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"
	"webserver/src/database"
	"webserver/src/server/sessions"
)

var Commands = make(map[string]*Command)

type Command struct {
	Name        string
	Description string
	Admin       bool
	Exec        func(sesh *sessions.Session, args []string)
}

func Init() {
	log.Printf("(commands) Loading!")
	Commands["clear"] = &Command{
		Name:        "clear",
		Description: "Clears the terminal",
		Admin:       false,
		Exec:        clear,
	}
	Commands["list"] = &Command{
		Name:        "list",
		Description: "list <ssh / mirai / qbot / apis>",
		Admin:       true,
		Exec:        list,
	}
	Commands["users"] = &Command{
		Name:        "users",
		Description: "user manager",
		Admin:       true,
		Exec:        users,
	}

	Commands["api"] = &Command{
		Name:        "api",
		Description: "api manager",
		Admin:       true,
		Exec:        api,
	}
	Commands["plan"] = &Command{
		Name:        "plan",
		Description: "shows your plan information",
		Admin:       false,
		Exec:        Plan,
	}
	Commands["ongoing"] = &Command{
		Name:        "ongoing",
		Description: "shows your ongoing attacks",
		Admin:       false,
		Exec:        ongoing,
	}
	Commands["help"] = &Command{
		Name:        "help",
		Description: "gets the help menu",
		Admin:       false,
		Exec:        Help,
	}
	Commands["running"] = &Command{
		Name:        "running",
		Description: "gets every running attack..",
		Admin:       true,
		Exec:        AllAttacks,
	}
	Commands["clogs"] = &Command{
		Name:        "clogs",
		Description: "clear all your attack logs!",
		Admin:       false,
		Exec:        ClearLogs,
	}
	Commands["methods"] = &Command{
		Name:        "methods",
		Description: "Shows methods",
		Admin:       false,
		Exec:        ShowMethods,
	}

	Commands["reload"] = &Command{
		Name:        "reload",
		Description: "reload configuration File",
		Admin:       true,
		Exec:        Reload,
	}
	for _, v := range Commands {
		log.Printf("(load/cmd) %s : %s | Admin : %v", v.Name, v.Description, v.Admin)
	}
}

func IsCommand(cmd string) bool {
	_, found := Commands[cmd]
	return found
}

func clear(session *sessions.Session, args []string) {
	render(session, "banners/clear.txt")
}

func render(session *sessions.Session, path string) {
	file, err := os.Open(path)
	if err != nil {
		return
	}

	scanner := bufio.NewScanner(file)
	scanner.Split(bufio.ScanLines)

	for scanner.Scan() {
		maxtime := strconv.Itoa(session.User.MaxTime)
		if strings.Contains(scanner.Text(), "<<100>>") {
			time.Sleep(100 * time.Millisecond)
		}
		if strings.Contains(scanner.Text(), "<<200>>") {
			time.Sleep(200 * time.Millisecond)
		}
		if strings.Contains(scanner.Text(), "<<300>>") {
			time.Sleep(300 * time.Millisecond)
		}
		if strings.Contains(scanner.Text(), "<<400>>") {
			time.Sleep(400 * time.Millisecond)
		}
		if strings.Contains(scanner.Text(), "<<500>>") {
			time.Sleep(500 * time.Millisecond)
		}
		if strings.Contains(scanner.Text(), "<<600>>") {
			time.Sleep(600 * time.Millisecond)
		}

		if strings.Contains(scanner.Text(), "<<700>>") {
			time.Sleep(700 * time.Millisecond)
		}

		if strings.Contains(scanner.Text(), "<<800>>") {
			time.Sleep(800 * time.Millisecond)
		}

		if strings.Contains(scanner.Text(), "<<900>>") {
			time.Sleep(900 * time.Millisecond)
		}

		if strings.Contains(scanner.Text(), "<<1000>>") {
			time.Sleep(1000 * time.Millisecond)
		}
		replacer := strings.NewReplacer(
			"<<username>>", session.User.Username,
			"<<maxtime>>", maxtime,
			"<<conns>>", strconv.Itoa(session.User.Conns),
			"<<running>>", strconv.Itoa(database.GetConcurrents(session.User.Username)),
			"<<100>>", "",
			"<<200>>", "",
			"<<300>>", "",
			"<<400>>", "",
			"<<500>>", "",
			"<<600>>", "",
			"<<700>>", "",
			"<<800>>", "",
			"<<900>>", "",
			"<<1000>>", "",
			"<<clear>>", "\033c",
		)
		lel := replacer.Replace(scanner.Text())
		fmt.Fprintf(session.Conn, "%s\r\n", lel)
	}
}

func Help(session *sessions.Session, args []string) {
	for _, v := range Commands {
		if v.Admin && session.User.Rank != 2 {
			continue
		} else {
			fmt.Fprintf(session.Conn, "%s : %s\r\n", v.Name, v.Description)
		}
	}
}
