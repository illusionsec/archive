package main

import (
	"fmt"
	"log"
    "Martian/core/sql"
    "Martian/core/config"
	"Martian/core/server/ssh"
)

func main() {

	// Prints our banner
	fmt.Printf("%s\r\n",Config.HEADER)

	// Connect will open the connection with SQL
	if err := sql.Connect(); err != nil {
		fmt.Print(" \x1b[0m"); log.Printf("[\x1b[38;5;9mERROR\x1b[0m] %s\r\n", err.Error())
		return
	}

	// Success message for the sql
	fmt.Print(" \x1b[0m"); log.Printf("[\x1b[38;5;10mSUCCESS\x1b[0m] [\x1b[38;5;3mSQL\x1b[0m] authenticated into the database %s\r\n", Config.SQLServer)

	// Initalize will start the server
	if err := ssh.Initalize(); err != nil {
		fmt.Print(" \x1b[0m"); log.Printf("[\x1b[38;5;9mERROR\x1b[0m] %s\r\n", err.Error())
		return
	}

}