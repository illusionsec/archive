package views

import "golang.org/x/crypto/ssh"

func NewInformationPage(channel ssh.Channel, conn *ssh.ServerConn) error {

	return nil
}