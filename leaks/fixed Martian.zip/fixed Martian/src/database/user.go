package database

import (
	"encoding/json"
	"os"
)

type UserConfiguration struct {
	Username string `json:"username"`
	Password string `json:"password"`
	Email    string `json:"email"`
	Verified bool   `json:"verified"`
	Friends  []struct {
		Username     string   `json:"username"`
		BestFriend   bool     `json:"best_friend"`
		Conversation []string `json:"conversation"`
		Nickname     string   `json:"nickname"`
	} `json:"friends"`
	CanAccess []string `json:"can_access"`
	Profile   struct {
		Aboutme           string   `json:"aboutme"`
		Profile           string   `json:"profile"`
		Contact           []string `json:"contact"`
		SecurityQuestions []struct {
			Question         string `json:"question"`
			Answer           string `json:"answer"`
			CapitalSensitive bool   `json:"capital_sensitive"`
		} `json:"security_questions"`
	} `json:"profile"`
}

// FetchUser will get the user via the password from the database
func (J *JsonConfig) FetchUser(user string) (*UserConfiguration, error) {

	// Ranges through all the users fetched
	for _, account := range J.privateUsers {

		// Compares the user
		if account.Username == user {
			return &account, nil // returns value
		}
	}

	// Returns the value
	return nil, nil
}


// Changes the users password
func (J *JsonConfig) ChangePassword(password string, user *UserConfiguration) error {
	user.Password = Hash(password)	// rehashes the system
	return J.UpdateUser(user)		// Updates the database
}

// UpdateUser will complete update the database contains information
func (J *JsonConfig) UpdateUser(user *UserConfiguration) error {
	
	var found bool = false
	// Ranges through the options
	for pos, private := range J.privateUsers {
		if private.Username != user.Username { // Only username
			continue // continues looping
		}

		J.privateUsers[pos] = *user // Updates the user
		found = true
	}

	if !found { // Not found as it inserts into the array
		J.privateUsers = append(J.privateUsers, *user)
	}

	// Converts into the json format
	converted, err := json.MarshalIndent(&J.privateUsers, "", "\t")
	if err != nil {
		return err
	}

	// Writes the structure needed
	return os.WriteFile(J.UserFile, converted, 0)
}


// Makes the user inside the database and returns the structure
func (J *JsonConfig) MakeUser(user, pass, email string) (*UserConfiguration, error) {

	// Creates our base structure inside the database
	var Config *UserConfiguration = &UserConfiguration{
		Username: user,
		Password: Hash(pass),
		Email: email,
		Verified: false,
		Friends: make([]struct{Username string "json:\"username\""; BestFriend bool "json:\"best_friend\""; Conversation []string "json:\"conversation\""; Nickname string "json:\"nickname\""}, 0),
		CanAccess: make([]string, 0),
		Profile: struct{Aboutme string "json:\"aboutme\""; Profile string "json:\"profile\""; Contact []string "json:\"contact\""; SecurityQuestions []struct{Question string "json:\"question\""; Answer string "json:\"answer\""; CapitalSensitive bool "json:\"capital_sensitive\""} "json:\"security_questions\""}{
			Aboutme: "Hey, im new here!",
			Profile: "",
			Contact: make([]string, 0),
			SecurityQuestions: make([]struct{Question string "json:\"question\""; Answer string "json:\"answer\""; CapitalSensitive bool "json:\"capital_sensitive\""}, 0),
		},
	}


	// Updates inside the database
	return Config, J.UpdateUser(Config)
}