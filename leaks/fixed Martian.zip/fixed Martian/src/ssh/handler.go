package ssh

import (
	"Martian/src/views"
	"fmt"
	"log"
	"net"

	"golang.org/x/crypto/ssh"
	//"Martian/src/views"
)

// NewClientOriginDetected will prompt the client through attempts of creating a ssh channe
func NewClientOriginDetected(connection net.Conn) error {

	// NewServerConn starts a new ssh server with connection
	conn, channels, reqs, err := ssh.NewServerConn(connection, ServerConfiguration)
	if err != nil {
		return err
	}

	// Success message for basic handshake accepted
	fmt.Print(" "); log.Printf("Client from %s -> %s accepted with NoAuth",  connection.RemoteAddr().String(), connection.LocalAddr().String())

	go ssh.DiscardRequests(reqs) // Discards any requests

	// Ranges through open channels
	for Chan := range channels {

		// Funnels unwanted requests
		if Chan.ChannelType() != "session" {
			Chan.Reject(ssh.UnknownChannelType, "unknown channel type")
			return nil
		}

		// Accepts the channel for the connection
		Channel, Request, err := Chan.Accept()
		if err != nil {
			return err
		}

		// Handles requests from clients
		go func(in <-chan *ssh.Request) {
			for request := range in { // Ranges through requests
				switch request.Type { 
				case "pty-req", "shell": // Only accepts PTY & SHELL
					request.Reply(true, nil) // Replys with true
					continue
				}
			}
		}(Request)

		views.NewWelcomedConnection(Channel, conn)
	}
	return nil
}