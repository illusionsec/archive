package ssh

import (
	"fmt"
	"log"
	"net"
	"strconv"
)

// ListenForConnections while start the connection watcher
func ListenForConnections() error {


	// Starts the listener on the network interface ensures its done properly
	Network, err := net.Listen(Configuration.Protocol, ":"+strconv.Itoa(Configuration.Listener))
	if err != nil {
		return err
	}

	fmt.Print(" "); log.Printf("\x1b[0m[\x1b[38;5;10mSUCCESS\x1b[0m] \x1b[0m[\x1b[38;5;72mSSH\x1b[0m] SSH connection watcher has been created with the interface as [:%d]\r\n\r\n", Configuration.Listener)

	for {
		// Accepts the incoming connection
		connection, err := Network.Accept()
		if err != nil {
			continue
		}

		// Little notify message to the terminal
		fmt.Print(" "); log.Printf("Client accepted from %s -> %s\r\n", connection.RemoteAddr().String(), connection.LocalAddr().String())

		// Creates SSH Server with connection in a safe environment
		go NewClientOriginDetected(connection)
	}
}