package ssh

import (
	"io/ioutil"

	"golang.org/x/crypto/ssh"
)


type ServerConfig struct {
	Protocol string `json:"protocol"`		// Protocol for the listener
	Listener int    `json:"listener"`		// Listener host for the listener 
	HostKey  string `json:"hostkey"`		// HostKey for the ssh serverConfig
}

var (
	ServerConfiguration *ssh.ServerConfig = nil
	Configuration       *ServerConfig     = nil
)

// CreateConfig will build the ssh configuration
func CreateConfig(Config *ServerConfig) error {

	// Configures the ssh server
	settings := &ssh.ServerConfig{
		MaxAuthTries: 		1,			// Sets 1 maximum number of authentication attempts
		NoClientAuth: 		true,		// Disables the client authentication
	}

	// Reads the configuration file for the HostKey
	HostKeyFile, err := ioutil.ReadFile(Config.HostKey)
	if err != nil {
		return err
	}

	// Parses the HostKeyFile bytes into a signature
	signature, err := ssh.ParsePrivateKey(HostKeyFile)
	if err != nil {
		return err
	}

	settings.AddHostKey(signature) // Adds into the server settings
	ServerConfiguration = settings // Updates the object for the system
	Configuration	    = Config   // Updates the object for the config
	return nil
}