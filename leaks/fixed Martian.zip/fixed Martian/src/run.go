package src

import (
	"Martian/src/ssh"
	"errors"
)

// Run starts the main process of martian
func Run() error {


	if ssh.ServerConfiguration == nil { // Checks if the before system has been executed
		return errors.New("you must run the Startup() function before executing the Run() function")
	}


	// Starts the connection listener
	return ssh.ListenForConnections()
}