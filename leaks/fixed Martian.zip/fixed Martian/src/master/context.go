package master

import (
	"Martian/src/database"
	"fmt"

	"golang.org/x/crypto/ssh"
)

// NewMasterHandler will handle the master as a new master connection
func NewMasterHandler(channel ssh.Channel, conn *ssh.ServerConn, context *database.UserConfiguration) error {


	fmt.Println("HERE")

	return nil
}