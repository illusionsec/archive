package Config


const (
	// Allows for version control of the product
	VERSION string = "v1.0"
)