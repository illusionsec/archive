package ssh

import (
	"errors"
	"fmt"
	"Martian/core/server"
	"net"

	"golang.org/x/crypto/ssh"
)

// NewClientConnectionOrigin will launch the new conn in ssh
func NewClientConnectionOrigin(conn net.Conn, config *ssh.ServerConfig) error {

	// Creates the new connection with the server
	connection, channels, reqs, err := ssh.NewServerConn(conn, config)
	if err != nil {
		return err
	}

	// DiscardRequests the seperate ssh requests
	go ssh.DiscardRequests(reqs)

	// Ranges through all open channels
	for channel := range channels {

		// Only allow channels of session type
		if channel.ChannelType() != "session" {
			channel.Reject(ssh.UnknownChannelType, "unknown channel type")
			return errors.New("unknown channel type")
		}

		// Accepts the current channel as its valid
		NewChannel, requests, err := channel.Accept()
		if err != nil {
			return errors.New(fmt.Sprintf("handshake issue with %s", conn.RemoteAddr().String()))
		}

		// Handles requests from clients
		go func(in <-chan *ssh.Request) {
			for request := range in {
				switch request.Type {
				case "pty-req", "shell":
					request.Reply(true, nil)
					continue
				}
			}
		}(requests)

		
		// Handles the requests from the remote client safely
		return server.HandleNewConnection(NewChannel, *connection)
	}

	return nil
}