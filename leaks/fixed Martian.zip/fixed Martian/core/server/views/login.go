package views

import (
	"time"

	"golang.org/x/crypto/ssh"

	"Martian/core/config"
	"Martian/core/server/util"
)

// LoginRoute will perform the login information
func LoginRoute(channel ssh.Channel, conn ssh.ServerConn) error {


	// Writes the clear ansi escape to the terminal
	if _, err := channel.Write([]byte("\033c\r")); err != nil {
		return err
	}

	cancel := make(chan struct{})
	go util.MarqueeText(channel, "│", "Enter your login information inside the boxes!", Config.ScreenY-1, 10, 89, 50, "│", cancel)

	// Writes our display banner for system information
	channel.Write([]byte("\x1b[38;5;105m┌─ \x1b[38;5;11m\x1b[4mMartian Login\x1b[0m\x1b[38;5;105m ───────────────────────────────────────────────────────────────────── \x1b[38;5;11m\x1b[4m"+time.Now().Format("02/01/2006")+"\x1b[0m\x1b[38;5;105m ─┐\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│                                                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m├────────┬─────────────────────────────────────────────────────────────────────────────────────────┤\r\n"))
	channel.Write([]byte("\x1b[38;5;105m│\x1b[48;5;9m\x1b[38;5;16m  BACK  \x1b[0m\x1b[38;5;105m│                                                                  │\r\n"))
	channel.Write([]byte("\x1b[38;5;105m└────────┴─────────────────────────────────────────────────────────────────────────────────────────┘\033[?25l"))

	for {
		// Listens for the mouse events within the system
		MouseEvent, err := util.MouseEventCallback(channel)
		if err != nil {
			return err
		}

		// Tries to verify if the button was pressed mimics the button position
		button, ok := util.ValidMouseCursor(MouseEvent.X, MouseEvent.Y, map[string][][2]int{
			"BACK":util.Between(Config.ScreenY-1, 2, 10, make([][2]int, 0)),
		})

		// Only accept valud clicks like leftclick or rightclick and checks for button
		if !ok || MouseEvent.Alert != util.LeftClick && MouseEvent.Alert != util.RightClick {
			continue // Continues looping throughout the system
		}

		switch button {
		case "BACK":
			go func() {
				cancel <- struct{}{}	 	// Sends the stop protocol to the client
			}()
			err := MakeNewConnection(channel, &conn)
			return err 	
		}
		
	}
}