package util


const (
	// OFFSET will be removed from the final position
	OFFSET 		int = 32
)


// MouseAlert stores information about the system
type MouseAlert struct {
	Alert		MouseEvent		`json:"alert"`
	X			int				`json:"x"`
	Y			int				`json:"y"`
	String		string	  		`json:"string"`
}


type MouseEvent int

const (
	LeftClick			MouseEvent = 1 // Left click
	ScrollClick			MouseEvent = 2 // Scroll click
	RightClick			MouseEvent = 3 // Right click
	MouseRelease		MouseEvent = 4 // Click release
	ScrollUp			MouseEvent = 5 // Scroll up
	ScrollDown			MouseEvent = 6 // Scroll down
)

// ToString converts into string representation
func (M *MouseEvent) ToString() string {
	switch *M {
	case LeftClick:
		return "#leftclick"
	case ScrollClick:
		return "#scrollclick"
	case RightClick:
		return "#rightclick"
	case MouseRelease:
		return "#mouserelease"
	case ScrollUp:
		return "#scrollup"
	case ScrollDown:
		return "#scrolldown"
	default:
		return "#eof"
	}
}

// ConvertPosition will convert position into int
func ConvertPosition(buf byte) int {
	return int(buf) - OFFSET
}


// ValidMouseCursor ensures the button click is within a button
func ValidMouseCursor(x,y int, position map[string][][2]int) (string, bool) {

	// Ranges through all the different button position
	for ButtonName, ButtonArray := range position {

		// Ranges through within the inside positions
		for _, ButtonPosition := range ButtonArray {

			// Checks within the valid mouse cursor
			if ButtonPosition[0] == y && ButtonPosition[1] == x {
				return ButtonName, true //returns the sys
			}
		}

	}; return "", false
}


// Works all possible positions within the system
func Between(y int, startx, endx int, src [][2]int) [][2]int {

	// Works the size of the button system properly
	for start := startx; start < endx; start++ {
		src = append(src, [2]int{y, start})
	}

	// Returns the source output
	return src
}