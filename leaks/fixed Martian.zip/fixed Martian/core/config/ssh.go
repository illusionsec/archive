package Config


const (

	// ServerPrivateKey stores the servers private key
	ServerPrivateKey = "templates/server.ppk"

	// Default window x
	ScreenX int = 100

	// Default window y
	ScreenY int = 25


	// HomeMenuScreen
	HomeMenuScreen string = "Welcome to Martian Zee an Zee"
)