package Config

const (
	// HEADER will display on the terminal on startup.
	HEADER string = "     __  ______    ____  _____________    _   __ \r\n"+
			 		"    /  |/  /   |  / __ \\/_  __/  _/   |  / | / /\r\n"+
			 		"   / /|_/ / /| | / /_/ / / /  / // /| | /  |/ /  \r\n"+
			 		"  / /  / / ___ |/ _, _/ / / _/ // ___ |/ /|  /   \r\n"+
			 		" /_/  /_/_/  |_/_/ |_| /_/ /___/_/  |_/_/ |_/    \r\n"
)