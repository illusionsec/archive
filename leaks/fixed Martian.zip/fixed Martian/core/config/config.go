package Config


const (

	// SQLServer will store the sql server address
	SQLServer = "localhost:3306"
	// SQLUser will store the sql servers username
	SQLUser   = "root"
	// SQLPassword will store the sql servers password
	SQLPassword = ""
	// SQLName stores the sql server name
	SQLName = "martian"

	// MasterServer will store the master server address on the listener
	MasterServer = ":25565"
)