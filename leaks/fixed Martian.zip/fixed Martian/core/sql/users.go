package sql 


type User struct {
	ClientID	int 	`json:"client_id"`	  // ID
	Username 	string 	`json:"username"` 	  // Username
	Password 	string  `json:"password"`	  // Password
	Email 		string  `json:"email"`	      // Email
}


// SearchUser will return the user fetched from the sql database
func SearchUser(username string) (*User, error) {




	return nil, nil
}