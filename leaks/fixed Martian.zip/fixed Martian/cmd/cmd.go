package main

import (
	"Martian/src"
	"Martian/src/config"
	"Martian/src/database"
	"Martian/src/ssh"

	"log"
)

func main() {

	// Configure Martians information
	var instance *Config.MartianConfig = &Config.MartianConfig{
		SSH: &ssh.ServerConfig{
			Listener: 	7474,
			Protocol: 	"tcp",
			HostKey:    "private.ppk",
		},	
		DB: &database.JsonConfig{
			UserFile: "./templates/user.json",
		},
	}

	// Startup will ensure its safe to start
	if err := src.Startup(instance); err != nil {
		log.Panic(err.Error())
	}


	// Run will start every longterm process
	if err := src.Run(); err != nil {
		log.Panic(err.Error())
	}
}