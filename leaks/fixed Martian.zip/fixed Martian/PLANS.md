# Martian (23/05/2022) [->] present day



## [Features]

- account verification
    *email verification* ~ on account creation they are asked for an email
                         ~ which an email is sent to confirm it is there email

- register
    - allows users to create there own
