#pragma once

#define HTTP_SERVER "103.195.236.140"
#define HTTP_PORT 80

#define TFTP_SERVER "103.195.236.140"
