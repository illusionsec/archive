import time, os
while True:
    screen = os.system("cd;screen -dmS cnc ./cnc")
    time.sleep(10)
