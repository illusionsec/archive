#pragma once

#define HTTP_SERVER "194.87.151.244"
#define HTTP_PORT 80

#define TFTP_SERVER "194.87.151.244"
