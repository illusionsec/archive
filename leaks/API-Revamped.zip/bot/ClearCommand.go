package bot

import (
	"Manager/database"
	"fmt"
	"github.com/bwmarrin/discordgo"
)

func ClearCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	channel, err := s.State.Channel(i.ChannelID)
	if err != nil {
		fmt.Println("Error getting channel: ", err)
		return
	}
	guild, err := s.State.Guild(channel.GuildID)
	if err != nil {
		fmt.Println("Error getting guild: ", err)
		return
	}
	var category *discordgo.Channel
	for _, c := range guild.Channels {
		if c.ID == channel.ParentID {
			category = c
		}
	}
	name := channel.Name
	permissions := channel.PermissionOverwrites
	_, err = s.ChannelDelete(i.ChannelID)
	if database.CheckError(err) {
		return
	}
	newChannel, err := s.GuildChannelCreate(guild.ID, name, channel.Type)
	if database.CheckError(err) {
		return
	}
	for _, permission := range permissions {
		err = s.ChannelPermissionSet(newChannel.ID, permission.ID, permission.Type, permission.Allow, permission.Deny)
		if database.CheckError(err) {
			return
		}
	}
	if category != nil {
		_, err = s.ChannelEditComplex(newChannel.ID, &discordgo.ChannelEdit{
			ParentID: category.ID,
		})
		if database.CheckError(err) {
			return
		}
	}
}
