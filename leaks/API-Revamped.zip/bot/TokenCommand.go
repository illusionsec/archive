package bot

import "github.com/bwmarrin/discordgo"

func TokenCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	// TODO: Implement Token Command
}
