package bot

import (
	"Manager/assets"
	"Manager/database"
	"github.com/bwmarrin/discordgo"
	"strconv"
	"strings"
	"time"
)

func UserCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	switch i.ApplicationCommandData().Options[0].Name {
	case "list", "info", "show":
		if len(i.ApplicationCommandData().Options[0].Options) > 0 {
			user := database.GetUser(i.ApplicationCommandData().Options[0].Options[0].StringValue())
			myAttacks := 0
			for _, attack := range database.Attacks {
				if attack.User == user.Username {
					myAttacks++
				}
			}
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:   "**Username**",
									Value:  "```" + user.Username + "```",
									Inline: false,
								},
								{
									Name:   "**Key**",
									Value:  "```" + user.Key + "```",
									Inline: false,
								},
								{
									Name:   "**Plan**",
									Value:  "```" + user.Plan + "```",
									Inline: false,
								},
								{
									Name:   "**Max Time**",
									Value:  "```" + strconv.Itoa(user.MaxTime) + "```",
									Inline: false,
								},
								{
									Name:   "**Concurrents**",
									Value:  "```" + strconv.Itoa(database.GetActiveConsUser(user.Username)) + " / " + strconv.Itoa(user.Concurrent) + "```",
									Inline: false,
								},
								{
									Name:   "**Expiry**",
									Value:  "```" + user.Expiry + "```",
									Inline: false,
								},
								{
									Name:   "**Attack Count**",
									Value:  "```" + strconv.Itoa(myAttacks) + "```",
									Inline: false,
								},
								{
									Name:   "**Cooldown**",
									Value:  "```" + strconv.Itoa(user.Cooldown) + "```",
									Inline: false,
								},
								{
									Name:   "**Banned**",
									Value:  "```" + strconv.Itoa(user.Banned) + "```",
									Inline: false,
								},
							},
						},
					},
				},
			})
		} else {
			users := ""
			for _, user := range database.Users {
				users += user.Username + "\r\n"
			}
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:   "**Users**",
									Value:  "```\r\n" + users + "```",
									Inline: false,
								},
							},
						},
					},
				},
			})
			err := Bot.UpdateWatchStatus(0, strconv.Itoa(len(database.Users))+" Users")
			database.CheckError(err)
		}
	case "add":
		expiry := time.Now().Add(time.Hour * 24 * time.Duration(i.ApplicationCommandData().Options[0].Options[4].IntValue())).Format("02-01-2006")
		user := assets.User{
			Username:    i.ApplicationCommandData().Options[0].Options[0].StringValue(),
			Key:         database.GenerateKey(),
			Plan:        i.ApplicationCommandData().Options[0].Options[1].StringValue(),
			MaxTime:     int(i.ApplicationCommandData().Options[0].Options[2].IntValue()),
			Concurrent:  int(i.ApplicationCommandData().Options[0].Options[3].IntValue()),
			Expiry:      expiry,
			HasCooldown: false,
			Cooldown:    int(i.ApplicationCommandData().Options[0].Options[5].IntValue()),
			Banned:      0,
			Threads:     int(i.ApplicationCommandData().Options[0].Options[6].IntValue()),
		}
		database.CreateUser(user)
		_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title: "API Manager",
						Color: 5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:   "**User Added**",
								Value:  "```" + user.Username + "```",
								Inline: false,
							},
						},
					},
				},
			},
		})
	case "remove":
		database.RemoveUser(i.ApplicationCommandData().Options[0].Options[0].StringValue())
		_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title: "API Manager",
						Color: 5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:   "**User Removed**",
								Value:  "```" + i.ApplicationCommandData().Options[0].Options[0].StringValue() + "```",
								Inline: false,
							},
						},
					},
				},
			},
		})
	case "ban":
		database.UpdateUser(i.ApplicationCommandData().Options[0].Options[0].StringValue(), "Banned", "1")
		_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title: "API Manager",
						Color: 5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:   "**User Banned**",
								Value:  "```" + i.ApplicationCommandData().Options[0].Options[0].StringValue() + "```",
								Inline: false,
							},
						},
					},
				},
			},
		})
	case "unban":
		if !database.UpdateUser(i.ApplicationCommandData().Options[0].Options[0].StringValue(), "Banned", "0") {
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:  "**Failed to unban User**",
									Value: "```Please check your input.```",
								},
							},
						},
					},
				},
			})
		}
		_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title: "API Manager",
						Color: 5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:   "**User Unbanned**",
								Value:  "```" + i.ApplicationCommandData().Options[0].Options[0].StringValue() + "```",
								Inline: false,
							},
						},
					},
				},
			},
		})
	case "edit":
		switch strings.ToLower(i.ApplicationCommandData().Options[0].Options[1].StringValue()) {
		case "plan", "role":
			if !database.UpdateUser(i.ApplicationCommandData().Options[0].Options[0].StringValue(), "Plan", i.ApplicationCommandData().Options[0].Options[2].StringValue()) {
				_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title: "API Manager",
								Color: 5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:   "**Failed to set Plan**",
										Value:  "```Please check your input.```",
										Inline: false,
									},
								},
							},
						},
					},
				})
				return
			}
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:   "**User's Plan Updated**",
									Value:  "```" + i.ApplicationCommandData().Options[0].Options[1].StringValue() + "=" + i.ApplicationCommandData().Options[0].Options[2].StringValue() + "```",
									Inline: false,
								},
							},
						},
					},
				},
			})
		case "threads", "threadlimit":
			if !database.UpdateUser(i.ApplicationCommandData().Options[0].Options[0].StringValue(), "ThreadLimit", i.ApplicationCommandData().Options[0].Options[2].StringValue()) {
				_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title: "API Manager",
								Color: 5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:  "**Failed to set Thread Limit**",
										Value: "Please check your input.",
									},
								},
							},
						},
					},
				})
				return
			}
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:  "**User's Thread Limit Updated**",
									Value: "```" + i.ApplicationCommandData().Options[0].Options[1].StringValue() + "=" + i.ApplicationCommandData().Options[0].Options[2].StringValue() + "```",
								},
							},
						},
					},
				},
			})
		case "maxtime", "time", "timelimit":
			if !database.UpdateUser(i.ApplicationCommandData().Options[0].Options[0].StringValue(), "MaxTime", i.ApplicationCommandData().Options[0].Options[2].StringValue()) {
				_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title: "API Manager",
								Color: 5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:  "**Failed to set Max Time**",
										Value: "Please check your input.",
									},
								},
							},
						},
					},
				})
				return
			}
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:  "**User's Max Time Updated**",
									Value: "```" + i.ApplicationCommandData().Options[0].Options[1].StringValue() + "=" + i.ApplicationCommandData().Options[0].Options[2].StringValue() + "```",
								},
							},
						},
					},
				},
			})
		case "concurrent", "cons", "maxconcurrent", "maxconcurrents", "maxcons":
			if !database.UpdateUser(i.ApplicationCommandData().Options[0].Options[0].StringValue(), "MaxConcurrents", i.ApplicationCommandData().Options[0].Options[2].StringValue()) {
				_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title: "API Manager",
								Color: 5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:  "**Failed to set Concurrents**",
										Value: "Please check your input.",
									},
								},
							},
						},
					},
				})
				return
			}
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:  "**User's Concurrents Updated**",
									Value: "```" + i.ApplicationCommandData().Options[0].Options[1].StringValue() + "=" + i.ApplicationCommandData().Options[0].Options[2].StringValue() + "```",
								},
							},
						},
					},
				},
			})
		case "key", "password":
			if !database.UpdateUser(i.ApplicationCommandData().Options[0].Options[0].StringValue(), "Key", i.ApplicationCommandData().Options[0].Options[2].StringValue()) {
				_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title: "API Manager",
								Color: 5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:  "**Failed to set Key**",
										Value: "Please check your input.",
									},
								},
							},
						},
					},
				})
				return
			}
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:  "**User's Key Updated**",
									Value: "```" + i.ApplicationCommandData().Options[0].Options[1].StringValue() + "=" + i.ApplicationCommandData().Options[0].Options[2].StringValue() + "```",
								},
							},
						},
					},
				},
			})
		case "expiry", "date", "expire":
			_expr, err := strconv.Atoi(i.ApplicationCommandData().Options[0].Options[2].StringValue())
			if database.CheckError(err) {
				_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title: "API Manager",
								Color: 5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:  "**Failed to set Expiry**",
										Value: "Please check your input.",
									},
								},
							},
						},
					},
				})
			}
			expiry := time.Now().Add(time.Hour * 24 * time.Duration(_expr)).Format("02-01-2006")
			if !database.UpdateUser(i.ApplicationCommandData().Options[0].Options[0].StringValue(), "Expiry", expiry) {
				_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title: "API Manager",
								Color: 5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:  "**Failed to set Expiry**",
										Value: "Please check your input.",
									},
								},
							},
						},
					},
				})
				return
			}
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:  "**User's Expiry Updated**",
									Value: "```" + i.ApplicationCommandData().Options[0].Options[1].StringValue() + "=" + expiry + "```",
								},
							},
						},
					},
				},
			})
		case "cooldown":
			if !database.UpdateUser(i.ApplicationCommandData().Options[0].Options[0].StringValue(), "Cooldown", i.ApplicationCommandData().Options[0].Options[2].StringValue()) {
				_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title: "API Manager",
								Color: 5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:  "**Failed to set Cooldown**",
										Value: "Please check your input.",
									},
								},
							},
						},
					},
				})
				return
			}
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:  "**User's Cooldown Updated**",
									Value: "```" + i.ApplicationCommandData().Options[0].Options[1].StringValue() + "=" + i.ApplicationCommandData().Options[0].Options[2].StringValue() + "```",
								},
							},
						},
					},
				},
			})
		case "username", "name":
			if !database.UpdateUser(i.ApplicationCommandData().Options[0].Options[0].StringValue(), "Username", i.ApplicationCommandData().Options[0].Options[2].StringValue()) {
				_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title: "API Manager",
								Color: 5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:  "**Failed to set Username**",
										Value: "Please check your input.",
									},
								},
							},
						},
					},
				})
				return
			}
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:  "**User's Username Updated**",
									Value: "```" + i.ApplicationCommandData().Options[0].Options[1].StringValue() + "=" + i.ApplicationCommandData().Options[0].Options[2].StringValue() + "```",
								},
							},
						},
					},
				},
			})
		}
	}
}
