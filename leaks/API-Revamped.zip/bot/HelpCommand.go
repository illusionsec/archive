package bot

import (
	"Manager/database"
	"github.com/bwmarrin/discordgo"
)

func HelpCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				{
					Title:       "Help",
					Description: "This is a list of all commands",
					Color:       5763719,
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**Help**",
							Value:  "```Shows this message```",
							Inline: false,
						},
						{
							Name:   "**Attack**",
							Value:  "```Attacks a Target```",
							Inline: false,
						},
						{
							Name:   "**User**",
							Value:  "```Manage users```",
							Inline: false,
						},
						{
							Name:   "**Stop**",
							Value:  "```Stops the bot```",
							Inline: false,
						},
						{
							Name:   "**Restart**",
							Value:  "```Restarts the bot```",
							Inline: false,
						},
						{
							Name:   "**Whitelist**",
							Value:  "```Manages the whitelist```",
							Inline: false,
						},
						{
							Name:   "**Blacklist**",
							Value:  "```Manages the blacklist```",
							Inline: false,
						},
						{
							Name:   "**Clear**",
							Value:  "```Clears the channel```",
							Inline: false,
						},
						{
							Name:   "**Info**",
							Value:  "```Shows info about the API```",
							Inline: false,
						},
						{
							Name:   "**Methods**",
							Value:  "```Shows all available methods```",
							Inline: false,
						},
						{
							Name:   "**Reload**",
							Value:  "```Reloads the Config, Methods, Whitelist and Blacklist```",
							Inline: false,
						},
					},
				},
			},
		},
	})
	database.CheckError(err)
}
