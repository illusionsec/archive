package bot

import (
	"Manager/assets"
	"Manager/database"
	"github.com/bwmarrin/discordgo"
)

func ReloadCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	database.Config = assets.Config{}
	database.Methods.Methods = []assets.Method{}
	database.Users = []assets.User{}
	database.LoadConfig()
	database.LoadMethods()
	database.LoadUsers()
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Content: "Reloading Complete!",
		},
	})
}
