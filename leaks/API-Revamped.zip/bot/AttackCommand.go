package bot

import (
	"Manager/database"
	"github.com/bwmarrin/discordgo"
)

func AttackCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseModal,
		Data: &discordgo.InteractionResponseData{
			CustomID: "attack_screen_" + i.Interaction.Member.User.ID,
			Title:    "Attacking...",
			Components: []discordgo.MessageComponent{
				discordgo.ActionsRow{
					Components: []discordgo.MessageComponent{
						discordgo.TextInput{
							CustomID:    "User",
							Label:       "Username/Key (Both)",
							Placeholder: "e.g Username/Key",
							Style:       discordgo.TextInputShort,
							Required:    true,
							MinLength:   1,
							MaxLength:   50,
						},
					},
				},
				discordgo.ActionsRow{
					Components: []discordgo.MessageComponent{
						discordgo.TextInput{
							CustomID:    "Target",
							Label:       "Target",
							Style:       discordgo.TextInputShort,
							Placeholder: "e.g 70.70.70.75 or http://example.com",
							Required:    true,
							MaxLength:   300,
							MinLength:   4,
						},
					},
				},
				discordgo.ActionsRow{
					Components: []discordgo.MessageComponent{
						discordgo.TextInput{
							CustomID:    "Port",
							Label:       "Port",
							Placeholder: "e.g 80",
							Style:       discordgo.TextInputShort,
							Required:    true,
							MinLength:   1,
							MaxLength:   5,
						},
					},
				},
				discordgo.ActionsRow{
					Components: []discordgo.MessageComponent{
						discordgo.TextInput{
							CustomID:    "Time",
							Label:       "Time",
							Placeholder: "e.g 10",
							Style:       discordgo.TextInputShort,
							Required:    true,
							MinLength:   1,
							MaxLength:   5,
						},
					},
				},
				discordgo.ActionsRow{
					Components: []discordgo.MessageComponent{
						discordgo.TextInput{
							CustomID:    "Method",
							Label:       "Method",
							Placeholder: "e.g UDP, TCP",
							Style:       discordgo.TextInputShort,
							Required:    true,
							MinLength:   1,
							MaxLength:   10,
						},
					},
				},
			},
		},
	})
	if database.CheckError(err) {
		return
	}
}
