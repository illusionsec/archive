package bot

import (
	"Manager/database"
	"github.com/bwmarrin/discordgo"
	"strconv"
)

func InfoCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				{
					Title:       "Info",
					Description: "API Information's",
					Color:       5763719,
					Fields: []*discordgo.MessageEmbedField{
						{

							Name:   "**Version**",
							Value:  "```" + database.Version + "```",
							Inline: false,
						},
						{
							Name:   "**Users Count**",
							Value:  "```" + strconv.Itoa(len(database.Users)) + "```",
							Inline: false,
						},
						{
							Name:   "**Methods Count**",
							Value:  "```" + strconv.Itoa(len(database.Methods.Methods)) + "```",
							Inline: false,
						},
						{
							Name:   "**Attacks Count**",
							Value:  "```" + strconv.Itoa(len(database.Attacks)) + "```",
							Inline: false,
						},
						{
							Name:   "**Servers Count**",
							Value:  "```" + strconv.Itoa(len(database.Servers.Servers)) + "```",
							Inline: false,
						},
						{
							Name:   "**Current Cons**",
							Value:  "```" + strconv.Itoa(database.GetActiveCons()) + "```",
							Inline: false,
						},
						{
							Name:   "**Max Global Cons**",
							Value:  "```" + strconv.Itoa(database.Config.MaxCons) + "```",
							Inline: false,
						},
						{
							Name:   "**Max Global Time**",
							Value:  "```" + strconv.Itoa(database.Config.MaxTime) + "```",
							Inline: false,
						},
						{
							Name:   "**Powersaving**",
							Value:  "```" + strconv.FormatBool(database.Config.Powersaving) + "```",
							Inline: false,
						},
						{
							Name:   "**Debug Mode**",
							Value:  "```" + strconv.FormatBool(database.Config.Debug) + "```",
							Inline: false,
						},
						{
							Name:   "**Qbots**",
							Value:  "```" + strconv.Itoa(len(database.Qbots)) + "```",
							Inline: false,
						},
						{
							Name:  "**Mirais**",
							Value: "```" + strconv.Itoa(len(database.Mirai)) + "```",
						},
						{
							Name:  "**Total Bots**",
							Value: "```" + strconv.Itoa(len(database.Mirai)+len(database.Qbots)) + "```",
						},
						{
							Name:  "**Load**",
							Value: "```" + strconv.FormatFloat(database.GetLoad(), 'f', 2, 64) + "%```",
						},
					},
				},
			},
		},
	})
	database.CheckError(err)
}
