package bot

import (
	"Manager/database"
	"github.com/bwmarrin/discordgo"
)

func WhitelistCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	switch i.ApplicationCommandData().Options[0].Name {
	case "list", "info", "show":
		ips := "\r\n"
		for _, ip := range database.Config.Whitelist {
			ips += ip + "\r\n"
		}
		err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title:       "Whitelist",
						Description: "This is a list of all whitelisted IPs",
						Color:       5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:  "**IPs**",
								Value: "```" + ips + "```",
							},
						},
					},
				},
			},
		})
		if database.CheckError(err) {
			return
		}
	case "add":
		ip := i.ApplicationCommandData().Options[0].Options[0].StringValue()
		for _, ip2 := range database.Config.Whitelist {
			if ip == ip2 {
				err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title:       "Whitelist",
								Description: "IP already whitelisted",
								Color:       5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:  "**IP**",
										Value: "```" + ip + " already whitelisted```",
									},
								},
							},
						},
					},
				})
				if database.CheckError(err) {
					return
				}
				return
			}
		}
		database.Config.Whitelist = append(database.Config.Whitelist, ip)
		database.SaveConfig()
		err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title:       "Whitelist",
						Description: "IP added to whitelist",
						Color:       5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:  "**IP**",
								Value: "```" + ip + " added```",
							},
						},
					},
				},
			},
		})
		if database.CheckError(err) {
			return
		}
	case "remove":
		ip := i.ApplicationCommandData().Options[0].Options[0].StringValue()
		for index, ip2 := range database.Config.Whitelist {
			if ip == ip2 {
				database.Config.Whitelist = append(database.Config.Whitelist[:index], database.Config.Whitelist[index+1:]...)
				break
			}
		}
		database.SaveConfig()
		err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title:       "Whitelist",
						Description: "IP added to whitelist",
						Color:       5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:  "**IP**",
								Value: "```" + ip + " removed```",
							},
						},
					},
				},
			},
		})
		if database.CheckError(err) {
			return
		}
	}
}
