package bot

import (
	"Manager/database"
	"github.com/bwmarrin/discordgo"
)

func MethodsCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	Methods := "\r\n"
	for _, method := range database.Methods.Methods {
		Methods += method.Name + "\r\n"
	}
	err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				{
					Title:       "Methods",
					Description: "This is a list of all methods",
					Color:       5763719,
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**Methods**",
							Value:  "```" + Methods + "```",
							Inline: false,
						},
					},
				},
			},
		},
	})
	database.CheckError(err)
}
