package bot

import (
	"Manager/database"
	"github.com/bwmarrin/discordgo"
	"strconv"
)

var Bot *discordgo.Session
var Commands []*discordgo.ApplicationCommand
var CommandHandlers = map[string]func(s *discordgo.Session, i *discordgo.InteractionCreate){}

func StartBot() {
	RegisterCommands()
	var err error
	Bot, err = discordgo.New("Bot " + database.Config.DiscordBot)
	database.CheckError(err)
	Bot.Identify.Intents = discordgo.IntentsAll
	_, err = Bot.User("@me")
	if database.CheckError(err) {
		return
	}
	err = Bot.Open()
	database.CheckError(err)
	for _, command := range Commands {
		_, err := Bot.ApplicationCommandCreate(Bot.State.User.ID, "", command)
		database.CheckError(err)
	}
	Bot.AddHandler(func(s *discordgo.Session, i *discordgo.InteractionCreate) {
		switch i.Type {
		case discordgo.InteractionApplicationCommand:
			if handler, ok := CommandHandlers[i.ApplicationCommandData().Name]; ok {
				handler(s, i)
			}
		case discordgo.InteractionModalSubmit:
			AttackHandler(s, i)
		}
	})
	err = Bot.UpdateWatchStatus(0, strconv.Itoa(len(database.Users))+" Users")
	database.CheckError(err)
	database.Info("Discord Bot Running")

}

func RegisterCommands() {
	adminPerm := int64(discordgo.PermissionAdministrator)
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:        "help",
		Description: "Shows this message",
	})
	CommandHandlers["help"] = HelpCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:        "info",
		Description: "Shows information about the API Manager",
	})
	CommandHandlers["info"] = InfoCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:                     "stop",
		Description:              "Stops the API Manager",
		DefaultMemberPermissions: &adminPerm,
	})
	CommandHandlers["stop"] = StopCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:                     "restart",
		Description:              "Restarts the API Manager",
		DefaultMemberPermissions: &adminPerm,
	})
	CommandHandlers["restart"] = RestartCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:                     "user",
		Description:              "Manage users",
		DefaultMemberPermissions: &adminPerm,
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Add a user",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "username",
						Description: "The name of the user",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "role",
						Description: "The role of the user",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionInteger,
						Name:        "maxtime",
						Description: "The maximum time the user can use the system",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionInteger,
						Name:        "concurrent",
						Description: "The maximum number of concurrent uses the user can have",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionInteger,
						Name:        "days",
						Description: "The number of days until the user's access expires",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionInteger,
						Name:        "cooldown",
						Description: "The cooldown time for the user (in seconds)",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionInteger,
						Name:        "threads",
						Description: "The number of threads the user uses",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove a user",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "username",
						Description: "The name of the user",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "edit",
				Description: "Edit a user",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "username",
						Description: "The name of the user",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "field",
						Description: "The Field in the database to edit",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "value",
						Description: "The new value for the field",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List all users",
				Required:    false,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "username",
						Description: "The name of the user",
						Required:    false,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "info",
				Description: "Get information about a user",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "username",
						Description: "The name of the user",
						Required:    false,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "ban",
				Description: "Ban a user",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "username",
						Description: "The name of the user",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "unban",
				Description: "Unban a user",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "username",
						Description: "The name of the user",
						Required:    true,
					},
				},
			},
		},
	})
	CommandHandlers["user"] = UserCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:                     "clear",
		Description:              "Clear the Channel",
		DefaultMemberPermissions: &adminPerm,
	})
	CommandHandlers["clear"] = ClearCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:                     "token",
		Description:              "Manage Tokens",
		DefaultMemberPermissions: &adminPerm,
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Add a token",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:     discordgo.ApplicationCommandOptionString,
						Required: true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove a token",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:     discordgo.ApplicationCommandOptionString,
						Required: true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List all tokens",
			},
		},
	})
	CommandHandlers["token"] = TokenCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:                     "reload",
		Description:              "Reload the Config, Methods, Whitelist and Blacklist",
		DefaultMemberPermissions: &adminPerm,
	})
	CommandHandlers["reload"] = ReloadCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:        "attack",
		Description: "Shows the Attack Screen",
	})
	CommandHandlers["attack"] = AttackCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:        "lookup",
		Description: "Shows Information about an IP/Domain",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "ip",
				Description: "The IP/Domain to lookup",
				Required:    true,
			},
		},
	})
	CommandHandlers["lookup"] = LookupCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:                     "whitelist",
		Description:              "Manage the Whitelist",
		DefaultMemberPermissions: &adminPerm,
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Add an IP to the Whitelist",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "ip",
						Description: "The IP-Address to Whitelist",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove an IP from the Whitelist",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "ip",
						Description: "The IP-Address to remove from the Whitelist",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List all IPs in the Whitelist",
			},
		},
	})
	CommandHandlers["whitelist"] = WhitelistCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:                     "blacklist",
		Description:              "Manage the Blacklist",
		DefaultMemberPermissions: &adminPerm,
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Add an IP to the Blacklist",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "ip",
						Description: "The IP-Address to Blacklist",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove an IP from the Blacklist",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "ip",
						Description: "The IP-Address to remove from the Blacklist",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List all IPs in the Blacklist",
			},
		},
	})
	CommandHandlers["blacklist"] = BlacklistCommand
	Commands = append(Commands, &discordgo.ApplicationCommand{
		Name:        "methods",
		Description: "Manage the Methods",
	})
	CommandHandlers["methods"] = MethodsCommand
}
