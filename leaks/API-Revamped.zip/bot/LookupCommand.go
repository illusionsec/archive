package bot

import (
	"Manager/database"
	"github.com/bwmarrin/discordgo"
)

func LookupCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	Info := database.GetIPInfo(i.ApplicationCommandData().Options[0].StringValue())
	if Info.IP != "" {
		err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title:       "Lookup",
						Description: "Lookup successful",
						Color:       5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:  "**IP**",
								Value: "```" + Info.IP + "```",
							},
							{
								Name:  "**Hostname**",
								Value: "```" + Info.Hostname + "```",
							},
							{
								Name:  "**City**",
								Value: "```" + Info.City + "```",
							},
							{
								Name:  "**Region**",
								Value: "```" + Info.Region + "```",
							},
							{
								Name:  "**Country**",
								Value: "```" + Info.Country + "```",
							},
							{
								Name:  "**Location**",
								Value: "```" + Info.Loc + "```",
							},
							{
								Name:  "**Org**",
								Value: "```" + Info.Org + "```",
							},
							{
								Name:  "**Postal**",
								Value: "```" + Info.Postal + "```",
							},
							{
								Name:  "**Timezone**",
								Value: "```" + Info.Timezone + "```",
							},
						},
					},
				},
			},
		})
		database.CheckError(err)
	} else {
		err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title:       "Lookup",
						Description: "Lookup failed",
						Color:       5763719,
					},
				},
			},
		})
		if database.CheckError(err) {
			return
		}
	}
}
