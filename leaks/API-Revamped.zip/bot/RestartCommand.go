package bot

import (
	"github.com/bwmarrin/discordgo"
	"os"
	"os/exec"
)

func RestartCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Content: "Restarting...",
		},
	})
	go func() {
		exec.Command("sudo", "screen", "-S", "Manager", "./"+os.Args[0], "quit").Run()
		os.Exit(0)
	}()
}
