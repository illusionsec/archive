package bot

import (
	"Manager/database"
	"github.com/bwmarrin/discordgo"
)

func BlacklistCommand(s *discordgo.Session, i *discordgo.InteractionCreate) {
	switch i.ApplicationCommandData().Options[0].Name {
	case "list", "info", "show":
		ips := "\r\n"
		for _, ip := range database.Config.Blacklist {
			ips += ip + "\r\n"
		}
		err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title:       "Blacklist",
						Description: "This is a list of all blacklisted IPs",
						Color:       5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:  "**IPs**",
								Value: "```" + ips + "```",
							},
						},
					},
				},
			},
		})
		if database.CheckError(err) {
			return
		}
	case "add":
		ip := i.ApplicationCommandData().Options[0].Options[0].StringValue()
		for _, ip2 := range database.Config.Blacklist {
			if ip == ip2 {
				err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Title:       "Blacklist",
								Description: "IP already blacklisted",
								Color:       5763719,
								Fields: []*discordgo.MessageEmbedField{
									{
										Name:  "**IP**",
										Value: "```" + ip + " already blacklisted```",
									},
								},
							},
						},
					},
				})
				if database.CheckError(err) {
					return
				}
			}
		}
		database.Config.Blacklist = append(database.Config.Blacklist, ip)
		database.SaveConfig()
		err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title:       "Blacklist",
						Description: "IP added to blacklist",
						Color:       5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:  "**IP**",
								Value: "```" + ip + " added```",
							},
						},
					},
				},
			},
		})
		if database.CheckError(err) {
			return
		}
	case "remove":
		ip := i.ApplicationCommandData().Options[0].Options[0].StringValue()
		for index, ip2 := range database.Config.Blacklist {
			if ip == ip2 {
				database.Config.Blacklist = append(database.Config.Blacklist[:index], database.Config.Blacklist[index+1:]...)
				break
			}
		}
		database.SaveConfig()
		err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Title:       "Blacklist",
						Description: "IP added to blacklist",
						Color:       5763719,
						Fields: []*discordgo.MessageEmbedField{
							{
								Name:  "**IP**",
								Value: "```" + ip + " removed```",
							},
						},
					},
				},
			},
		})
		if database.CheckError(err) {
			return
		}
	}
}
