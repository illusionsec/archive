package database

import (
	"Manager/assets"
	"bytes"
	"database/sql"
	"encoding/json"
	"io/ioutil"
	"log"
	_ "modernc.org/sqlite"
	"os"
	"strconv"
	"time"
)

var DB *sql.DB
var err error

func Connect() {
	DB, err = sql.Open("sqlite", "./database.db?_busy_timeout=50000")
	CheckError(err)
	_, err = DB.Exec("CREATE TABLE IF NOT EXISTS `Users` (`Username` TEXT NOT NULL UNIQUE, `Key` TEXT NOT NULL UNIQUE, `Plan` TEXT NOT NULL, `MaxConcurrents` INTEGER NOT NULL DEFAULT 1, `MaxTime` INTEGER NOT NULL, `Banned` INTEGER NOT NULL DEFAULT 0, `Expiry` TEXT NOT NULL, `Cooldown` INTEGER NOT NULL DEFAULT 15, `HasCooldown` INTEGER NOT NULL DEFAULT 0, `Threads` INTEGER NOT NULL DEFAULT 1);")
	CheckError(err)
	_, err = DB.Exec("CREATE TABLE IF NOT EXISTS `Attacks` (`Host` TEXT NOT NULL , `Port` INT NOT NULL , `Method` TEXT NOT NULL , `Time` TEXT NOT NULL, `User` TEXT NOT NULL, `Timestamp` TEXT NOT NULL, `End` TEXT NOT NULL);")
	CheckError(err)
	_, err = DB.Exec("CREATE TABLE IF NOT EXISTS `Tokens` (`Token` TEXT NOT NULL UNIQUE, `Plan` TEXT NOT NULL, `MaxTime` INTEGER NOT NULL, `MaxCons` INTEGER NOT NULL, `MaxThreads` INTEGER NOT NULL, `Days` INTEGER NOT NULL, `Used` INTEGER NOT NULL, `Uses` INTEGER NOT NULL);")
	CheckError(err)
}

func CreateUser(user assets.User) bool {
	if CheckChars(user.Username) || CheckChars(user.Key) || CheckChars(user.Plan) {
		return false
	}
	_, err := DB.Exec("INSERT INTO `Users` (`Username`, `Key`, `Plan`, `MaxConcurrents`, `MaxTime`, `Banned`, `Expiry`, `Cooldown`, `HasCooldown`, `Threads`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", user.Username, user.Key, user.Plan, user.Concurrent, user.MaxTime, user.Banned, user.Expiry, user.Cooldown, user.HasCooldown, user.Threads)
	Users = append(Users, user)
	Concurrents.Running = append(Concurrents.Running, assets.Concurrent{User: user, Targets: []string{}})
	if CheckError(err) {
		return false
	}
	return true
}

func SaveMethods() {
	file, _ := json.MarshalIndent(Methods, "", "    ")
	fileStr := string(file)
	fileBytes := []byte(fileStr)
	fileBytes = bytes.ReplaceAll(fileBytes, []byte("\\u0026"), []byte("&"))
	fileStr = string(fileBytes)
	file = []byte(fileStr)
	err = ioutil.WriteFile("config/methods.json", file, 0644)
	if err != nil {
		log.Fatal(err)
	}
}

func SaveConfig() {
	file, _ := json.MarshalIndent(Config, "", "	")
	_ = os.WriteFile("config/config.json", file, 0644)
}

func RemoveUser(username string) bool {
	if CheckChars(username) {
		return false
	}
	rowExists := DB.QueryRow("DELETE FROM `Users` WHERE `Username`=?", username)
	if rowExists == nil {
		return false
	}
	for i, user := range Users {
		if user.Username == username {
			Users = append(Users[:i], Users[i+1:]...)
		}
	}
	return true
}

func LoadUsers() {
	rows, err := DB.Query("SELECT * FROM `Users`")
	CheckError(err)
	for rows.Next() {
		var user assets.User
		err = rows.Scan(&user.Username, &user.Key, &user.Plan, &user.Concurrent, &user.MaxTime, &user.Banned, &user.Expiry, &user.Cooldown, &user.HasCooldown, &user.Threads)
		CheckError(err)
		Users = append(Users, user)
	}
	if Users == nil || GetUser("Admin").Username == "" {
		var user assets.User
		user.Username = "Admin"
		user.Key = GenerateKey()
		user.Expiry = time.Now().AddDate(50, 0, 0).Format("02-01-2006")
		user.Plan = "Admin"
		user.MaxTime = 9999
		user.HasCooldown = false
		user.Cooldown = 0
		user.Banned = 0
		user.Threads = 10
		user.Concurrent = 9999
		if !CreateUser(user) {
			Info("Failed to create admin account!")
		} else {
			Info("----------------------------------------")
			Info("Admin-Account")
			Info("Username: Admin")
			Info("Key: " + user.Key)
			Info("Expiry: " + user.Expiry)
			Info("Plan: Admin")
			Info("MaxTime: 9999")
			Info("HasCooldown: false")
			Info("Cooldown: 0")
			Info("Banned: 0")
			Info("Threads: 10")
			Info("Concurrent: 9999")
			Info("----------------------------------------")
		}
	}
	for _, user := range Users {
		Concurrents.Running = append(Concurrents.Running, assets.Concurrent{User: user, Targets: []string{}})
	}
	err = rows.Close()
	CheckError(err)
}

func Authenticate(username string, key string) bool {
	if CheckChars(username) || CheckChars(key) {
		return false
	}
	for _, user := range Users {
		if user.Key == key && user.Username == username {
			return true
		}
	}
	return false
}

func LoadPlans() {
	file, err := os.Open("config/plans.json")
	if CheckError(err) {
		return
	}
	defer file.Close()
	decoder := json.NewDecoder(file)
	err = decoder.Decode(&Plans)
	if CheckError(err) {
		return
	}
}

func LoadNets() {
	file, err := os.Open("config/nets.json")
	if CheckError(err) {
		return
	}
	defer file.Close()
	decoder := json.NewDecoder(file)
	err = decoder.Decode(&Nets)
	if CheckError(err) {
		return
	}
}

func GetUser(username string) assets.User {
	if CheckChars(username) {
		return assets.User{}
	}
	for _, user := range Users {
		if user.Username == username {
			return user
		}
	}
	return assets.User{}
}

func UpdateUser(username string, field string, value string) bool {
	if CheckChars(username) || CheckChars(field) || CheckChars(value) {
		return false
	}
	exec, err := DB.Prepare("UPDATE `Users` SET " + field + "=? WHERE Username=?")
	if CheckError(err) {
		return false
	}
	_, err = exec.Exec(value, username)
	if CheckError(err) {
		return false
	}
	err = exec.Close()
	if CheckError(err) {
		return false
	}
	for i, user := range Users {
		if user.Username == username {
			switch field {
			case "Username":
				Users[i].Username = value
			case "Key":
				Users[i].Key = value
			case "Plan":
				Users[i].Plan = value
			case "MaxConcurrents":
				Users[i].Concurrent, _ = strconv.Atoi(value)
			case "MaxTime":
				Users[i].MaxTime, _ = strconv.Atoi(value)
			case "Banned":
				Users[i].Banned, _ = strconv.Atoi(value)
			case "Expiry":
				Users[i].Expiry = value
			case "Cooldown":
				Users[i].Cooldown, _ = strconv.Atoi(value)
			case "HasCooldown":
				if value == "1" || value == "true" {
					Users[i].HasCooldown = true
				} else {
					Users[i].HasCooldown = false
				}
			}
		}
	}
	return true
}

func UpdateUserStruct(user assets.User) bool {
	if CheckChars(user.Username) || CheckChars(user.Key) || CheckChars(user.Plan) || CheckChars(user.Expiry) || CheckChars(strconv.Itoa(user.Concurrent)) || CheckChars(strconv.Itoa(user.MaxTime)) || CheckChars(strconv.Itoa(user.Banned)) || CheckChars(strconv.Itoa(user.Cooldown)) || CheckChars(strconv.Itoa(user.Threads)) {
		return false
	}
	exec, err := DB.Prepare("UPDATE `Users` SET Username=?, Key=?, Plan=?, MaxConcurrents=?, MaxTime=?, Banned=?, Expiry=?, Cooldown=?, HasCooldown=?, Threads=? WHERE Username=?")
	if CheckError(err) {
		return false
	}
	_, err = exec.Exec(user.Username, user.Key, user.Plan, user.Concurrent, user.MaxTime, user.Banned, user.Expiry, user.Cooldown, user.HasCooldown, user.Threads, user.Username)
	if CheckError(err) {
		return false
	}
	err = exec.Close()
	if CheckError(err) {
		return false
	}
	for i, u := range Users {
		if u.Username == user.Username {
			Users[i] = user
		}
	}
	return true
}

func AddAttack(host string, port int, method string, duration int, user string) {
	var attack assets.Attack
	attack.Host = host
	attack.Port = port
	attack.Method = method
	attack.Time = duration
	attack.User = user
	if CheckChars(attack.Method) || CheckChars(attack.User) {
		return
	}
	attack.Timestamp = time.Now().Format("02-01-2006 15:04:05")
	attack.End = time.Now().Add(time.Duration(duration) * time.Second).Format("02-01-2006 15:04:05")
	Attacks = append(Attacks, attack)
	exec, err := DB.Prepare("INSERT INTO `Attacks` (`Host`, `Port`, `Method`, `Time`, `User`, `Timestamp`, `End`) VALUES (?, ?, ?, ?, ?, ?, ?)")
	CheckError(err)
	_, err = exec.Exec(attack.Host, attack.Port, attack.Method, attack.Time, attack.User, attack.Timestamp, attack.End)
	CheckError(err)
	err = exec.Close()
	CheckError(err)
}

func LoadAttacks() {
	rows, err := DB.Query("SELECT * FROM `Attacks` ORDER BY `Timestamp` DESC LIMIT 500")
	CheckError(err)
	for rows.Next() {
		var attack assets.Attack
		err = rows.Scan(&attack.Host, &attack.Port, &attack.Method, &attack.Time, &attack.User, &attack.Timestamp, &attack.End)
		CheckError(err)
		Attacks = append(Attacks, attack)
	}
	err = rows.Close()
	CheckError(err)
}

func LoadConfig() {
	file, _ := os.Open("config/config.json")
	defer func(file *os.File) {
		err := file.Close()
		CheckError(err)
	}(file)
	decoder := json.NewDecoder(file)
	err := decoder.Decode(&Config)
	CheckError(err)
}

func LoadMethods() {
	file, _ := os.Open("config/methods.json")
	defer func(file *os.File) {
		err := file.Close()
		CheckError(err)
	}(file)
	decoder := json.NewDecoder(file)
	err := decoder.Decode(&Methods)
	CheckError(err)
}

func AddMethod(method assets.Method) {
	if CheckChars(method.Name) || CheckChars(method.Type) {
		return
	}
	m := GetMethod(method.Name)
	if m.Name == "" {
		Methods.Methods = append(Methods.Methods, method)
	} else {
		for i, m := range Methods.Methods {
			if m.Name == method.Name {
				Methods.Methods[i] = method
			}
		}
	}
}

func LoadServers() {
	file, _ := os.Open("config/servers.json")
	defer func(file *os.File) {
		err := file.Close()
		CheckError(err)
	}(file)
	decoder := json.NewDecoder(file)
	err := decoder.Decode(&Servers)
	CheckError(err)
}
