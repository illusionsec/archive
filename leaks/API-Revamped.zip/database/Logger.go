package database

import (
	"fmt"
	"os"
	"time"
)

func LogRequests(message ...interface{}) {
	file, err := os.OpenFile("requests.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer file.Close()
	if _, err := file.WriteString("[" + time.Now().Format("2006-01-02 15:04:05") + "] " + fmt.Sprint(message) + "\n"); err != nil {
		return
	}
}

func Info(message ...interface{}) {
	fmt.Println("[" + time.Now().Format("2006-01-02 15:04:05") + "] [\u001B[32mINFO\u001B[0m] " + fmt.Sprint(message) + "\u001b[0m")
	file, err := os.OpenFile("logs.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer file.Close()
	if _, err := file.WriteString("[" + time.Now().Format("2006-01-02 15:04:05") + "] [INFO] " + fmt.Sprint(message) + "\n"); err != nil {
		return
	}
}

func Warning(message ...interface{}) {
	fmt.Println("[" + time.Now().Format("2006-01-02 15:04:05") + "] [\033[33mWARNING\u001B[0m] \u001b[33;1m" + fmt.Sprint(message) + "\u001B[0m")
	file, err := os.OpenFile("logs.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer file.Close()
	if _, err := file.WriteString("[" + time.Now().Format("2006-01-02 15:04:05") + "] [WARNING] " + fmt.Sprint(message) + "\n"); err != nil {
		return
	}
}
