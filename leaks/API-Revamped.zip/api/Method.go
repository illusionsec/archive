package api

import (
	"Manager/assets"
	"Manager/database"
	"fmt"
	"net/http"
	"strconv"
	"strings"
)

var methodTEMP = NAV + `
<style>
    .panel-container {
        display: flex;
        justify-content: center;
    }
    .panel {
        width: 75%;
        height: 50px;
        margin: 0 75px 25px 75px;
        background-color: #222;
        border-radius: 25px;
        box-shadow: 0 0 10px rgba(0,0,0,0.2);
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: center;
        position: relative;
        cursor: pointer;
        text-align: left;
    }


    .panel.active {
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
    }

    .panel.active .details {
        display: block;
    }

    .icon {
        position: absolute;
        top: 10px;
        right: 15px;
        font-size: 30px;
        color: #fff;
        background-size: contain;
        background-repeat: no-repeat;
        opacity: 0.5;
    }

    .h2, .h3, .count {
        margin: 0;
        position: absolute;
        top: 15%;
    }

    .h2 {
        left: 15px;
        font-size: 32px;
    }

    .h3 {
        font-size: 20px;
        color: #999;
        top: 25%;
        align-items: Center;
        font-family: 'JetBrainsMono';
    }

    .details {
        display: none;
        width: 100%;
        background: #222;
        margin-top: 50px;
    }

    .attribute {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 95%;
        top: 15%;
        margin-top: 50px;
        margin-bottom: 25px;
        margin-left: 25px;
        font-size: 18px;
        font-family: 'JetBrainsMono';
    }

    .attribute input {
        background-color: transparent;
        color: #fff;
        width: 80%;
        font-size: 18px;
        border: 2px solid #333;
        position: relative;
        font-family: 'JetBrainsMono';
    }

    .attribute input:focus {
        outline: none;
    }

    table {
        width: 100%;
        max-width: 1800px;
        border-collapse: collapse;
        margin: 20px auto;
        color: #fff;
        font-size: 16px;
        font-weight: bold;
        text-align: center;
    }

    thead {
        background-color: transparent;
    }

    th {
        padding: 10px 0;
        border-bottom: 2px solid #fff;
    }

    tbody tr {
        background-color: transparent;
        border-bottom: 2px solid #fff;
    }

    tbody td {
        padding: 10px 0;
        border-bottom: 1px solid #fff;
    }

    .save {
        position: relative;
        left: 43%;
        width: 250px;
        background-color: #333;
        border: none;
        color: #fff;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        font-size: 16px;
        margin: 15px 20px;
        cursor: pointer;
        border-radius: 25px;
        font-family: 'JetBrainsMono';
    }

    .save:hover {
        background-color: rgba(55, 55, 55, 0.5);
    }

    .delete {
        position: relative;
        left: 70%;
        width: 100px;
        background-color: #333;
        border: none;
        color: #fff;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        font-size: 16px;
        margin: 15px 20px;
        cursor: pointer;
        border-radius: 25px;
        font-family: 'JetBrainsMono';
    }

    .delete:hover {
        background-color: rgba(55, 55, 55, 0.5);
    }

    .attribute textarea {
        background-color: transparent;
        color: #fff;
        width: 80%;
        font-size: 18px;
        border: 2px solid #333;
        font-family: 'JetBrainsMono';
		min-height: 150px;
    }

    .qbot {
        margin: 25px 0 25px 700px;
        padding-bottom: 15px;
        font-size: 32px;
    }

    .mirai {
        margin: 25px 0 25px 700px;
        padding-bottom: 15px;
        font-size: 32px;
    }
</style>
</head>
<body>
<nav class="navbar">
    <a href="/dashboard"><i class="fas fa-layer-group"></i>Dashboard</a>
    <a href="/users"><i class="fas fa-user"></i>Users</a>
    <a href="/plan"><i class="fas fa-book"></i>Plan</a>
    <a href="/config"><i class="fas fa-cog"></i>Config</a>
    <a href="/methods"><i class="fas fa-rss"></i>Methods</a>
    <a href="/history"><i class="fas fa-clock"></i>History</a>
    <a href="/attack"><i class="fas fa-bolt"></i>Attack</a>
    <a href="/shop"><i class="fas fa-shopping-cart"></i>Shop</a>
    <a href="/logout"><i class="fas fa-door-open logout"></i>Logout</a>
</nav>
<div class="hero">
    <h1 class="h1">Method Management</h1>
    <p>Here you can see and edit the Methods</p>
    <p style="color: red; font-size: 16px; margin-bottom: 20px;">{{.}}</p>
</div>
{{#methods}}
<script>
    function togglePanel(panel) {
        if (event.target.classList.contains('panel') || event.target.classList.contains('icon') || event.target.classList.contains('fas') || event.target.classList.contains('h2') || event.target.classList.contains('h3') ) {
            if (panel.querySelector('.icon i').classList.contains('fa-plus')) {
                panel.querySelector('.icon i').classList.remove('fa-plus');
                panel.querySelector('.icon i').classList.add('fa-minus');
            } else {
                panel.querySelector('.icon i').classList.remove('fa-minus');
                panel.querySelector('.icon i').classList.add('fa-plus');
            }
            panel.classList.toggle('active');
        }
        panel.style.marginBottom = panel.classList.contains('active') ? '1900px' : '25px';
    }
</script>
</body>
</html>
`

func MethodPage(w http.ResponseWriter, r *http.Request) {
	database.LogRequests("==== [ Requested Method Page ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Content-Length: %s", r.Header.Get("Content-Length")))
	database.LogRequests(fmt.Sprintf("Content-Type: %s", r.Header.Get("Content-Type")))
	database.LogRequests(fmt.Sprintf("Referer: %s", r.Header.Get("Referer")))
	database.LogRequests(fmt.Sprintf("Origin: %s", r.Header.Get("Origin")))
	database.LogRequests("=================================")
	var _Temp string
	username, _ := Auth(w, r)
	user := database.GetUser(username)
	if r.Method == "POST" {
		if r.FormValue("save") == "Save" {
			var method assets.Method
			var err error
			method.Name = r.FormValue("name")
			method.Type = r.FormValue("type")
			method.Slots, err = strconv.Atoi(r.FormValue("slots"))
			method.Time, err = strconv.Atoi(r.FormValue("maxtime"))
			if method.Slots >= 0 && method.Name != "" && r.FormValue("plan") != "" && r.FormValue("maxtime") != "" && (method.Type == "Layer4" || method.Type == "Layer7") && err == nil {
				if r.FormValue("qbotcmd") == "" {
					method.Gateway.Qbot.Command = ""
				} else {
					method.Gateway.Qbot.Command = r.FormValue("qbotcmd")
				}
				if r.FormValue("qbotamount") == "" {
					method.Gateway.Qbot.Bots = 0
				} else {
					method.Gateway.Qbot.Bots, err = strconv.Atoi(r.FormValue("qbotamount"))
				}
				if r.FormValue("miraimethod") == "" {
					method.Gateway.Mirai.MethodFlag = 0
				} else {
					method.Gateway.Mirai.MethodFlag, err = strconv.Atoi(r.FormValue("miraimethod"))
				}
				if r.FormValue("miraiamount") == "" {
					method.Gateway.Mirai.Bots = 0
				} else {
					method.Gateway.Mirai.Bots, err = strconv.Atoi(r.FormValue("miraiamount"))
				}
				if r.FormValue("miraiport") == "" {
					method.Gateway.Mirai.PortFlag = 0
				} else {
					method.Gateway.Mirai.PortFlag, err = strconv.Atoi(r.FormValue("miraiport"))
				}
				if r.FormValue("mirailen") == "" {
					method.Gateway.Mirai.LenFlag = 0
				} else {
					method.Gateway.Mirai.LenFlag, err = strconv.Atoi(r.FormValue("mirailen"))
				}
				if len(r.FormValue("commands")) > 0 {
					method.Gateway.Command = []assets.Command{}
					for _, value := range strings.Split(r.FormValue("commands"), "\r\n") {
						method.Gateway.Command = append(method.Gateway.Command, assets.Command{Cmd: value, Count: 1})
					}
				} else {
					method.Gateway.Command = []assets.Command{}
				}
				if len(r.FormValue("asn")) > 0 {
					method.ASN = []string{}
					for _, value := range strings.Split(r.FormValue("asn"), "\r\n") {
						method.ASN = append(method.ASN, value)
					}
				} else {
					method.ASN = []string{}
				}
				if len(r.FormValue("plan")) > 0 {
					method.Plan = []string{}
					for _, value := range strings.Split(r.FormValue("plan"), "\r\n") {
						method.Plan = append(method.Plan, value)
					}
				} else {
					method.Plan = []string{}
				}
				if len(r.FormValue("apis")) > 0 {
					method.Gateway.APIs = []string{}
					for _, value := range strings.Split(r.FormValue("apis"), "\r\n") {
						method.Gateway.APIs = append(method.Gateway.APIs, value)
					}
				} else {
					method.Gateway.APIs = []string{}
				}
				if database.CheckError(err) {
					http.Redirect(w, r, "/methods?error=invalid_input", http.StatusSeeOther)
					return
				}
				database.AddMethod(method)
				database.SaveMethods()
				http.Redirect(w, r, "/methods?error=false", http.StatusSeeOther)
				return
			} else {
				http.Redirect(w, r, "/methods?error=emptyStrings", http.StatusSeeOther)
				return
			}
		} else if r.FormValue("delete") == "Delete" {
			Name := r.FormValue("name")
			if Name != "" && !database.CheckChars(Name) {
				for i, method := range database.Methods.Methods {
					if method.Name == Name {
						database.Methods.Methods = append(database.Methods.Methods[:i], database.Methods.Methods[i+1:]...)
						break
					}
				}
				database.SaveMethods()
				http.Redirect(w, r, "/methods?error=false", 302)
				return
			}
			http.Redirect(w, r, "/methods?error=emptyStrings", 302)
			return
		} else {
			http.Redirect(w, r, "/methods?error=invalid_input", 302)
			return
		}
	}
	if user.Plan != "Admin" {
		_Temp = strings.Replace(methodTEMP, "<a href=\"/users\"><i class=\"fas fa-user\"></i>Users</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/config\"><i class=\"fas fa-cog\"></i>Config</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/methods\"><i class=\"fas fa-rss\"></i>Methods</a>", "", 1)
		_Temp = strings.Replace(_Temp, "width: 42%;", "width: 30%;", 1)
	} else {
		_Temp = methodTEMP
	}

	if r.URL.Query().Get("error") == "emptyStrings" {
		_Temp = strings.NewReplacer("{{.}}", "Please fill out all fields!").Replace(_Temp)
	} else if r.URL.Query().Get("error") == "invalid_input" {
		_Temp = strings.NewReplacer("{{.}}", "Invalid input!").Replace(_Temp)
	} else if r.URL.Query().Get("error") == "update_failed" {
		_Temp = strings.NewReplacer("{{.}}", "Failed to update method!").Replace(_Temp)
	} else if r.URL.Query().Get("error") == "false" {
		_Temp = strings.NewReplacer("{{.}}", "Successfully updated method!").Replace(_Temp)
		_Temp = strings.Replace(_Temp, "color: red;", "color: green;", 1)
	} else if r.URL.Query().Get("error") == "delete_failed" {
		_Temp = strings.NewReplacer("{{.}}", "Failed to delete method!").Replace(_Temp)
	} else if r.URL.Query().Get("error") == "create_failed" {
		_Temp = strings.NewReplacer("{{.}}", "Failed to create method!").Replace(_Temp)
	} else {
		_Temp = strings.NewReplacer("{{.}}", "").Replace(_Temp)
	}

	var _Methods string
	for _, method := range database.Methods.Methods {
		_Methods += fmt.Sprintf(`
<div class="panel-container">
    <div class="panel" onclick="togglePanel(this)">
        <div class="icon"><i class="fas fa-plus"></i></div>
        <h2 class="h2">%s</h2>
        <p class="h3">Click to see Details</p>
        <div class="details">
            <form method="post">
                <div class="attribute">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" value="%s" placeholder="e.g TCP">
                </div>
                <div class="attribute">
                    <label for="type">Type</label>
                    <input type="text" name="type" id="type" value="%s" placeholder="Layer4 / Layer7">
                </div>
                <div class="attribute">
                    <label for="slots">Slots</label>
                    <input type="text" name="slots" id="slots" value="%d" placeholder="e.g 4">
                </div>
                <div class="attribute">
                    <label for="maxtime">MaxTime</label>
                    <input type="text" name="maxtime" id="maxtime" value="%d" placeholder="e.g 300">
                </div>
                <div class="attribute">
                    <label for="asn">ASNS</label>
                    <textarea type="text" name="asn" id="asn" placeholder="e.g ASN382904">%s</textarea>
                </div>
                <div class="attribute">
                    <label for="plan">Plans</label>
                    <textarea type="text" name="plan" id="plan" placeholder="e.g User">%s</textarea>
                </div>
                <div class="attribute">
                    <label for="apis">APIs</label>
                    <textarea type="text" name="apis" id="apis" placeholder="http://api1.com/api/start?username=ClaasCode&key=123&host=[host]&port=[port]&time=[time]&method=TCP">%s</textarea>
                </div>
                <h2 class="qbot">Qbot</h2>
                <div class="attribute">
                    <label for="qbotcmd">Qbot Command</label>
                    <input type="text" name="qbotcmd" id="qbotcmd" value="%s" placeholder="e.g !* TCP [host] [port] [time] 32 1024 0">
                </div>
                <div class="attribute">
                    <label for="qbotamount">QBot Amount</label>
                    <input type="text" name="qbotamount" id="qbotamount" value="%d" placeholder="e.g 500">
                </div>
                <h2 class="mirai">Mirai</h2>
                <div class="attribute">
                    <label for="miraiport">Port Flag</label>
                    <input type="text" name="miraiport" id="miraiport" value="%d" placeholder="e.g 7">
                </div>
                <div class="attribute">
                    <label for="miraimethod">Method Flag</label>
                    <input type="text" name="miraimethod" id="miraimethod" value="%d" placeholder="e.g 0">
                </div>
                <div class="attribute">
                    <label for="mirailen">Len Flag</label>
                    <input type="text" name="mirailen" id="mirailen" value="%d" placeholder="e.g 0">
                </div>
                <div class="attribute">
                    <label for="miraiamount">Mirai Amount</label>
                    <input type="text" name="miraiamount" id="miraiamount" value="%d" placeholder="e.g 500">
                </div>
                <input class="save" type="submit" name="save" id="save" value="Save">
                <input class="delete" type="submit" name="delete" id="delete" value="Delete">
            </form>
        </div>
    </div>
</div>
`, method.Name, method.Name, method.Type, method.Slots, method.Time, strings.Join(method.ASN, "\r\n"), strings.Join(method.Plan, "\r\n"), strings.Join(method.Gateway.APIs, "\r\n"), method.Gateway.Qbot.Command, method.Gateway.Qbot.Bots, method.Gateway.Mirai.PortFlag, method.Gateway.Mirai.MethodFlag, method.Gateway.Mirai.LenFlag, method.Gateway.Mirai.Bots)
	}

	_Methods += `
<div class="panel-container">
    <div class="panel" onclick="togglePanel(this)">
        <div class="icon"><i class="fas fa-plus"></i></div>
        <h2 class="h2">New Method</h2>
        <p class="h3">Click & Edit to Create</p>
        <div class="details">
            <form method="post">
                <div class="attribute">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" value="" placeholder="e.g TCP">
                </div>
                <div class="attribute">
                    <label for="type">Type</label>
                    <input type="text" name="type" id="type" value="" placeholder="Layer4 / Layer7">
                </div>
                <div class="attribute">
                    <label for="slots">Slots</label>
                    <input type="text" name="slots" id="slots" value="" placeholder="e.g 4">
                </div>
                <div class="attribute">
                    <label for="maxtime">MaxTime</label>
                    <input type="text" name="maxtime" id="maxtime" value="" placeholder="e.g 300">
                </div>
                <div class="attribute">
                    <label for="asn">ASNS</label>
                    <textarea type="text" name="asn" id="asn" placeholder="e.g ASN382904"></textarea>
                </div>
                <div class="attribute">
                    <label for="plan">Plan</label>
                    <input type="text" name="plan" id="plan" value="" placeholder="e.g User">
                </div>
                <div class="attribute">
                    <label for="commands">Server Command</label>
                     <textarea type="text" name="commands" id="commands" placeholder="e.g screen -dmS UDP ./UDP [host] [port] [time] [threads]"></textarea>
                </div>
                <div class="attribute">
                    <label for="apis">APIs</label>
                    <textarea type="text" name="apis" id="apis" placeholder="http://api1.com/api/start?username=ClaasCode&key=123&host=[host]&port=[port]&time=[time]&method=TCP"></textarea>
                </div>
                <h2 class="qbot">Qbot</h2>
                <div class="attribute">
                    <label for="qbotcmd">Qbot Command</label>
                    <input type="text" name="qbotcmd" id="qbotcmd" value="" placeholder="e.g !* TCP [host] [port] [time] 32 1024 0">
                </div>
                <div class="attribute">
                    <label for="qbotamount">QBot Amount</label>
                    <input type="text" name="qbotamount" id="qbotamount" value="" placeholder="e.g 500">
                </div>
                <h2 class="mirai">Mirai</h2>
                <div class="attribute">
                    <label for="miraiport">Port Flag</label>
                    <input type="text" name="miraiport" id="miraiport" value="" placeholder="e.g 7">
                </div>
                <div class="attribute">
                    <label for="miraimethod">Method Flag</label>
                    <input type="text" name="miraimethod" id="miraimethod" value="" placeholder="e.g 0">
                </div>
                <div class="attribute">
                    <label for="mirailen">Len Flag</label>
                    <input type="text" name="mirailen" id="mirailen" value="" placeholder="e.g 0">
                </div>
                <div class="attribute">
                    <label for="miraiamount">Mirai Amount</label>
                    <input type="text" name="miraiamount" id="miraiamount" value="" placeholder="e.g 500">
                </div>
                <input class="save" type="submit" name="save" id="save" value="Save">
            </form>
        </div>
    </div>
</div>
`
	_, err := strings.NewReplacer("{{#methods}}", _Methods).WriteString(w, _Temp)
	if database.CheckError(err) {
		return
	}
}
