package api

import (
	"Manager/database"
	"fmt"
	"net/http"
	"strings"
)

var shopTEMP = NAV + `
<style>
        .panel-container {
            display: flex;
            justify-content: center;
            margin-bottom: 50px;
        }

        .panel {
            width: 20%;
            height: 525px;
            margin: 0 75px 0 75px;
            background-color: #222;
            border-radius: 25px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            position: relative;
        }

        .icon {
            position: absolute;
            top: 15px;
            right: 10px;
            font-size: 85px;
            color: #000;
            background-size: contain;
            background-repeat: no-repeat;
            opacity: 0.5;
        }

        .h2, .h3, .infos {
            text-align: center;
            margin: 0;
            position: absolute;
            top: 10%;
        }

        .h2 {
            font-size: 32px;
        }

        .h3 {
            font-size: 20px;
            color: #999;
            top: 20%;
            font-family: 'JetBrainsMono';
        }

        .infos {
            font-size: 20px;
            text-align: left;
            color: #999;
            background: transparent;
            border: none;
            outline: none;
            user-select: none;
            top: 30%;
            left: -30%;
            font-family: 'JetBrainsMono';
        }

        .price {
            top: 70%;
            position: absolute;
            bottom: 20px;
            font-size: 32px;
            align-self: center;
            left: 20%;
            color: #fff;
            background-size: contain;
            background-repeat: no-repeat;
            opacity: 0.9;
        }

        .buy {
            position: absolute;
            top: 85%;
            align-self: center;
            width: 250px;
            background-color: #333;
            border: none;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            margin: 15px 20px;
            cursor: pointer;
            border-radius: 25px;
            font-family: 'JetBrainsMono';
        }

		.buy:hover {
			background-color: rgba(55, 55, 55, 0.5);
		}

        form {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 0 20px;
        }

        .code {
            position: relative;
            background-color: transparent;
            width: 500px;
            padding: 10px 20px;
            color: #ffff;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            margin: 15px 20px;
            cursor: pointer;
            border: none;
            border-bottom: #fff 2px solid;
            top: 115%;
            font-family: 'JetBrainsMono';
        }

		.code:focus {
			outline: none;
		}

        .redeembtn {
            position: absolute;
            top: 70%;
            align-self: center;
            width: 250px;
            background-color: #333;
            border: none;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            margin: 15px 20px;
            cursor: pointer;
            border-radius: 25px;
            font-family: 'JetBrainsMono';
        }

        .redeembtn:hover {
            background-color: rgba(55, 55, 55, 0.5);
        }

        .redeem {
            width: 60%;
            height: 250px;
            margin: 0 75px 0 75px;
            background-color: #222;
            border-radius: 25px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            position: relative;
        }
    </style>
</head>
<body>
<nav class="navbar">
    <a href="/dashboard"><i class="fas fa-layer-group"></i>Dashboard</a>
    <a href="/users"><i class="fas fa-user"></i>Users</a>
    <a href="/plan"><i class="fas fa-book"></i>Plan</a>
    <a href="/config"><i class="fas fa-cog"></i>Config</a>
    <a href="/methods"><i class="fas fa-rss"></i>Methods</a>
    <a href="/history"><i class="fas fa-clock"></i>History</a>
    <a href="/attack"><i class="fas fa-bolt"></i>Attack</a>
    <a href="/shop"><i class="fas fa-shopping-cart"></i>Shop</a>
    <a href="/logout"><i class="fas fa-door-open logout"></i>Logout</a>
</nav>

<div class="hero">
    <h1 class="h1">Our Shop</h1>
    <p class="p">Here you can see all our Plans.</p>
</div>
{{#plans}}

<div class="panel-container">
    <div class="redeem">
        <div class="icon">
            <i class="fas fa-gift"></i>
        </div>
        <h2 class="h2">Redeem Code</h2>
        <form method="post">
            <input type="text" name="code" placeholder="Code" class="code" id="code">
            <button type="submit" class="redeembtn">Redeem</button>
        </form>
    </div>
</div>

</div>
</body>
</html>`

func ShopPage(w http.ResponseWriter, r *http.Request) {
	database.LogRequests("==== [ Requested Shop Page ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Content-Length: %s", r.Header.Get("Content-Length")))
	database.LogRequests(fmt.Sprintf("Content-Type: %s", r.Header.Get("Content-Type")))
	database.LogRequests(fmt.Sprintf("Referer: %s", r.Header.Get("Referer")))
	database.LogRequests(fmt.Sprintf("Origin: %s", r.Header.Get("Origin")))
	database.LogRequests("=================================")
	var _Temp string
	username, _ := Auth(w, r)
	user := database.GetUser(username)
	if r.Method == "POST" {
		submit := r.FormValue("code")
		if database.CheckChars(submit) {
			return
		}
	}
	// TODO: Check for Request Method & Add Code Redeem
	if user.Plan != "Admin" {
		_Temp = strings.Replace(shopTEMP, "<a href=\"/users\"><i class=\"fas fa-user\"></i>Users</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/config\"><i class=\"fas fa-cog\"></i>Config</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/methods\"><i class=\"fas fa-rss\"></i>Methods</a>", "", 1)
		_Temp = strings.Replace(_Temp, "width: 42%;", "width: 30%;", 1)
	} else {
		_Temp = shopTEMP
	}
	database.LoadPlans()
	index := 0
	var plans = "<div class=\"panel-container\">"
	for _, plan := range database.Plans.Plans {
		plans += fmt.Sprintf(`
<div class="panel">
        <i class="fas %s icon"></i>
        <h2 class="h2">%s</h2>
        <h3 class="h3">%s</h3>
        <pre>
        <p class="infos">
            MaxTime     %d<br>
            Cooldown    %d<br>
            Threads     %d<br>
            Concurrents %d<br>
        </p>
            <p class="price">%s / %d Days</p>
        </pre>
        <button class="buy"><i class="fas fa-shopping-cart"></i> Buy</button>
    </div>
`, plan.Icon, plan.Name, plan.Description, plan.MaxTime, plan.Cooldown, plan.Threads, plan.Concurrents, plan.Price, plan.Days)
		if (index+1)%3 == 0 {
			plans += "</div><div class=\"panel-container\">"
		}
		index++
	}
	plans += "</div>"
	_, err := strings.NewReplacer("{{#plans}}", plans).WriteString(w, _Temp)
	database.CheckError(err)
}
