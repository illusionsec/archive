package api

import (
	"Manager/assets"
	"Manager/database"
	"fmt"
	"log"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"
)

var historyTEMP = NAV + `
<style>
        .panel-container {
            display: flex;
            justify-content: center;
            margin-bottom: 50px;
        }

        .panel {
            width: 20%;
            height: 450px;
            margin: 0 75px 0 75px;
            background-color: #222;
            border-radius: 25px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            position: relative;
        }

        .icon {
            position: absolute;
            top: 20px;
            right: 10px;
            font-size: 85px;
            color: #000;
            background-size: contain;
            background-repeat: no-repeat;
            opacity: 0.5;
        }

        .h2, .h3, .count {
            text-align: center;
            margin: 0;
            position: absolute;
            top: 15%;
        }

        .h2 {
            font-size: 32px;
        }

        .h3 {
            font-size: 20px;
            color: #999;
            top: 25%;
            font-family: 'JetBrainsMono';
        }

        .count {
            font-size: 40px;
            color: #999;
            top: 55%;
            font-family: 'JetBrainsMono';
        }

        .logout {
            margin-left: 20px;
        }

        table {
            width: 100%;
            max-width: 600px;
            border-collapse: collapse;
            margin: 20px auto;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            text-align: center;
        }

        thead {
            background-color: transparent;
        }

        th {
            padding: 10px 0;
            border-bottom: 2px solid #fff;
        }

        tbody tr {
            background-color: transparent;
            border-bottom: 2px solid #fff;
        }

        tbody td {
            padding: 10px 0;
            border-bottom: 1px solid #fff;
        }

 		.attack {
            left: 30px;
            top: 40px;
        }

        .running {
            left: 30px;
            top: 30%;
        }

        .running-p {
            left: 40px;
            top: 40%;
        }

        .total {
            left: 30px;
            top: 60%;
        }

        .total-p {
            left: 40px;
            top: 70%;
        }

        .table {
            max-width: 1500px;
        }

		.overflow {
			position: relative;
			overflow: auto;
			width: 65%;
			left: 20%;
			padding: 0 20px;
			height: 400px;
			margin-bottom: 75px;
		}

		#chart {
		  width: 65%;
		  height: 400px;
		  left: 20%;
		}
    </style>
	<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
</head>
<body>
<nav class="navbar">
    <a href="/dashboard"><i class="fas fa-layer-group"></i>Dashboard</a>
    <a href="/users"><i class="fas fa-user"></i>Users</a>
    <a href="/plan"><i class="fas fa-book"></i>Plan</a>
    <a href="/config"><i class="fas fa-cog"></i>Config</a>
    <a href="/methods"><i class="fas fa-rss"></i>Methods</a>
    <a href="/history"><i class="fas fa-clock"></i>History</a>
    <a href="/attack"><i class="fas fa-bolt"></i>Attack</a>
    <a href="/shop"><i class="fas fa-shopping-cart"></i>Shop</a>
    <a href="/logout"><i class="fas fa-door-open logout"></i>Logout</a>
</nav>

<div class="hero">
    <h1 class="h1">Attacks</h1>
    <p class="p">Global Attack Information</p>
</div>

<div class="panel-container">
    <div class="panel">
		<i class="fas fa-globe icon"></i>
        <h2 class="attack h2">Attack Info</h2>
        <h3 class="running h3">Running Attacks</h3>
        <p class="running-p count">{{running}}</p>
        <h3 class="total h3">Total Attacks</h3>
        <p class="total-p count">{{total}}</p>
    </div>
	<div id="chart" class="chart">
	</div>
</div>
	<div class="overflow">
			<table class="table">
				<thead>
				<tr>
					<th>Date</th>
					<th>User</th>
					<th>Host</th>
					<th>Port</th>
					<th>Time</th>
					<th>Method</th>
				</tr>
				</thead>
				{{#attacks}}
				<tbody>
			</table>
		</div>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
var options = {
		series: [{
          data: [{{data}}]
        }],
		chart: {
          type: 'area',
          height: 280,
          sparkline: {
            enabled: true
          },
        },
        stroke: {
          curve: 'smooth'
        },
        fill: {
          opacity: 0.2,
        },
        yaxis: {
          min: 0
        },
        title: {
          text: '{{total}}',
          offsetX: 0,
          style: {
            fontSize: '24px',
     		colors: '#0000'
          }
        },
        subtitle: {
          text: 'Attacks last 7 Days',
          offsetX: 0,
          style: {
            fontSize: '14px',
			colors: ['#ffffff']
          }
        }
        };

var chart = new ApexCharts(document.querySelector("#chart"), options);
chart.render();
</script>
</body>
</html>
`

func GetLastSevenDaysAttacks() []assets.AttackCount {
	attacks := database.Attacks

	lastSevenDays := make(map[string]int)
	for i := 0; i < 7; i++ {
		date := time.Now().UTC().AddDate(0, 0, -i-1).Format("02-01-2006")
		lastSevenDays[date] = 0
	}

	for _, attack := range attacks {
		timestamp, err := time.Parse("02-01-2006 15:04:05", attack.Timestamp)
		if err != nil {
			log.Fatal(err)
		}

		date := timestamp.Format("02-01-2006")

		if timestamp.After(time.Now().AddDate(0, 0, -7)) {
			lastSevenDays[date]++
		}
	}

	dates := make([]time.Time, 0, len(lastSevenDays))
	for date := range lastSevenDays {
		t, _ := time.Parse("02-01-2006", date)
		dates = append(dates, t)
	}
	sort.Slice(dates, func(i, j int) bool {
		return dates[i].Before(dates[j])
	})

	results := make([]assets.AttackCount, 0, len(dates))
	for _, date := range dates {
		strDate := date.UTC().Format("02-01-2006")
		count := lastSevenDays[strDate]
		results = append(results, assets.AttackCount{Date: strDate, Count: count})
	}

	return results
}

func HistoryPage(w http.ResponseWriter, r *http.Request) {
	database.LogRequests("==== [ Requested Index Page ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Content-Length: %s", r.Header.Get("Content-Length")))
	database.LogRequests(fmt.Sprintf("Content-Type: %s", r.Header.Get("Content-Type")))
	database.LogRequests(fmt.Sprintf("Referer: %s", r.Header.Get("Referer")))
	database.LogRequests(fmt.Sprintf("Origin: %s", r.Header.Get("Origin")))
	database.LogRequests("=================================")
	var _Temp string
	username, _ := Auth(w, r)
	user := database.GetUser(username)
	if user.Plan != "Admin" {
		_Temp = strings.Replace(historyTEMP, "<a href=\"/users\"><i class=\"fas fa-user\"></i>Users</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/config\"><i class=\"fas fa-cog\"></i>Config</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/methods\"><i class=\"fas fa-rss\"></i>Methods</a>", "", 1)
		_Temp = strings.Replace(_Temp, "width: 42%;", "width: 30%;", 1)
	} else {
		_Temp = historyTEMP
	}
	var attacks string
	var labels string
	var data string
	for i := 7; i >= 0; i-- {
		labels += "\"" + time.Now().AddDate(0, 0, -i).Format("Monday") + "\","
	}

	for _, count := range GetLastSevenDaysAttacks() {
		data += strconv.Itoa(count.Count) + ","
	}
	labels = strings.TrimSuffix(labels, ",")
	data = strings.TrimSuffix(data, ",")

	count := 500
	newAttacks := database.Attacks
	if len(database.Attacks) > 500 {
		newAttacks = database.Attacks[len(database.Attacks)-count:]
	}

	total := 0
	_tcks := strings.Split(data, ",")
	for _, a := range _tcks {
		if a != "" || a != "0" {
			_t, _ := strconv.Atoi(a)
			total += _t
		}
	}

	if user.Plan == "Admin" {
		for _, a := range newAttacks {
			date, err := time.Parse("02-01-2006 15:04:05", a.Timestamp)
			if database.CheckError(err) {
				return
			}
			attacks += "<tr><td>" + date.Format("02-01-2006") + "</td><td>" + a.User + "</td><td>" + a.Host + "</td><td>" + strconv.Itoa(a.Port) + "</td><td>" + strconv.Itoa(a.Time) + "</td><td>" + a.Method + "</td></tr>"
		}
	} else {
		for _, a := range newAttacks {
			if a.User == user.Username {
				date, err := time.Parse("02-01-2006 15:04:05", a.Timestamp)
				if database.CheckError(err) {
					return
				}
				attacks += "<tr><td>" + date.Format("02-01-2006") + "</td><td>" + a.User + "</td><td>" + a.Host + "</td><td>" + strconv.Itoa(a.Port) + "</td><td>" + strconv.Itoa(a.Time) + "</td><td>" + a.Method + "</td></tr>"
			}
		}
	}

	w.WriteHeader(http.StatusOK)
	_, err := strings.NewReplacer("{{labels}}", labels, "{{total}}", strconv.Itoa(total), "{{data}}", data, "{{#attacks}}", attacks, "{{running}}", strconv.Itoa(database.GetActiveCons()), "{{total}}", strconv.Itoa(len(database.Attacks))).WriteString(w, _Temp)
	if database.CheckError(err) {
		return
	}
}
