package api

import (
	"Manager/database"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"
)

var attackTEMP = NAV + `
<style>
        .panel-container {
            display: flex;
            justify-content: left;
        }

        .panel {
            width: 25%;
            height: 650px;
            margin: 0 75px 0 75px;
            background-color: #222;
            border-radius: 25px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
        }


        .attack {
            left: 51px;
        }

        .history {
            width: 60%;
        }

        .icon {
            position: absolute;
            top: 20px;
            right: 10px;
            font-size: 85px;
            color: #000;
            background-size: contain;
            background-repeat: no-repeat;
            opacity: 0.5;
        }

        .h2, .h3 {
            text-align: center;
            margin: 0;
            position: absolute;
            top: 5%;
        }

        .h2 {
            font-size: 32px;
        }

        .h3 {
            font-size: 20px;
            color: #999;
            top: 12%;
            font-family: 'JetBrainsMono', serif;
        }

        form {
            background-color: transparent;
            padding: 20px;
            border-radius: 5px;
            font-size: 20px;
            width: 300px;
            margin: 135px auto;
            display: flex;
            flex-direction: column;
        }

        input[type="text"], input[type="password"] {
            padding: 10px;
            margin-bottom: 20px;
            background-color: transparent;
            border: none;
            border-bottom: 2px solid #fff;
            color: #fff;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
            font-family: 'JetBrainsMono', serif;
            transition: all 0.3s ease;
        }
        input[type="text"]:focus, input[type="password"]:focus {
            border-bottom-color: #ccc;
            outline: none;
        }
        input[type="password"]::-webkit-outer-spin-button, input[type="password"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        input[type="password"] {
            -moz-appearance: textfield;
            width: 100%;
        }
        input[type="submit"] {
            padding: 10px 50px;
            background-color: transparent;
            border: 2px solid #fff;
            color: #fff;
            font-size: 16px;
            align-items: center;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #fff;
            color: #333;
        }


        table {
            top: 20%;
            width: 90%;
            border-collapse: collapse;
            margin: 20px auto;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            position: absolute;
			table-layout: fixed;
        }

        thead {
            background-color: transparent;
        }

        th {
            padding: 10px 0;
            border-bottom: 2px solid #fff;
        }

        tbody tr {
            background-color: transparent;
            border-bottom: 2px solid #fff;
        }

        tbody td {
            padding: 10px 0;
            border-bottom: 1px solid #fff;
        }

        .methods {
            position: relative;
            display: inline-block;
        }

        .methods .dropbtn {
            background-color: transparent;
            color: #fff;
            width: 100%;
            font-size: 16px;
            border: none;
            text-align: left;
            cursor: pointer;
            font-family: 'JetBrainsMono', sans-serif;
            padding: 10px 0;
            border-bottom: 2px solid #fff;
        }

        .methods .dropbtn:hover {
            border-bottom: 2px solid #ccc;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            width: 100%;
            max-height: 200px;
            overflow-y: auto;
            border: 2px solid #fff;
            border-top: none;
            border-bottom: 2px solid #ddd;
            background-color: rgba(33, 33, 33, 0.9);
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: #fff;
            font-family: 'JetBrainsMono', sans-serif;
            font-size: 16px;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: block;
        }

        .methods:hover .dropdown-content {
            display: block;
        }

        .dropdown-content a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .panel1 {
            top: 17%;
            margin: 0;
            overflow: auto;
            max-height: 500px;
            background: transparent;
            width: 100%;
            height: 650px;
            border-radius: 25px;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
        }

    </style>
</head>
<body>
<nav class="navbar">
    <a href="/dashboard"><i class="fas fa-layer-group"></i>Dashboard</a>
    <a href="/users"><i class="fas fa-user"></i>Users</a>
    <a href="/plan"><i class="fas fa-book"></i>Plan</a>
    <a href="/config"><i class="fas fa-cog"></i>Config</a>
    <a href="/methods"><i class="fas fa-rss"></i>Methods</a>
    <a href="/history"><i class="fas fa-clock"></i>History</a>
    <a href="/attack"><i class="fas fa-bolt"></i>Attack</a>
	<a href="/shop"><i class="fas fa-shopping-cart"></i>Shop</a>
    <a href="/logout"><i class="fas fa-door-open logout"></i>Logout</a>
</nav>

<div class="hero">
    <h1 class="h1">Attack Page</h1>
    <p></p>
</div>

<div class="panel-container">
    <div class="panel attack">
        <i class="fas fa-bolt icon"></i>
        <h2 class="h2">Attack</h2>
        <h3 class="h3">Prepare Attack</h3>
        <form method="post">
            <label for="host">Host:</label>
            <input type="text" name="host" id="host" placeholder="e.g 70.70.70.75" required>
            <label for="port">Port:</label>
            <input type="text" name="port" id="port" placeholder="e.g 80" required>
            <label for="time">Time:</label>
            <input type="text" name="time" id="time" placeholder="e.g 60" required>
            <label for="selected_method" class="methodlbl">Method:</label>
			<input type="hidden" name="selected_method" id="selected_method" value="">
            <div class="methods">
                <button class="dropbtn" id="dropbtn" type='button'>Select method...</button>
                <div class="dropdown-content">
                    {{#methods}}
                </div>
            </div>
            <p style="color: red; font-size: 16px; margin-bottom: 20px;">{{.}}</p>
            <input type="submit" value="Send Attack">
        </form>
    </div>

    <div class="panel history">
        <i class="fas fa-clock icon"></i>
        <h2 class="h2">Attack-History</h2>
        <h3 class="h3">Recently sent Attacks</h3>
		<div class="panel1 history">
			<table class="table">
				<thead>
				<tr>
					<th>Date</th>
					<th>Host</th>
					<th>Port</th>
					<th>Time</th>
					<th>Method</th>
				</tr>
				</thead>
				<tbody>
					{{#attacks}}
				<tbody>
			</table>
		</div>
    </div>
</div>

<script>
    const dropdownBtn = document.querySelector(".dropbtn");
    const dropdownContent = document.querySelector(".dropdown-content");
    const methoddiv = document.querySelector(".methods");

	dropdownContent.querySelectorAll("a").forEach((item) => {
		item.addEventListener("click", (event) => {
			const selectedMethod = getSelectedMethod(event.target);
			dropdownBtn.textContent = selectedMethod;
			document.getElementById("selected_method").value = selectedMethod;
			dropdownContent.style.display = "none";
		});
	});


    dropdownBtn.addEventListener("click", () => {
        dropdownContent.style.display =
            dropdownContent.style.display === "block" ? "none" : "block";
    });

    dropdownBtn.addEventListener("mouseenter", () => {
        if (dropdownContent.style.display === "none") {
            dropdownContent.style.display = "block";
        }
    });

    dropdownContent.addEventListener("mouseleave", () => {
        dropdownContent.style.display = "none";
    });

    methoddiv.addEventListener("mouseleave", () => {
        dropdownContent.style.display = "none";
    });

    dropdownContent.querySelectorAll("a").forEach((item) => {
        item.addEventListener("click", () => {
            dropdownContent.style.display = "none";
        });
    });

	function getSelectedMethod(target) {
    	return target.textContent;
	}
</script>
</body>
</html>
`

func AttackPage(w http.ResponseWriter, r *http.Request) {
	database.LogRequests("==== [ Requested Attack Page ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Content-Length: %s", r.Header.Get("Content-Length")))
	database.LogRequests(fmt.Sprintf("Content-Type: %s", r.Header.Get("Content-Type")))
	database.LogRequests(fmt.Sprintf("Referer: %s", r.Header.Get("Referer")))
	database.LogRequests(fmt.Sprintf("Origin: %s", r.Header.Get("Origin")))
	database.LogRequests("=================================")
	var _Temp string
	username, _ := Auth(w, r)
	user := database.GetUser(username)
	if r.Method == "POST" {
		Host := r.FormValue("host")
		Port := r.FormValue("port")
		Time := r.FormValue("time")
		Method := r.FormValue("selected_method")
		if Host == "" || Port == "" || Time == "" || Method == "" {
			http.Redirect(w, r, "/attack?error=empty", http.StatusSeeOther)
			return
		} else {
			var host string
			if database.ServerIP != "" {
				host = database.ServerIP
			} else {
				host = "localhost"
			}
			resp, err := http.Get("http://" + host + ":" + strconv.Itoa(database.Config.Port) + "/api/start?username=" + user.Username + "&key=" + user.Key + "&host=" + Host + "&port=" + Port + "&time=" + Time + "&method=" + Method)
			if database.CheckError(err) {
				http.Redirect(w, r, "/attack?error=request", http.StatusSeeOther)
				return
			} else {
				if resp.StatusCode == 200 {
					http.Redirect(w, r, "/attack?error=false", http.StatusSeeOther)
					return
				}
				body, err := io.ReadAll(resp.Body)
				if database.CheckError(err) {
					http.Redirect(w, r, "/attack?error=request", http.StatusSeeOther)
					return
				}
				switch string(body) {
				case "Login failed":
					http.Redirect(w, r, "/attack?error=login", http.StatusSeeOther)
					return
				case "Bad string":
					http.Redirect(w, r, "/attack?error=string", http.StatusSeeOther)
					return
				case "Host is blacklisted":
					http.Redirect(w, r, "/attack?error=blacklist", http.StatusSeeOther)
					return
				case "Invalid time":
					http.Redirect(w, r, "/attack?error=invalid_time", http.StatusSeeOther)
					return
				case "Time bigger than allowed":
					http.Redirect(w, r, "/attack?error=config_time", http.StatusSeeOther)
					return
				case "You are on cooldown":
					http.Redirect(w, r, "/attack?error=cooldown", http.StatusSeeOther)
					return
				case "You are banned":
					http.Redirect(w, r, "/attack?error=banned", http.StatusSeeOther)
					return
				case "Time is too long":
					http.Redirect(w, r, "/attack?error=time", http.StatusSeeOther)
					return
				case "Host is not an IP":
					http.Redirect(w, r, "/attack?error=l7_ip", http.StatusSeeOther)
					return
				case "Host is a Domain":
					http.Redirect(w, r, "/attack?error=l4_domain", http.StatusSeeOther)
					return
				case "Method not allowed":
					http.Redirect(w, r, "/attack?error=asn", http.StatusSeeOther)
					return
				case "Method not found":
					http.Redirect(w, r, "/attack?error=method", http.StatusSeeOther)
					return
				case "Method time exceeded":
					http.Redirect(w, r, "/attack?error=method_time", http.StatusSeeOther)
					return
				case "Method not allowed on your plan":
					http.Redirect(w, r, "/attack?error=plan", http.StatusSeeOther)
					return
				case "Invalid port":
					http.Redirect(w, r, "/attack?error=port", http.StatusSeeOther)
				case "You are already attacking the maximum amount of targets":
					http.Redirect(w, r, "/attack?error=max_cons", http.StatusSeeOther)
					return
				case "Target is already being attacked":
					http.Redirect(w, r, "/attack?error=powersaving", http.StatusSeeOther)
					return
				case "Global Concurrent limit reached":
					http.Redirect(w, r, "/attack?error=global_concurrent", http.StatusSeeOther)
					return
				default:
					http.Redirect(w, r, "/attack?error=request", http.StatusSeeOther)
				}

			}
		}
	}

	if user.Plan != "Admin" {
		_Temp = strings.Replace(attackTEMP, "<a href=\"/users\"><i class=\"fas fa-user\"></i>Users</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/config\"><i class=\"fas fa-cog\"></i>Config</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/methods\"><i class=\"fas fa-rss\"></i>Methods</a>", "", 1)
		_Temp = strings.Replace(_Temp, "width: 42%;", "width: 30%;", 1)
	} else {
		_Temp = attackTEMP
	}
	var methods = "<a>[Layer 4]</a>"
	for _, method := range database.Methods.Methods {
		if method.Type == "Layer4" && database.CheckPlan(user.Plan, method.Plan) {
			methods += `<a>` + method.Name + `</a>`
		}
	}
	methods += `<a></a><a>[Layer 7]</a>`
	for _, method := range database.Methods.Methods {
		if method.Type == "Layer7" && database.CheckPlan(user.Plan, method.Plan) {
			methods += `<a>` + method.Name + `</a>`
		}
	}

	count := 500
	newAttacks := database.Attacks
	if len(database.Attacks) > 500 {
		newAttacks = database.Attacks[len(database.Attacks)-count:]
	}
	var attacks string
	for _, attack := range newAttacks {
		if attack.User == username {
			date, err := time.Parse("02-01-2006 15:04:05", attack.Timestamp)
			database.CheckError(err)
			attacks += `<tr>
				<td>` + date.Format("02-01-2006") + `</td>
				<td>` + attack.Host + `</td>
				<td>` + strconv.Itoa(attack.Port) + `</td>
				<td>` + strconv.Itoa(attack.Time) + `</td>
				<td>` + attack.Method + `</td>
			</tr>`
		}
	}

	if r.URL.Query().Get("error") != "" {
		switch r.URL.Query().Get("error") {
		case "request":
			_Temp = strings.NewReplacer("{{.}}", "Error while sending request").Replace(_Temp)
		case "login":
			_Temp = strings.NewReplacer("{{.}}", "Login failed").Replace(_Temp)
		case "string":
			_Temp = strings.NewReplacer("{{.}}", "Invalid string").Replace(_Temp)
		case "blacklist":
			_Temp = strings.NewReplacer("{{.}}", "Host is blacklisted").Replace(_Temp)
		case "invalid_time":
			_Temp = strings.NewReplacer("{{.}}", "Invalid time").Replace(_Temp)
		case "config_time":
			_Temp = strings.NewReplacer("{{.}}", "Time bigger than allowed").Replace(_Temp)
		case "cooldown":
			_Temp = strings.NewReplacer("{{.}}", "You are on cooldown").Replace(_Temp)
		case "banned":
			_Temp = strings.NewReplacer("{{.}}", "You are banned").Replace(_Temp)
		case "time":
			_Temp = strings.NewReplacer("{{.}}", "Time is too long").Replace(_Temp)
		case "l7_ip":
			_Temp = strings.NewReplacer("{{.}}", "Host is not an IP").Replace(_Temp)
		case "l4_domain":
			_Temp = strings.NewReplacer("{{.}}", "Host is a Domain").Replace(_Temp)
		case "asn":
			_Temp = strings.NewReplacer("{{.}}", "Method not allowed on that IP.").Replace(_Temp)
		case "method":
			_Temp = strings.NewReplacer("{{.}}", "Method not found").Replace(_Temp)
		case "method_time":
			_Temp = strings.NewReplacer("{{.}}", "Method time exceeded").Replace(_Temp)
		case "plan":
			_Temp = strings.NewReplacer("{{.}}", "Method not allowed on your plan").Replace(_Temp)
		case "port":
			_Temp = strings.NewReplacer("{{.}}", "Invalid port").Replace(_Temp)
		case "max_cons":
			_Temp = strings.NewReplacer("{{.}}", "You are already attacking the maximum amount of targets").Replace(_Temp)
		case "powersaving":
			_Temp = strings.NewReplacer("{{.}}", "Target is already being attacked").Replace(_Temp)
		case "global_concurrent":
			_Temp = strings.NewReplacer("{{.}}", "Global Concurrent limit reached").Replace(_Temp)
		case "empty":
			_Temp = strings.NewReplacer("{{.}}", "Please check your input").Replace(_Temp)
		case "false":
			_Temp = strings.NewReplacer("{{.}}", "Attack successfully Sent").Replace(_Temp)
			_Temp = strings.Replace(_Temp, "color: red;", "color: green;", 1)
		default:
			_Temp = strings.Replace(_Temp, "{{.}}", "", 1)
		}
	} else {
		_Temp = strings.Replace(_Temp, "{{.}}", "", 1)
	}

	_, err := strings.NewReplacer("{{#attacks}}", attacks, "{{#methods}}", methods).WriteString(w, _Temp)
	if database.CheckError(err) {
		return
	}
}
