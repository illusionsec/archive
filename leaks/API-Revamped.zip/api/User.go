package api

import (
	"Manager/database"
	"fmt"
	"net/http"
	"strconv"
	"strings"
)

var userTEMP = NAV + `
<style>
        .panel-container {
            display: flex;
            justify-content: center;
        }

        .panel {
            width: 50%;
            height: 50px;
            margin: 0 75px 25px 75px;
            background-color: #222;
            border-radius: 25px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            position: relative;
            cursor: pointer;
            text-align: left;
        }


        .panel.active {
            border-bottom-left-radius: 0;
            border-bottom-right-radius: 0;
        }

        .panel.active .details {
            display: block;
        }

        .icon {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 30px;
            color: #fff;
            background-size: contain;
            background-repeat: no-repeat;
            opacity: 0.5;
        }

        .h2, .h3, .count {
            margin: 0;
            position: absolute;
            top: 15%;
        }

        .h2 {
            left: 15px;
            font-size: 32px;
        }

        .h3 {
            font-size: 20px;
            color: #999;
            top: 25%;
            align-items: Center;
            font-family: 'JetBrainsMono';
        }

        .count {
            font-size: 40px;
            color: #999;
            top: 55%;
            font-family: 'JetBrainsMono';
        }

        .details {
            display: none;
            width: 100%;
            background: #222;
            margin-top: 50px;
        }

        .attribute {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 80%;
            margin-top: 20px;
			margin-left: 20px;
            font-size: 18px;
            font-family: 'JetBrainsMono';
        }

        .attribute input {
            border: none;
            background-color: transparent;
            color: #fff;
            font-size: 18px;
            border: 2px solid #333;
            font-family: 'JetBrainsMono';
        }

        .attribute input:focus {
            outline: none;
        }

		.attribute .key {
			width: 20%;
		}

        .table {
            max-width: 1500px;
        }

        table {
            width: 100%;
            max-width: 1800px;
            border-collapse: collapse;
            margin: 20px auto;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            text-align: center;
        }

        thead {
            background-color: transparent;
        }

        th {
            padding: 10px 0;
            border-bottom: 2px solid #fff;
        }

        tbody tr {
            background-color: transparent;
            border-bottom: 2px solid #fff;
        }

        tbody td {
            padding: 10px 0;
            border-bottom: 1px solid #fff;
        }

        .save {
            position: relative;
            left: 35%;
            width: 250px;
            background-color: #333;
            border: none;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            margin: 15px 20px;
            cursor: pointer;
            border-radius: 25px;
            font-family: 'JetBrainsMono';
        }

		.save:hover {
			background-color: rgba(55, 55, 55, 0.5);
		}
		
		.delete {
            position: relative;
            left: 55%;
            width: 100px;
            background-color: #333;
            border: none;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            margin: 15px 20px;
            cursor: pointer;
            border-radius: 25px;
            font-family: 'JetBrainsMono';
		}

		.delete:hover {
			background-color: rgba(55, 55, 55, 0.5);
		}
    </style>
</head>
<body>
<nav class="navbar">
    <a href="/dashboard"><i class="fas fa-layer-group"></i>Dashboard</a>
    <a href="/users"><i class="fas fa-user"></i>Users</a>
    <a href="/plan"><i class="fas fa-book"></i>Plan</a>
    <a href="/config"><i class="fas fa-cog"></i>Config</a>
    <a href="/methods"><i class="fas fa-rss"></i>Methods</a>
    <a href="/history"><i class="fas fa-clock"></i>History</a>
    <a href="/attack"><i class="fas fa-bolt"></i>Attack</a>
	<a href="/shop"><i class="fas fa-shopping-cart"></i>Shop</a>
    <a href="/logout"><i class="fas fa-door-open logout"></i>Logout</a>
</nav>
<div class="hero">
    <h1 class="h1">User Managment</h1>
    <p>Here you can see and edit the Users</p>
	<p style="color: red; font-size: 16px; margin-bottom: 20px;">{{.}}</p>
</div>
{{#users}}
<script>
    function togglePanel(panel) {
        if (event.target.classList.contains('panel') || event.target.classList.contains('icon') || event.target.classList.contains('fas') || event.target.classList.contains('h2') || event.target.classList.contains('h3') ) {
            if (panel.querySelector('.icon i').classList.contains('fa-plus')) {
                panel.querySelector('.icon i').classList.remove('fa-plus');
                panel.querySelector('.icon i').classList.add('fa-minus');
            } else {
                panel.querySelector('.icon i').classList.remove('fa-minus');
                panel.querySelector('.icon i').classList.add('fa-plus');
            }
            panel.classList.toggle('active');
        }
        panel.style.marginBottom = panel.classList.contains('active') ? '520px' : '25px';
    }
</script>
</body>
</html>
`

func UserPage(w http.ResponseWriter, r *http.Request) {
	database.LogRequests("==== [ Requested Index Page ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Content-Length: %s", r.Header.Get("Content-Length")))
	database.LogRequests(fmt.Sprintf("Content-Type: %s", r.Header.Get("Content-Type")))
	database.LogRequests(fmt.Sprintf("Referer: %s", r.Header.Get("Referer")))
	database.LogRequests(fmt.Sprintf("Origin: %s", r.Header.Get("Origin")))
	database.LogRequests("=================================")
	var _Temp string
	username, _ := Auth(w, r)
	user := database.GetUser(username)
	if r.Method == "POST" {
		if r.FormValue("save") == "Save" {
			Username := r.FormValue("username")
			Key := r.FormValue("key")
			Plan := r.FormValue("plan")
			Expiry := r.FormValue("expiry")
			Cooldown := r.FormValue("cooldown")
			Threads := r.FormValue("threads")
			Cons := r.FormValue("cons")
			MaxTime := r.FormValue("maxtime")
			Banned := r.FormValue("banned")
			if Username != "" && Plan != "" && Expiry != "" && Cooldown != "" && Threads != "" && Cons != "" && MaxTime != "" && Banned != "" && !database.CheckChars(Username) && !database.CheckChars(Key) && !database.CheckChars(Plan) && !database.CheckChars(Expiry) && !database.CheckChars(Cooldown) && !database.CheckChars(Threads) && !database.CheckChars(Cons) && !database.CheckChars(MaxTime) && !database.CheckChars(Banned) {
				var err error
				user := database.GetUser(Username)
				user.Username = Username
				if Key != "" {
					user.Key = Key
				} else {
					user.Key = database.GenerateKey()
				}
				user.Plan = Plan
				user.Expiry = Expiry
				user.Cooldown, err = strconv.Atoi(Cooldown)
				user.Threads, err = strconv.Atoi(Threads)
				user.Concurrent, err = strconv.Atoi(Cons)
				user.MaxTime, err = strconv.Atoi(MaxTime)
				user.Banned, err = strconv.Atoi(Banned)
				user.Username = Username
				if Key != "" {
					user.Key = Key
				} else {
					user.Key = database.GenerateKey()
				}
				user.Plan = Plan
				user.Expiry = Expiry
				user.Cooldown, err = strconv.Atoi(Cooldown)
				user.Threads, err = strconv.Atoi(Threads)
				user.Concurrent, err = strconv.Atoi(Cons)
				user.MaxTime, err = strconv.Atoi(MaxTime)
				user.Banned, err = strconv.Atoi(Banned)
				if database.CheckError(err) {
					http.Redirect(w, r, "/users?error=invalid_input", 302)
					return
				}
				if database.GetUser(Username).Username == "" {
					_err := database.CreateUser(user)
					if !_err {
						http.Redirect(w, r, "/users?error=create_failed", 302)
						return
					}
				} else {
					_err := database.UpdateUserStruct(user)
					if !_err {
						http.Redirect(w, r, "/users?error=update_failed", 302)
						return
					}
				}
				database.SendLog("\r\n**User " + user.Username + " has been updated by " + username + "**\r\n\r\n**Username**: \r\n" + user.Username + "\r\n**Key**: \r\n" + user.Key + "\r\n**Plan**: \r\n" + user.Plan + "\r\n**Expiry**: \r\n" + user.Expiry + "\r\n**Cooldown**: \r\n" + strconv.Itoa(user.Cooldown) + "\r\n**Threads**: \r\n" + strconv.Itoa(user.Threads) + "\r\n**Concurrent**: \r\n" + strconv.Itoa(user.Concurrent) + "\r\n**MaxTime**: \r\n" + strconv.Itoa(user.MaxTime) + "\r\n**Banned**: \r\n" + strconv.Itoa(user.Banned) + "\r\n")
				http.Redirect(w, r, "/users?error=false", 302)
				return
			}
			http.Redirect(w, r, "/users?error=emptyStrings", 302)
			return
		} else if r.FormValue("delete") == "Delete" {
			Username := r.FormValue("username")
			if Username != "" && !database.CheckChars(Username) {
				_err := database.RemoveUser(Username)
				if !_err {
					http.Redirect(w, r, "/users?error=delete_failed", 302)
					return
				}
				database.SendLog("\r\n**User " + Username + " has been deleted by " + username + "**\r\n\r\n**Username**: \r\n" + Username + "\r\n")
				http.Redirect(w, r, "/users?error=false", 302)
				return
			}
			http.Redirect(w, r, "/users?error=emptyStrings", 302)
			return
		} else {
			http.Redirect(w, r, "/users?error=invalid_input", 302)
			return
		}
	}
	if user.Plan != "Admin" {
		_Temp = strings.Replace(userTEMP, "<a href=\"/users\"><i class=\"fas fa-user\"></i>Users</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/config\"><i class=\"fas fa-cog\"></i>Config</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/methods\"><i class=\"fas fa-rss\"></i>Methods</a>", "", 1)
		_Temp = strings.Replace(_Temp, "width: 42%;", "width: 30%;", 1)
	} else {
		_Temp = userTEMP
	}

	if r.URL.Query().Get("error") == "emptyStrings" {
		_Temp = strings.NewReplacer("{{.}}", "Please fill out all fields!").Replace(_Temp)
	} else if r.URL.Query().Get("error") == "invalid_input" {
		_Temp = strings.NewReplacer("{{.}}", "Invalid input!").Replace(_Temp)
	} else if r.URL.Query().Get("error") == "update_failed" {
		_Temp = strings.NewReplacer("{{.}}", "Failed to update user!").Replace(_Temp)
	} else if r.URL.Query().Get("error") == "false" {
		_Temp = strings.NewReplacer("{{.}}", "Successfully updated user!").Replace(_Temp)
		_Temp = strings.Replace(_Temp, "color: red;", "color: green;", 1)
	} else if r.URL.Query().Get("error") == "delete_failed" {
		_Temp = strings.NewReplacer("{{.}}", "Failed to delete user!").Replace(_Temp)
	} else if r.URL.Query().Get("error") == "create_failed" {
		_Temp = strings.NewReplacer("{{.}}", "Failed to create user!").Replace(_Temp)
	} else {
		_Temp = strings.NewReplacer("{{.}}", "").Replace(_Temp)
	}

	var _Users string
	for _, user := range database.Users {
		_Users += fmt.Sprintf(`
<div class="panel-container">
    <div class="panel" onclick="togglePanel(this)">
        <div class="icon"><i class="fas fa-plus"></i></div>
        <h2 class="h2">%s</h2>
        <p class="h3">Click to see Details</p>
        <div class="details">
			<form method="post">
				<div class="attribute">
					<label for="username">Username</label>
					<input type="text" name="username" id="username" value="%s">
				</div>
				<div class="attribute">
					<label for="key">Key</label>
					<input type="text" name="key" id="key" value="%s">
				</div>
				<div class="attribute">
					<label for="plan">Plan</label>
					<input type="text" name="plan" id="plan" value="%s">
				</div>
				<div class="attribute">
					<label for="expiry">Expiry</label>
					<input type="text" name="expiry" id="expiry" value="%s">
				</div>
				<div class="attribute">
					<label for="cooldown">Cooldown</label>
					<input type="text" name="cooldown" id="cooldown" value="%d">
				</div>
				<div class="attribute">
					<label for="threads">Threads</label>
					<input type="text" name="threads" id="threads" value="%d">
				</div>
				<div class="attribute">
					<label for="cons">Cons</label>
					<input type="text" name="cons" id="cons" value="%d">
				</div>
				<div class="attribute">
					<label for="maxtime">MaxTime</label>
					<input type="text" name="maxtime" id="maxtime" value="%d">
				</div>
				<div class="attribute">
					<label for="banned">Banned</label>
					<input type="text" name="banned" id="banned" value="%d">
				</div>
				<input class="save" type="submit" name="save" id="save" value="Save">
				<input class="delete" type="submit" name="delete" id="delete" value="Delete">
			</form>
        </div>
    </div>
</div>
`, user.Username, user.Username, user.Key, user.Plan, user.Expiry, user.Cooldown, user.Threads, user.Concurrent, user.MaxTime, user.Banned)
	}
	_Users += `
<div class="panel-container">
    <div class="panel" onclick="togglePanel(this)">
        <div class="icon"><i class="fas fa-plus"></i></div>
        <h2 class="h2">New User</h2>
        <p class="h3">Click & Edit to Create</p>
        <div class="details">
			<form method="post">
				<div class="attribute">
					<label for="username">Username</label>
					<input type="text" name="username" id="username" value="" placeholder="e.g ClaasCode">
				</div>
				<div class="attribute">
					<label for="key">Key</label>
					<input type="text" name="key" id="key" value="" placeholder="(Leave empty to randomly generate)">
				</div>
				<div class="attribute">
					<label for="plan">Plan</label>
					<input type="text" name="plan" id="plan" value="" placeholder="e.g User">
				</div>
				<div class="attribute">
					<label for="expiry">Expiry</label>
					<input type="text" name="expiry" id="expiry" value="" placeholder="e.g 30-01-2025">
				</div>
				<div class="attribute">
					<label for="cooldown">Cooldown</label>
					<input type="text" name="cooldown" id="cooldown" value="" placeholder="e.g 30">
				</div>
				<div class="attribute">
					<label for="threads">Threads</label>
					<input type="text" name="threads" id="threads" value="" placeholder="e.g 2">
				</div>
				<div class="attribute">
					<label for="cons">Cons</label>
					<input type="text" name="cons" id="cons" value="" placeholder="e.g 2">
				</div>
				<div class="attribute">
					<label for="maxtime">MaxTime</label>
					<input type="text" name="maxtime" id="maxtime" value="" placeholder="e.g 300">
				</div>
				<div class="attribute">
					<label for="banned">Banned</label>
					<input type="text" name="banned" id="banned" value="" placeholder="e.g 0">
				</div>
				<input class="save" type="submit" name="save" id="save" value="Save">
			</form>
        </div>
    </div>
</div>`
	_, err := strings.NewReplacer("{{#users}}", _Users).WriteString(w, _Temp)
	if database.CheckError(err) {
		return
	}
}
