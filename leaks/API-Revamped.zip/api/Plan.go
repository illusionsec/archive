package api

import (
	"Manager/database"
	"fmt"
	"net/http"
	"strconv"
	"strings"
)

var planTEMP = NAV + `
<style>
        .panel-container {
            display: flex;
            justify-content: center;
            margin-bottom: 50px;
        }

        .panel {
            width: 20%;
            height: 450px;
            margin: 0 75px 0 75px;
            background-color: #222;
            border-radius: 25px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            position: relative;
        }

        .icon {
            position: absolute;
            top: 20px;
            right: 10px;
            font-size: 85px;
            color: #000;
            background-size: contain;
            background-repeat: no-repeat;
            opacity: 0.5;
        }

        .h2, .h3, .count {
            text-align: center;
            margin: 0;
            position: absolute;
            top: 15%;
        }

        .h2 {
            font-size: 32px;
        }

        .h3 {
            font-size: 20px;
            color: #999;
            top: 25%;
            font-family: 'JetBrainsMono';
        }

        .count {
            font-size: 40px;
            color: #999;
			background: transparent;
			border: none;
         	border: none;
            outline: none;
            user-select: none;
            top: 55%;
            font-family: 'JetBrainsMono';
        }

		.toggle-icon {
		  position: absolute;
		  top: 60%;
		  right: 12px;
		  font-size: 25px;
		  color: #999;
		  cursor: pointer;
		}
		
        .pwcount[type="password"] {
			max-width: 200px;
            letter-spacing: 0.1em;
        }

        .pwcount[type="text"] {
            letter-spacing: normal;
        }
    </style>
</head>
<body>
<nav class="navbar">
    <a href="/dashboard"><i class="fas fa-layer-group"></i>Dashboard</a>
    <a href="/users"><i class="fas fa-user"></i>Users</a>
    <a href="/plan"><i class="fas fa-book"></i>Plan</a>
    <a href="/config"><i class="fas fa-cog"></i>Config</a>
    <a href="/methods"><i class="fas fa-rss"></i>Methods</a>
    <a href="/history"><i class="fas fa-clock"></i>History</a>
    <a href="/attack"><i class="fas fa-bolt"></i>Attack</a>
	<a href="/shop"><i class="fas fa-shopping-cart"></i>Shop</a>
    <a href="/logout"><i class="fas fa-door-open logout"></i>Logout</a>
</nav>

<div class="hero">
    <h1 class="h1">Your Account</h1>
	<p class="p">Here you can see your account information.</p>
</div>

<div class="panel-container">
    <div class="panel">
        <i class="fas fa-user icon"></i>
        <h2 class="h2">Username</h2>
        <h3 class="h3">Your Username</h3>
        <p class="count">{{user.username}}</p>
    </div>

    <div class="panel">
        <i class="fas fa-key icon"></i>
        <h2 class="h2">Key</h2>
        <h3 class="h3">Your Key</h3>
        <input class="count pwcount" type="password" value="{{user.key}}" readonly>
		<i class="fas fa-eye-slash toggle-icon"></i>
    </div>

    <div class="panel">
        <i class="fas fa-file icon"></i>
        <h2 class="h2">Plan</h2>
        <h3 class="h3">Your Plan</h3>
        <p class="count">{{user.plan}}</p>
    </div>

    <div class="panel">
        <i class="fas fa-calendar-day icon"></i>
        <h2 class="h2">Expiry</h2>
        <h3 class="h3">Date of Experation</h3>
        <p class="count">{{user.expiry}}</p>
    </div>
</div>

<div class="panel-container">
    <div class="panel">
        <i class="fas fa-wind icon"></i>
        <h2 class="h2">Concurrents</h2>
        <h3 class="h3">Your Concurrent Attacks</h3>
        <p class="count">{{user.cons}}
            /
            {{user.maxcons}}</p>
    </div>

    <div class="panel">
        <i class="fas fa-hourglass-half icon"></i>
        <h2 class="h2">Max Time</h2>
        <h3 class="h3">Your Maximum Time</h3>
        <p class="count">{{user.maxtime}}</p>
    </div>

    <div class="panel">
        <i class="fas fa-clock icon"></i>
        <h2 class="h2">Cooldown</h2>
        <h3 class="h3">Date of Experation</h3>
        <p class="count">{{user.cooldown}}</p>
    </div>

    <div class="panel">
        <i class="fas fa-layer-group icon"></i>
        <h2 class="h2">Threads</h2>
        <h3 class="h3">Amount of Threads</h3>
        <p class="count">{{user.threads}}</p>
    </div>

<script>
const toggleIcon = document.querySelector('.toggle-icon');
const passwordInput = document.querySelector('.pwcount');

toggleIcon.addEventListener('click', function() {
  if (passwordInput.type === 'password') {
    passwordInput.type = 'text';
    toggleIcon.classList.remove('fa-eye-slash');
    toggleIcon.classList.add('fa-eye');
  } else {
    passwordInput.type = 'password';
    toggleIcon.classList.remove('fa-eye');
    toggleIcon.classList.add('fa-eye-slash');
  }
});
</script>
</div>
</body>
</html>
`

func PlanPage(w http.ResponseWriter, r *http.Request) {
	database.LogRequests("==== [ Requested Plan Page ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Content-Length: %s", r.Header.Get("Content-Length")))
	database.LogRequests(fmt.Sprintf("Content-Type: %s", r.Header.Get("Content-Type")))
	database.LogRequests(fmt.Sprintf("Referer: %s", r.Header.Get("Referer")))
	database.LogRequests(fmt.Sprintf("Origin: %s", r.Header.Get("Origin")))
	database.LogRequests("=================================")
	var _Temp string
	username, _ := Auth(w, r)
	user := database.GetUser(username)
	if user.Plan != "Admin" {
		_Temp = strings.Replace(planTEMP, "<a href=\"/users\"><i class=\"fas fa-user\"></i>Users</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/config\"><i class=\"fas fa-cog\"></i>Config</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/methods\"><i class=\"fas fa-rss\"></i>Methods</a>", "", 1)
		_Temp = strings.Replace(_Temp, "width: 42%;", "width: 30%;", 1)
	} else {
		_Temp = planTEMP
	}
	_, err := strings.NewReplacer("{{user.username}}", user.Username, "{{user.threads}}", strconv.Itoa(user.Threads), "{{user.plan}}", user.Plan, "{{user.key}}", user.Key, "{{user.expiry}}", user.Expiry, "{{user.cons}}", strconv.Itoa(database.GetActiveConsUser(username)), "{{user.maxcons}}", strconv.Itoa(user.Concurrent), "{{user.maxtime}}", strconv.Itoa(user.MaxTime), "{{user.cooldown}}", strconv.Itoa(user.Cooldown)).WriteString(w, _Temp)
	if database.CheckError(err) {
		return
	}
}
