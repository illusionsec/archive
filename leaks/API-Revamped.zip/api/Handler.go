package api

import (
	"Manager/database"
	"fmt"
	"net/http"
	"strings"
)

func StartWebserver() {
	http.HandleFunc("/", IndexPage)
	http.HandleFunc("/plan", PlanPage)
	http.HandleFunc("/dashboard", Dashboard)
	http.HandleFunc("/history", HistoryPage)
	http.HandleFunc("/login", LoginPage)
	http.HandleFunc("/logout", Logout)
	http.HandleFunc("/attack", AttackPage)
	http.HandleFunc("/users", UserPage)
	http.HandleFunc("/shop", ShopPage)
	http.HandleFunc("/config", ConfigPage)
	http.HandleFunc("/methods", MethodPage)
	http.HandleFunc("/api/start", StartPage)
	err := http.ListenAndServe("0.0.0.0:"+fmt.Sprint(database.Config.Port), nil)
	database.CheckError(err)
}

func Auth(w http.ResponseWriter, r *http.Request) (string, bool) {
	session, err := r.Cookie("session")
	database.LogRequests("====== [ Authentication ] ======")
	database.LogRequests(fmt.Sprintf("Remote-IP: %s \r\n Requested-URI: %s", r.RemoteAddr, r.RequestURI))
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Full URL: %s", r.URL.String()))
	database.LogRequests(fmt.Sprintf("User-Agent: %s", r.UserAgent()))
	database.LogRequests(fmt.Sprintf("Method: %s", r.Method))
	database.LogRequests(fmt.Sprintf("User-Agent: %s", r.UserAgent()))
	database.LogRequests("================================")
	if database.CheckError(err) {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return "", false
	}
	if r.RequestURI == "/shop" {
		return "NEW", true
	}
	username := strings.Split(session.Value, " ")[0]
	key := strings.Split(session.Value, " ")[1]
	if database.CheckChars(username) || database.CheckChars(key) {
		http.Redirect(w, r, "/login?error=invalid_user", http.StatusSeeOther)
		return "", false
	}
	if database.Config.AdminOnlyWeb && database.GetUser(username).Plan != "Admin" {
		http.Redirect(w, r, "/login?error=invalid_user", http.StatusSeeOther)
		return "", false
	}
	if !database.Authenticate(username, key) {
		http.Redirect(w, r, "/login?error=invalid_user", http.StatusSeeOther)
		return "", false
	} else if database.GetUser(username).Banned > 0 {
		http.Redirect(w, r, "/login?error=banned", http.StatusSeeOther)
		return "", false
	} else if database.CheckExpiry(username) {
		http.Redirect(w, r, "/login?error=expired", http.StatusSeeOther)
		return "", false
	}
	if r.RequestURI == "/config" || r.RequestURI == "/methods" || r.RequestURI == "/users" {
		if database.GetUser(username).Plan != "Admin" {
			http.Redirect(w, r, "/dashboard", http.StatusSeeOther)
			return "", false
		}
	}
	return username, true
}

var NAV = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Manager</title>
    <script src="https://kit.fontawesome.com/3668f12ee4.js" crossorigin="anonymous"></script>
    <style>
        @import url('https://fonts.cdnfonts.com/css/cascadia-code');
        @font-face{
            font-family: 'JetBrainsMono';
            src: url('https://cdn.jsdelivr.net/gh/JetBrains/JetBrainsMono/web/woff2/JetBrainsMono-Regular.woff2') format('woff2'),
            url('https://cdn.jsdelivr.net/gh/JetBrains/JetBrainsMono/web/woff/JetBrainsMono-Regular.woff') format('woff'),
            url('https://cdn.jsdelivr.net/gh/JetBrains/JetBrainsMono/ttf/JetBrainsMono-Regular.ttf') format('truetype');
            font-weight: 400;
            font-style: normal;
        }
        body {
            background-color: #1a1a1a;
            color: #fff;
            font-family: 'Cascadia Code';
            margin: 0;
        }
        .navbar {
            margin: 0 auto;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 30px;
            background-color: #333;
            margin-bottom: 50px;
            padding: 15px 20px 15px;
            width: 42%;
            border-bottom-right-radius: 25px;
            border-bottom-left-radius: 25px;
            font-family: 'JetBrainsMono';
        }
        .navbar a {
            display: flex;
            justify-content: left;
            align-items: center;
            height: 100%;
            padding: 0 10px 10px;
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px;
            transition: all 0.5s ease;
        }

        .navbar a i {
            margin-right: 5px;
        }

        .navbar a:hover {
            font-size: 18px;
        }

        .hero {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 0 20px;
        }

        .hero .h1 {
            font-size: 45px;
            margin-bottom: 5px;
        }

        .hero p {
            font-size: 20px;
            margin-bottom: 50px;
        }

        ::-webkit-scrollbar {
            width: 10px;
            background-color: #333;
        }

        ::-webkit-scrollbar-thumb {
            background-color: #ccc;
            border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background-color: #aaa;
        }

        .logout {
            margin-left: 20px;
        }
	</style>
`
