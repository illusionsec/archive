package api

import (
	"Manager/database"
	"fmt"
	"net/http"
	"strings"
	"time"
)

var loginTEMP = NAV + `
<style>
      form {
         background-color: #333;
         padding: 20px;
         border-radius: 5px;
         font-size: 20px;
         width: 300px;
         margin: 0 auto;
         display: flex;
         flex-direction: column;
         align-items: left;
      }
      input[type="text"], input[type="password"] {
         padding: 10px;
         margin-bottom: 20px;
         background-color: transparent;
         border: none;
         border-bottom: 2px solid #fff;
         color: #fff;
         font-size: 16px;
         width: 100%;
         box-sizing: border-box;
         font-family: 'JetBrainsMono';
         transition: all 0.3s ease;
      }
      input[type="text"]:focus, input[type="password"]:focus {
         border-bottom-color: #ccc;
         outline: none;
      }
      input[type="password"]::-webkit-outer-spin-button, input[type="password"]::-webkit-inner-spin-button {
         -webkit-appearance: none;
         margin: 0;
      }
      input[type="password"] {
         -moz-appearance: textfield;
         width: 100%;
      }
      input[type="password"]::before {
         content: "\25CF\25CF\25CF\25CF\25CF\25CF\25CF\25CF";
         color: #fff;
         font-size: 16px;
         position: absolute;
         padding: 10px;
         display: inline-block;
         margin-top: -36px;
         margin-left: -4px;
         opacity: 0.7;
      }
      input[type="password"]:focus::before {
         opacity: 1;
      }
      input[type="submit"] {
         padding: 10px 50px;
         background-color: transparent;
         border: 2px solid #fff;
         color: #fff;
         font-size: 16px;
         align-items: center;
         border-radius: 5px;
         cursor: pointer;
         transition: all 0.3s ease;
      }
      input[type="submit"]:hover {
         background-color: #fff;
         color: #333;
      }
      h1 {
         text-align: center;
         margin-top: 50px;
         font-size: 40px;
         font-weight: bold;
         margin-bottom: 45px;
      }
    a {
        text-decoration: none;
        color: dodgerblue;
        font-size: 16px;
    }
    .registerText {
        margin-top: 20px;
        font-size: 16px;
    }
   </style>
</head>
<body>
   <h1>Login</h1>
   <form method="post">
      <label for="username">Username:</label>
      <input type="text" name="username" id="username">
      <label for="password">Key:</label>
      <input type="password" name="password" id="password">
		<p style="color: red; font-size: 16px; margin-bottom: 20px;">{{.}}</p>	
      <input type="submit" value="Login">
      <div class="registerText">Don't have an account?</div>
      <a href="/shop">Buy a Plan here.</a>
   </form>

   <script src="https://kit.fontawesome.com/1234567890.js" crossorigin="anonymous"></script>
</body>
</html>
`

func LoginPage(w http.ResponseWriter, r *http.Request) {
	database.LogRequests("==== [ Requested Login Page ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Content-Length: %s", r.Header.Get("Content-Length")))
	database.LogRequests(fmt.Sprintf("Content-Type: %s", r.Header.Get("Content-Type")))
	database.LogRequests(fmt.Sprintf("Referer: %s", r.Header.Get("Referer")))
	database.LogRequests(fmt.Sprintf("Origin: %s", r.Header.Get("Origin")))
	database.LogRequests("=================================")
	var _Temp string
	if r.Method == "POST" {
		username := r.FormValue("username")
		password := r.FormValue("password")
		if database.CheckChars(username) || database.CheckChars(password) {
			http.Redirect(w, r, "/login?error=true", http.StatusSeeOther)
			return
		}
		if !database.Config.AdminOnlyWeb {
			if database.Authenticate(username, password) {
				setSession(username, password, w)
				http.Redirect(w, r, "/dashboard", http.StatusSeeOther)
				return
			} else if database.CheckExpiry(username) {
				http.Redirect(w, r, "/login?error=expired", http.StatusSeeOther)
				return
			} else if database.GetUser(username).Username == "" {
				http.Redirect(w, r, "/login?error=invalid_user", http.StatusSeeOther)
				return
			} else if database.GetUser(username).Banned > 0 {
				http.Redirect(w, r, "/login?error=banned", http.StatusSeeOther)
				return
			} else {
				http.Redirect(w, r, "/login?error=true", http.StatusSeeOther)
				return
			}
		} else {
			if database.GetUser(username).Plan == "Admin" {
				if database.Authenticate(username, password) {
					setSession(username, password, w)
					http.Redirect(w, r, "/dashboard", http.StatusSeeOther)
					return
				} else {
					http.Redirect(w, r, "/login?error=true", http.StatusSeeOther)
					return
				}
			} else {
				http.Redirect(w, r, "/login?error=true", http.StatusSeeOther)
				return
			}
		}

	}

	if r.URL.Query().Get("error") == "invalid_user" {
		_Temp = strings.NewReplacer("{{.}}", "User doesn't exist.").Replace(loginTEMP)
	} else if r.URL.Query().Get("error") == "banned" {
		_Temp = strings.NewReplacer("{{.}}", "You are banned from using this service.").Replace(loginTEMP)
	} else if r.URL.Query().Get("error") == "true" {
		_Temp = strings.NewReplacer("{{.}}", "Invalid username or key.").Replace(loginTEMP)
	} else if r.URL.Query().Get("error") == "expired" {
		_Temp = strings.NewReplacer("{{.}}", "Your key has expired.").Replace(loginTEMP)
	} else {
		_Temp = strings.NewReplacer("{{.}}", "").Replace(loginTEMP)
	}
	w.WriteHeader(http.StatusOK)
	_, err := w.Write([]byte(_Temp))
	database.CheckError(err)
}

func setSession(username string, key string, w http.ResponseWriter) {
	expiration := time.Now().Add(6 * time.Hour)
	cookie := http.Cookie{Name: "session", Value: username + " " + key, Expires: expiration}
	http.SetCookie(w, &cookie)
}
