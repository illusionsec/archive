package api

import (
	"Manager/database"
	"fmt"
	"net/http"
	"strconv"
	"strings"
)

var configTEMP = NAV + `
<style>
.panel-container {
            display: flex;
            justify-content: center;
        }

        .panel {
            width: 70%;
            height: 1750px;
            margin: 0 75px 25px 75px;
            background-color: #222;
            border-radius: 25px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            position: relative;
            cursor: pointer;
            text-align: left;
        }

        .icon {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 65px;
            color: #fff;
            background-size: contain;
            background-repeat: no-repeat;
            opacity: 0.5;
        }

        .h2, .h3 {
            margin: 0;
            position: absolute;
            top: 1%;
        }

        .h2 {
            left: 40%;
            font-size: 32px;
        }

        .h3 {
            font-size: 20px;
            color: #999;
            top: 25%;
            align-items: Center;
            font-family: 'JetBrainsMono';
        }

        .qbot {
            margin: 25px 0 25px 600px;
            padding-bottom: 15px;
            left: 85%;
            font-size: 32px;
        }

        .mirai {
            margin: 25px 0 25px 600px;
            padding-bottom: 15px;
            left: 85%;
            font-size: 32px;
        }

        .details {
            width: 100%;
            background: #222;
            margin-top: 85px;
        }

        .attribute {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 80%;
            margin-top: 20px;
            margin-left: 20px;
            font-size: 18px;
            font-family: 'JetBrainsMono';
        }

        .attribute input {
            width: 50%;
            background-color: transparent;
            color: #fff;
            font-size: 18px;
            border: 2px solid #333;
            font-family: 'JetBrainsMono';
        }

        .attribute input:focus {
            outline: none;
        }

        .save {
            top: 95%;
            position: absolute;
            left: 40%;
            width: 250px;
            background-color: #333;
            border: none;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            margin: 20px 20px;
            cursor: pointer;
            border-radius: 25px;
            font-family: 'JetBrainsMono';
        }

        .save:hover {
            background-color: rgba(55, 55, 55, 0.5);
        }

        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
            margin: 10px;
        }

        .toggle-input {
            display: none;
        }

        .toggle-label {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
            background-color: rgba(55, 55, 55, 0.5);
            border-radius: 34px;
            transition: background-color 0.2s;
        }

        .toggle-label:before {
            content: "";
            position: absolute;
            top: 2px;
            right: 2px;
            width: 30px;
            height: 30px;
            background-color: #fff;
            border-radius: 50%;
            transition: transform 0.2s;
        }

        .toggle-input:checked + .toggle-label {
            background-color: rgba(22, 22, 22, 1);
        }

        .toggle-input:checked + .toggle-label:before {
            transform: translateX(-26px);
        }

        .attribute textarea {
            width: 50%;
            min-height: 80px;
            font-size: 18px;
            color: white;
            background-color: transparent;
            border-radius: 5px;
            border: 2px solid #333;
            resize: vertical;
        }

    </style>
</head>
<body>
   <nav class="navbar">
      <a href="/dashboard"><i class="fas fa-layer-group"></i>Dashboard</a>
      <a href="/users"><i class="fas fa-user"></i>Users</a>
	  <a href="/plan"><i class="fas fa-book"></i>Plan</a>
      <a href="/config"><i class="fas fa-cog"></i>Config</a>
      <a href="/methods"><i class="fas fa-rss"></i>Methods</a>
      <a href="/history"><i class="fas fa-clock"></i>History</a>
      <a href="/attack"><i class="fas fa-bolt"></i>Attack</a>
	  <a href="/shop"><i class="fas fa-shopping-cart"></i>Shop</a>

      <a href="/logout"><i class="fas fa-door-open logout"></i>Logout</a>
   </nav>
<div class="hero">
    <h1 class="h1">Config</h1>
    <p class="p">Here you can Manage your Config</p>
	<p style="color: red; font-size: 16px; margin-bottom: 20px;">{{.}}</p>
</div>

<div class="panel-container">
    <div class="panel">
        <div class="icon"><i class="fas fa-cog"></i></div>
        <h2 class="h2">Configuration</h2>
        <p class="h3"></p>
        <div class="details">
            <form method="post">
                <div class="attribute">
                    <label for="port">Port</label>
                    <input type="text" name="port" id="port" value="{{config.port}}" placeholder="e.g 80">
                </div>
                <div class="attribute">
                    <label for="maxtime">Global Time</label>
                    <input type="text" name="maxtime" id="maxtime" value="{{config.maxtime}}" placeholder="e.g 120">
                </div>
                <div class="attribute">
                    <label for="maxcon">Global Concurrents</label>
                    <input type="text" name="maxcon" id="maxcon" value="{{config.maxcon}}" placeholder="e.g 20">
                </div>
                <div class="attribute">
                    <label for="ipinfo">IPInfo Token</label>
                    <input type="text" name="ipinfo" id="ipinfo" value="{{config.ipinfo}}" placeholder="TOKEN FROM https://ipinfo.io/">
                </div>
                <div class="attribute">
                    <label for="telegrambot">Telegram Bot Token</label>
                    <input type="text" name="telegrambot" id="telegrambot" value="{{config.telegrambot}}" placeholder="BOT TOKEN HERE">
                </div>
                <div class="attribute">
                    <label for="telegramchat">Telegram Chat</label>
                    <input type="text" name="telegramchat" id="telegramchat" value="{{config.telegramchat}}" placeholder="e.g @QuakeNetworks">
                </div>
                <div class="attribute">
                    <label for="discordhook">Discord Webhook</label>
                    <input type="text" name="discordhook" id="discordhook" value="{{config.discordhook}}" placeholder="WEBHOOK HERE">
                </div>
                <div class="attribute">
                    <label for="discordbot">Discord Bot Token</label>
                    <input type="text" name="discordbot" id="discordbot" value="{{config.discordbot}}" placeholder="BOT TOKEN HERE">
                </div>
                <div class="attribute">
                    <label for="license">License</label>
                    <input type="text" name="license" id="license" value="{{config.license}}" placeholder="e.g License123">
                </div>
                <div class="attribute">
                    <label for="blacklist">Blacklist</label>
                    <textarea type="text" name="blacklist" id="blacklist" placeholder="70.70.70.75&#10;gov">{{config.blacklist}}</textarea>
                </div>
                <div class="attribute">
                    <label for="blacklistedport">Blacklisted Ports</label>
                    <textarea type="text" name="blacklistedport" id="blacklistedport" placeholder="22&#10;1999">{{config.blacklistedports}}</textarea>
                </div>
                <div class="attribute">
                    <label for="whitelist">Whitelist</label>
                    <textarea type="text" name="whitelist" id="whitelist" placeholder="45.142.114.179&#10;1.1.1.1">{{config.whitelist}}</textarea>
                </div>
                <div class="attribute">
                    <label for="powersaving">Powersaving</label>
                    <div class="toggle-switch">
                        <input type="checkbox" class="toggle-input" name="powersaving" id="powersaving" {{config.powersaving}}>
                        <label class="toggle-label" for="powersaving"></label>
                    </div>
                </div>
                <div class="attribute">
                    <label for="debug">Debug</label>
                    <div class="toggle-switch">
                        <input type="checkbox" class="toggle-input" name="debug" id="debug" {{config.debug}}>
                        <label class="toggle-label" for="debug"></label>
                    </div>
                </div>
                <h2 class="qbot">Qbot</h2>
                <div class="attribute">
                    <label for="qbothost">Listener Host</label>
                    <input type="text" name="qbothost" id="qbothost" value="{{config.qbothost}}" placeholder="e.g 0.0.0.0">
                </div>
                <div class="attribute">
                    <label for="qbotport">Listener Port</label>
                    <input type="text" name="qbotport" id="qbotport" value="{{config.qbotport}}" placeholder="e.g 2020">
                </div>
                <div class="attribute">
                    <label for="qbotdupes">Allow Duplicates</label>
                    <div class="toggle-switch">
                        <input type="checkbox" class="toggle-input" name="qbotdupes" id="qbotdupes" {{config.qbotdupes}}>
                        <label class="toggle-label" for="qbotdupes"></label>
                    </div>
                </div>
                <div class="attribute">
                    <label for="qbotenabled">Enabled</label>
                    <div class="toggle-switch">
                        <input type="checkbox" class="toggle-input" name="qbotenabled" id="qbotenabled" {{config.qbotenabled}}>
                        <label class="toggle-label" for="qbotenabled"></label>
                    </div>
                </div>
                <h2 class="mirai">Mirai</h2>
                <div class="attribute">
                    <label for="miraihost">Listener Host</label>
                    <input type="text" name="miraihost" id="miraihost" value="{{config.miraihost}}" placeholder="e.g 0.0.0.0">
                </div>
                <div class="attribute">
                    <label for="miraiport">Listener Port</label>
                    <input type="text" name="miraiport" id="miraiport" value="{{config.miraiport}}" placeholder="e.g 2055">
                </div>
                <div class="attribute">
                    <label for="miraidupes">Allow Duplicates</label>
                    <div class="toggle-switch">
                        <input type="checkbox" class="toggle-input" name="miraidupes" id="miraidupes" {{config.miraidupes}}>
                        <label class="toggle-label" for="miraidupes"></label>
                    </div>
                </div>
                <div class="attribute">
                    <label for="miraienabled">Enabled</label>
                    <div class="toggle-switch">
                        <input type="checkbox" class="toggle-input" name="miraienabled" id="miraienabled" {{config.miraienabled}}>
                        <label class="toggle-label" for="miraienabled"></label>
                    </div>
                </div>
                <input type="submit" value="Save" class="save" text="Save">
            </form>
        </div>
    </div>
</div>
</body>
</html>`

func ConfigPage(w http.ResponseWriter, r *http.Request) {
	database.LogRequests("==== [ Requested Config Page ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests(fmt.Sprintf("Content-Length: %s", r.Header.Get("Content-Length")))
	database.LogRequests(fmt.Sprintf("Content-Type: %s", r.Header.Get("Content-Type")))
	database.LogRequests(fmt.Sprintf("Referer: %s", r.Header.Get("Referer")))
	database.LogRequests(fmt.Sprintf("Origin: %s", r.Header.Get("Origin")))
	database.LogRequests("=================================")
	var _Temp string
	username, _ := Auth(w, r)
	user := database.GetUser(username)
	if user.Plan != "Admin" {
		_Temp = strings.Replace(configTEMP, "<a href=\"/users\"><i class=\"fas fa-user\"></i>Users</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/config\"><i class=\"fas fa-cog\"></i>Config</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/methods\"><i class=\"fas fa-rss\"></i>Methods</a>", "", 1)
		_Temp = strings.Replace(_Temp, "width: 42%;", "width: 30%;", 1)
	} else {
		_Temp = configTEMP
	}

	if r.Method == "POST" {
		var err error
		database.Config.Port, err = strconv.Atoi(r.FormValue("port"))
		database.Config.MaxTime, err = strconv.Atoi(r.FormValue("maxtime"))
		database.Config.MaxCons, err = strconv.Atoi(r.FormValue("maxcon"))
		database.Config.IPInfo = r.FormValue("ipinfo")
		database.Config.TelegramBot = r.FormValue("telegrambot")
		database.Config.TelegramChat = r.FormValue("telegramchat")
		database.Config.DiscordWeb = r.FormValue("discordhook")
		database.Config.DiscordBot = r.FormValue("discordbot")
		if len(r.FormValue("blacklist")) > 0 {
			database.Config.Blacklist = []string{}
			for _, value := range strings.Split(r.FormValue("blacklist"), "\r\n") {
				database.Config.Blacklist = append(database.Config.Blacklist, value)
			}
		} else {
			database.Config.Blacklist = []string{}
		}
		if len(r.FormValue("blacklistedport")) > 0 {
			database.Config.BlacklistedPort = []string{}
			for _, value := range strings.Split(r.FormValue("blacklistedport"), "\r\n") {
				database.Config.BlacklistedPort = append(database.Config.BlacklistedPort, value)
			}
		} else {
			database.Config.BlacklistedPort = []string{}
		}
		if r.FormValue("powersaving") == "on" {
			database.Config.Powersaving = false
		} else {
			database.Config.Powersaving = true
		}
		if r.FormValue("debug") == "on" {
			database.Config.Debug = false
		} else {
			database.Config.Debug = true
		}
		database.Config.QBot.Host = r.FormValue("qbothost")
		database.Config.QBot.Port, err = strconv.Atoi(r.FormValue("qbotport"))
		if r.FormValue("qbotdupes") == "on" {
			database.Config.QBot.Dupes = false
		} else {
			database.Config.QBot.Dupes = true
		}
		if r.FormValue("qbotenabled") == "on" {
			database.Config.QBot.Enabled = false
		} else {
			database.Config.QBot.Enabled = true
		}
		database.Config.Mirai.Host = r.FormValue("miraihost")
		database.Config.Mirai.Port, err = strconv.Atoi(r.FormValue("miraiport"))
		if r.FormValue("miraidupes") == "on" {
			database.Config.Mirai.Dupes = false
		} else {
			database.Config.Mirai.Dupes = true
		}
		if r.FormValue("miraienabled") == "on" {
			database.Config.Mirai.Enabled = false
		} else {
			database.Config.Mirai.Enabled = true
		}
		if database.CheckError(err) {
			http.Redirect(w, r, "/config?error=invalid_input", http.StatusSeeOther)
			return
		}
		database.SaveConfig()
		database.LoadConfig()
		http.Redirect(w, r, "/config?error=false", http.StatusSeeOther)
	}
	if r.URL.Query().Get("error") == "invalid_input" {
		_Temp = strings.NewReplacer("{{.}}", "Please try again!").Replace(_Temp)
	} else if r.URL.Query().Get("error") == "false" {
		_Temp = strings.NewReplacer("{{.}}", "Saved!").Replace(_Temp)
		_Temp = strings.Replace(_Temp, "color: red;", "color: green;", 1)
	} else {
		_Temp = strings.NewReplacer("{{.}}", "").Replace(_Temp)
	}
	config := database.Config
	powersaving := ""
	debug := ""
	qbotEnabled := ""
	miraiEnabled := ""
	qbotDupes := ""
	miraiDupes := ""
	if config.Powersaving {
		powersaving = ""
	} else {
		powersaving = "checked"
	}
	if config.Debug {
		debug = ""
	} else {
		debug = "checked"
	}
	if config.QBot.Enabled {
		qbotEnabled = ""
	} else {
		qbotEnabled = "checked"
	}
	if config.Mirai.Enabled {
		miraiEnabled = ""
	} else {
		miraiEnabled = "checked"
	}
	if config.QBot.Dupes {
		qbotDupes = ""
	} else {
		qbotDupes = "checked"
	}
	if config.Mirai.Dupes {
		miraiDupes = ""
	} else {
		miraiDupes = "checked"
	}
	_, err := strings.NewReplacer("{{config.port}}", strconv.Itoa(config.Port), "{{config.maxtime}}", strconv.Itoa(config.MaxTime), "{{config.maxcon}}", strconv.Itoa(config.MaxCons), "{{config.ipinfo}}", config.IPInfo, "{{config.telegrambot}}", config.TelegramBot, "{{config.telegramchat}}", config.TelegramChat, "{{config.discordhook}}", config.DiscordWeb, "{{config.discordbot}}", config.DiscordBot, "{{config.blacklist}}", strings.Join(config.Blacklist, "\r\n"), "{{config.blacklistedports}}", strings.Join(config.BlacklistedPort, "\r\n"), "{{config.whitelist}}", strings.Join(config.Whitelist, "\r\n"), "{{config.powersaving}}", powersaving, "{{config.debug}}", debug, "{{config.qbothost}}", config.QBot.Host, "{{config.qbotport}}", strconv.Itoa(config.QBot.Port), "{{config.qbotdupes}}", qbotDupes, "{{config.qbotenabled}}", qbotEnabled, "{{config.miraihost}}", config.Mirai.Host, "{{config.miraiport}}", strconv.Itoa(config.Mirai.Port), "{{config.miraidupes}}", miraiDupes, "{{config.miraienabled}}", miraiEnabled).WriteString(w, _Temp)
	database.CheckError(err)
}
