package api

import (
	"Manager/database"
	"net/http"
	"strconv"
	"strings"
)

var dashboardTEMP = NAV + `
<style>
      .panel-container {
        display: flex;
        justify-content: center;
      }

      .panel {
        width: 20%;
        height: 450px;
        margin: 0 75px 0 75px;
        background-color: #222;
        border-radius: 25px;
        box-shadow: 0 0 10px rgba(0,0,0,0.2);
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: center;
        position: relative;
      }

      .icon {
        position: absolute;
        top: 20px;
        right: 10px;
        font-size: 85px;
		color: #000;
        background-size: contain;
        background-repeat: no-repeat;
        opacity: 0.5;
      }

      .icon1 {
		font-size: 70px;
      }

      .h2, .h3, .count {
        text-align: center;
        margin: 0;
        position: absolute;
        top: 15%;
      }

      .h2 {
        font-size: 32px;
      }

      .h3 {
        font-size: 20px;
        color: #999;
        top: 25%;
        font-family: 'JetBrainsMono';
      }

      .count {
		font-size: 40px;
        color: #999;
        top: 55%;
        font-family: 'JetBrainsMono';
      }

      .logout {
	     margin-left: 20px;
	  }
   </style>
</head>
<body>
   <nav class="navbar">
      <a href="/dashboard"><i class="fas fa-layer-group"></i>Dashboard</a>
      <a href="/users"><i class="fas fa-user"></i>Users</a>
	  <a href="/plan"><i class="fas fa-book"></i>Plan</a>
      <a href="/config"><i class="fas fa-cog"></i>Config</a>
      <a href="/methods"><i class="fas fa-rss"></i>Methods</a>
      <a href="/history"><i class="fas fa-clock"></i>History</a>
      <a href="/attack"><i class="fas fa-bolt"></i>Attack</a>
	  <a href="/shop"><i class="fas fa-shopping-cart"></i>Shop</a>

      <a href="/logout"><i class="fas fa-door-open logout"></i>Logout</a>
   </nav>

   <div class="hero">
      <h1 class="h1">Dashboard</h1>
      <p>Welcome back {{user.username}}</p>
   </div>

   <div class="panel-container">
      <div class="panel">
        <i class="fas fa-user icon"></i>
        <h2 class="h2">Users</h2>
        <h3 class="h3">Total User Count</h3>
        <p class="count">{{user.count}}</p>
      </div>

      <div class="panel">
        <i class="fas fa-rss icon"></i>
        <h2 class="h2">Methods</h2>
        <h3 class="h3">Total Methods Count</h3>
        <p class="count">{{method.count}}</p>
      </div>

      <div class="panel">
        <i class="fas fa-network-wired icon icon1"></i>
        <h2 class="h2">Network</h2>
        <h3 class="h3">Total Network Load</h3>
        <p class="count">{{network.load}}</p>
      </div>

      <div class="panel">
        <i class="fas fa-bolt icon"></i>
        <h2 class="h2">Attacks</h2>
        <h3 class="h3">Total Attack Count</h3>
        <p class="count">{{attack.count}}</p>
      </div>
   </div>
</body>
</html>
`

func Dashboard(w http.ResponseWriter, r *http.Request) {
	database.LogRequests("==== [ Requested Dashboard Page ] ====")
	database.LogRequests("IP: " + r.RemoteAddr)
	database.LogRequests("Method: " + r.Method)
	database.LogRequests("User-Agent: " + r.UserAgent())
	database.LogRequests("Full URL: " + r.URL.String())
	database.LogRequests("Query: " + r.URL.RawQuery)
	database.LogRequests("=================================")
	var _Temp string
	username, _ := Auth(w, r)
	user := database.GetUser(username)
	if user.Plan != "Admin" {
		_Temp = strings.Replace(dashboardTEMP, "<a href=\"/users\"><i class=\"fas fa-user\"></i>Users</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/config\"><i class=\"fas fa-cog\"></i>Config</a>", "", 1)
		_Temp = strings.Replace(_Temp, "<a href=\"/methods\"><i class=\"fas fa-rss\"></i>Methods</a>", "", 1)
		_Temp = strings.Replace(_Temp, "width: 42%;", "width: 30%;", 1)
	} else {
		_Temp = dashboardTEMP
	}
	loadstr := strconv.Itoa(int(database.GetLoad())) + "%"
	_, err := strings.NewReplacer("{{network.load}}", loadstr, "{{user.username}}", user.Username, "{{user.count}}", strconv.Itoa(len(database.Users)), "{{method.count}}", strconv.Itoa(len(database.Methods.Methods)), "{{attack.count}}", strconv.Itoa(len(database.Attacks))).WriteString(w, _Temp)
	if database.CheckError(err) {
		return
	}
}
