#pragma once

#define HTTP_SERVER "193.35.18.172"
#define HTTP_PORT 80

#define TFTP_SERVER "193.35.18.172"
