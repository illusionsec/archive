package main

import "net"
import "time"

func main() {
	for {
		conn, err := net.Dial("tcp", SERVER_ADDRESS)
		if err != nil {
			continue
		}
		client := NewClient(conn)
		client.Handle()
		time.Sleep(1 * time.Second)
	}
}
