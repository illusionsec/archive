package main

import (
	"context"
	"time"
)

type routine func()

func TimedRoutine(routine routine, amount int, timeout time.Duration, delay int) {

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*time.Duration(timeout))

	for i := 0; i < amount; i++ {
		go func() {
			for {
				select {
				case <-ctx.Done():
					return
				default:
					routine()
				}
				if delay != -1 {
					time.Sleep(time.Duration(delay))
				}
			}
		}()
	}

	select {
	case <-ctx.Done():
		return
	case <-time.After(time.Second * time.Duration(timeout)):
		cancel()
	}

}
