package main

import (
	"server/core/config"
	"server/core/master"
	"server/core/master/database"
	"server/core/slave"
)

func main() {
	config.LoadConfig()
	database.Serve()
	go slave.BotServer()
	master.Serve()
}
