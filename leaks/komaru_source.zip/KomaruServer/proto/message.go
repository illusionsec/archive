package proto

type Message struct {
	Message   []byte
	Signature []byte
}
