package proto

import (
	"crypto/rsa"
	"net"
)

type Server struct {
	listener    *net.TCPListener
	Connections map[*Serverconn]int
}

type Serverconn struct {
	conn    net.Conn
	pubkey  rsa.PublicKey
	private *rsa.PrivateKey
}
