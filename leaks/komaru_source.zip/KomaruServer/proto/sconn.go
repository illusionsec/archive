package proto

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"strings"
)

func (c *Serverconn) Read(buf int) ([]byte, error) {
	bu := make([]byte, c.pubkey.N.BitLen()+20+buf)
	_, err := c.conn.Read(bu)
	if err != nil {
		return nil, err
	}
	Text, err := c.layerDecrypt(bu)
	if err != nil {
		return nil, err
	}
	var msg Message
	err = json.Unmarshal([]byte(strings.ReplaceAll(string(Text), "\x00", "")), &msg)
	if err != nil {
		return nil, err
	}
	rawsig, err := base64.RawStdEncoding.DecodeString(string(msg.Signature))
	if err != nil {
		return nil, err
	}
	rawmsg, err := base64.RawStdEncoding.DecodeString(string(msg.Message))
	if err != nil {
		return nil, err
	}
	if err := c.VerifySig(rawsig, rawmsg); err != nil {
		return nil, err
	}
	return rsa.DecryptOAEP(sha256.New(), rand.Reader, c.private, rawmsg, nil)
}

func (c *Serverconn) Write(buf []byte) (int, error) {
	m, err := rsa.EncryptOAEP(sha256.New(), rand.Reader, &c.pubkey, buf, nil)
	if err != nil {
		return 0, err
	}
	sig, err := c.Sign(m)
	if err != nil {
		return 0, err
	}
	msg := Message{
		Message:   []byte(base64.RawStdEncoding.EncodeToString(m)),
		Signature: []byte(base64.RawStdEncoding.EncodeToString(sig)),
	}
	Value, err := json.Marshal(&msg)
	if err != nil {
		return 0, err
	}
	embed, err := c.layerEncrypt(Value)
	if err != nil {
		return 0, err
	}
	return c.conn.Write(embed)
}

func (c *Serverconn) Close() {
	c.conn.Close()
	c = nil
}
