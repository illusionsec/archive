package proto

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
)

func (c *Conn) VerifySig(sig, msg []byte) error {
	l := sha256.New()
	if _, err := l.Write(msg); err != nil {
		return err
	}
	return rsa.VerifyPKCS1v15(c.key, crypto.SHA256, l.Sum(nil), sig)
}

func fingerprint(p *rsa.PublicKey) ([]byte, error) {
	sb := sha256.New()
	if _, err := sb.Write([]byte(p.N.Bytes())); err != nil {
		return nil, err
	}
	return sb.Sum(nil), nil
}

func (c *Serverconn) Sign(msg []byte) ([]byte, error) {
	l := sha256.New()
	if _, err := l.Write(msg); err != nil {
		return nil, err
	}
	return rsa.SignPKCS1v15(rand.Reader, c.private, crypto.SHA256, l.Sum(nil))
}

func (c *Serverconn) VerifySig(sig, msg []byte) error {
	l := sha256.New()
	if _, err := l.Write(msg); err != nil {
		return err
	}
	return rsa.VerifyPKCS1v15(&c.pubkey, crypto.SHA256, l.Sum(nil), sig)
}
