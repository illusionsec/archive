package proto

import (
	"crypto/rsa"
	"encoding/base64"
	"encoding/json"
	"strings"
)

func (c *Conn) getpub(data string) (*rsa.PublicKey, error) {
	raw, err := base64.RawStdEncoding.DecodeString(strings.ReplaceAll(data, "\x00", ""))
	if err != nil {
		return nil, err
	}
	var Key rsa.PublicKey
	err = json.Unmarshal(raw, &Key)
	if err != nil {
		return nil, err
	}
	return &Key, nil

}

func (c *Conn) getpriv(data string) (*rsa.PrivateKey, error) {
	raw, err := base64.RawStdEncoding.DecodeString(strings.ReplaceAll(data, "\x00", ""))
	if err != nil {
		return nil, err
	}
	var Key rsa.PrivateKey
	err = json.Unmarshal(raw, &Key)
	if err != nil {
		return nil, err
	}
	return &Key, nil

}
