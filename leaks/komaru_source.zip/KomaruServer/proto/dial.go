package proto

import "net"

func Dial(network string, raddr *net.TCPAddr) (*Conn, error) {
	conn, err := net.DialTCP(network, nil, raddr)
	if err != nil {
		return nil, err
	}
	return Upgrade(conn)
}

func Upgrade(conn *net.TCPConn) (*Conn, error) {
	buf := make([]byte, 5064)
	_, err := conn.Write([]byte{1, 0, 0, 1, 1, 2, 0, 3, 0})
	if err != nil {
		conn.Close()
		return nil, err
	}
	l, err := conn.Read(buf)
	if err != nil {
		return nil, err
	}
	c := &Conn{
		socket: conn,
	}
	c.key, err = c.getpub(string(buf[:l]))
	if err != nil {
		return nil, err
	}
	_, err = conn.Write([]byte{1, 1, 0, 1, 1, 2, 0, 3, 0})
	if err != nil {
		conn.Close()
		return nil, err
	}
	buf = make([]byte, 5064)
	l, err = conn.Read(buf)
	if err != nil {
		return nil, err
	}
	c.private, err = c.getpriv(string(buf[:l]))
	if err != nil {
		return nil, err
	}
	return c, nil
}
