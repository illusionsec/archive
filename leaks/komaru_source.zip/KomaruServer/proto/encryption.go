package proto

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"encoding/base64"
	"encoding/json"
	"io"
	"strings"
)

func (c *Conn) layerDecrypt(buf []byte) ([]byte, error) {
	out := make([]byte, 0)
	cText, err := base64.RawStdEncoding.DecodeString(strings.ReplaceAll(string(buf), "\x00", ""))
	if err != nil {
		return nil, err
	}
	fprint, err := fingerprint(c.key)
	if err != nil {
		return nil, err
	}
	block, err := aes.NewCipher(fprint)
	if err != nil {
		return nil, err
	}
	vector, ctext := cText[:aes.BlockSize], cText[aes.BlockSize:]
	stream := cipher.NewCFBDecrypter(block, vector)
	stream.XORKeyStream(out, ctext)
	return out, nil
}
func (c *Serverconn) layerDecrypt(buf []byte) ([]byte, error) {
	cText, err := base64.RawStdEncoding.DecodeString(strings.ReplaceAll(string(buf), "\x00", ""))
	if err != nil {
		return nil, err
	}
	fprint, err := fingerprint(&c.pubkey)
	if err != nil {
		return nil, err
	}
	block, err := aes.NewCipher(fprint)
	if err != nil {
		return nil, err
	}
	vector, ctext := cText[:aes.BlockSize], cText[aes.BlockSize:]
	stream := cipher.NewCFBDecrypter(block, vector)
	out := make([]byte, len(ctext)+1)
	stream.XORKeyStream(out, ctext)
	return out, nil
}

func (c *Serverconn) layerEncrypt(m []byte) ([]byte, error) {
	fingerprint, err := fingerprint(&c.pubkey)

	if err != nil {
		return nil, err
	}
	cBlock, err := aes.NewCipher(fingerprint)
	if err != nil {
		return nil, err
	}

	cText := make([]byte, aes.BlockSize+len(m))
	iVector := cText[:aes.BlockSize]

	if _, err := io.ReadFull(rand.Reader, iVector); err != nil {
		return nil, err
	}

	stream := cipher.NewCFBEncrypter(cBlock, iVector)
	stream.XORKeyStream(cText[aes.BlockSize:], m)
	return []byte(base64.RawStdEncoding.EncodeToString(cText)), nil
}

func (c *Conn) layerEncrypt(m []byte) ([]byte, error) {
	fingerprint, err := fingerprint(c.key)

	if err != nil {
		return nil, err
	}
	cBlock, err := aes.NewCipher(fingerprint)
	if err != nil {
		return nil, err
	}

	cText := make([]byte, aes.BlockSize+len(m))
	iVector := cText[:aes.BlockSize]

	if _, err := io.ReadFull(rand.Reader, iVector); err != nil {
		return nil, err
	}

	stream := cipher.NewCFBEncrypter(cBlock, iVector)
	stream.XORKeyStream(cText[aes.BlockSize:], m)
	return []byte(base64.RawStdEncoding.EncodeToString(cText)), nil
}

func publicKeyString(public *rsa.PublicKey) (string, error) {

	Interface, err := json.Marshal(public)

	if err != nil {
		return "", err
	}

	return base64.RawStdEncoding.EncodeToString(Interface), nil
}

func privateKeyString(public *rsa.PrivateKey) (string, error) {

	Interface, err := json.Marshal(public)
	if err != nil {
		return "", err
	}

	return base64.RawStdEncoding.EncodeToString(Interface), nil
}
