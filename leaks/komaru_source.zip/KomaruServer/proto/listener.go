package proto

import (
	"bytes"
	"crypto/rand"
	"crypto/rsa"
	"net"
)

func Listen(network, addr string) (*Server, error) {
	taddr, _ := net.ResolveTCPAddr(network, addr)
	listener, err := net.ListenTCP(network, taddr)
	if err != nil {
		return nil, err
	}
	s := &Server{
		listener:    listener,
		Connections: make(map[*Serverconn]int),
	}
	return s, nil
}

func (s *Server) Accept() (*Serverconn, error) {
	conn, err := s.listener.Accept()
	if err != nil {
		return nil, err
	}
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return nil, err
	}
	c := &Serverconn{
		conn:    conn,
		private: key,
		pubkey:  key.PublicKey,
	}
	buf := make([]byte, 9)
	_, err = conn.Read(buf)
	if err != nil {
		return nil, err
	}
	if bytes.Equal(buf[0:5], []byte{1, 0, 0, 1, 1}) {
		pubkey, err := publicKeyString(&c.pubkey)
		if err != nil {
			conn.Close()
			return nil, err
		}
		c.conn.Write([]byte(pubkey))
	}
	buf = make([]byte, 9)
	_, err = conn.Read(buf)
	if err != nil {
		return nil, err
	}
	if bytes.Equal(buf[0:5], []byte{1, 1, 0, 1, 1}) {
		pubkey, err := privateKeyString(c.private)
		if err != nil {
			conn.Close()
			return nil, err
		}
		c.conn.Write([]byte(pubkey))
	}
	s.Connections[c] += 1
	return c, nil
}
