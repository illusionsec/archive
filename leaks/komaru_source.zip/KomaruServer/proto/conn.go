package proto

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"net"
)

type Conn struct {
	socket  *net.TCPConn
	key     *rsa.PublicKey
	private *rsa.PrivateKey
}

func (c *Conn) Read(buf int) ([]byte, error) {
	bu := make([]byte, c.key.N.BitLen()+20+buf)
	_, err := c.socket.Read(bu)
	if err != nil {
		return nil, err
	}
	Text, err := c.layerDecrypt(bu)
	if err != nil {
		return nil, err
	}
	var msg Message
	err = json.Unmarshal(Text, &msg)
	if err != nil {
		return nil, err
	}
	rawsig, err := base64.RawStdEncoding.DecodeString(string(msg.Signature))
	if err != nil {
		return nil, err
	}
	rawmsg, err := base64.RawStdEncoding.DecodeString(string(msg.Message))
	if err != nil {
		return nil, err
	}
	if err := c.VerifySig(rawsig, rawmsg); err != nil {
		return nil, err
	}
	return rsa.DecryptOAEP(sha256.New(), rand.Reader, c.private, rawmsg, nil)
}
