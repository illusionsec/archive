package config

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"log"
	"os"
)

func LoadConfig() {
	writeConfig()
	file, err := ioutil.ReadFile("config.json")
	if err != nil {
		log.Println("Failed to read config.json.")
		return
	}
	err = json.NewDecoder(bytes.NewReader(file)).Decode(&Config)
	if err != nil {
		log.Println("Failed to decode config.json.")
		return
	}
	log.Println("Successfully loaded config.")
}

func writeConfig() {
	if _, err := os.Stat("config.json"); os.IsNotExist(err) {
		cfg := config{
			MasterPort:    1337,
			SlavePort:     69,
			SshKey:        "id_rsa",
			MysqlAddress:  "localhost:3306",
			MysqlUser:     "root",
			MysqlPassword: "",
			MysqlDatabase: "cat",
		}
		file, _ := json.MarshalIndent(cfg, "", " ")
		_ = ioutil.WriteFile("config.json", file, 0644)
	}
}
