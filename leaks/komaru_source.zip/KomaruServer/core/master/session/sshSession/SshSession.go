package sshSession

import (
	"io"
	"net"

	"golang.org/x/crypto/ssh"
)

type SecureShellSession struct {
	channel ssh.Channel
	netConn net.Conn
	sshConn ssh.ServerConn
}

func NewSecureShellSession(channel ssh.Channel, netConn net.Conn, conn ssh.ServerConn) *SecureShellSession {
	return &SecureShellSession{
		channel: channel,
		netConn: netConn,
		sshConn: conn,
	}
}

func (session SecureShellSession) Write(data []byte) error {
	_, err := session.channel.Write(data)
	if err != nil {
		return err
	}
	return nil
}

func (session SecureShellSession) Read(data []byte) error {
	_, err := session.channel.Read(data)
	if err != nil {
		return err
	}
	return nil
}

func (session SecureShellSession) Close() error {
	err := session.channel.Close()
	if err != nil {
		return err
	}
	return nil
}

func (session SecureShellSession) CloseWrite() error {
	err := session.channel.CloseWrite()
	if err != nil {
		return err
	}
	return nil
}

func (session SecureShellSession) GetReadWriter() io.ReadWriter {
	return session.channel.Stderr()
}
func (session SecureShellSession) GetChannel() ssh.Channel {
	return session.channel
}

func (session SecureShellSession) GetConnection() ssh.ServerConn {
	return session.sshConn
}

func (session SecureShellSession) GetNetConn() net.Conn {
	return session.netConn
}
