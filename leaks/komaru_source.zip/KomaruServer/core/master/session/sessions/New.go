package sessions

import (
	"crypto/rand"
	"encoding/binary"
	"errors"
)

func New(session *Session) error {
	if count(session.Name) > session.Sessions {
		return errors.New("Session limit reached")
	}
	buf := make([]byte, 8)
	for {
		if _, err := rand.Read(buf); err != nil {
			return err
		}

		id := binary.BigEndian.Uint64(buf)
		if _, ok := sessions[id]; !ok {
			session.ID = id
			sessions[id] = session
			return nil
		}
	}
	return nil
}
