package sessions

import (
	"fmt"
	"server/core/master/database"
	"server/core/master/session/sshSession"
	"server/core/master/utility/terminal"
	"time"
)

var (
	// sessions - Sessions map, where all the online sessions are saved.
	sessions = make(map[uint64]*Session)
)

type ssess struct {
}

type Session struct {
	ID uint64
	*sshSession.SecureShellSession
	*database.User
	Created  time.Time
	Terminal *terminal.Terminal
}

func Get(name string) *Session {
	for _, s := range sessions {
		if s.User.Name == name {
			return s
		}
	}
	return nil
}

//Count - Returns the amount of online users. A little obvious, isn't it?
func Count() int {
	return len(sessions)
}

// Clone - Returns the users in a slice
func Clone() []Session {
	var list []Session
	for _, session := range sessions {
		list = append(list, *session)
	}
	return list
}

// Print - Prints in the console.
func (session *Session) Print(a ...interface{}) {
	err := session.Write([]byte(fmt.Sprint(a...)))
	if err != nil {
		return
	}
}

// Println - Prints in the console using a new line.
func (session *Session) Println(a ...interface{}) {
	err := session.Write([]byte(fmt.Sprint(a...) + "\r\n"))
	if err != nil {
		return
	}
}

// PrintTitle - Changes the title.
func (session *Session) PrintTitle(a ...interface{}) error {
	err := session.Write([]byte("\033]0;" + fmt.Sprint(a...) + "\007"))
	if err != nil {
		return err
	}
	return nil
}

// EscClear - Returns the ESC code for clear screen.
func (session *Session) Clear() error {
	err := session.Write([]byte("\033c"))
	if err != nil {
		return err
	}
	return nil
}

// Read - Reads a line from the console.
func (session *Session) Read(prompt string) string {
	term := terminal.NewTerminal(session.GetChannel(), prompt)
	line, err := term.ReadLine()
	if err != nil {
		return ""
	}
	return line
}
