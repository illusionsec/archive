package color

import "strconv"

func Term_rgb(red int, green int, blue int) string {

	var r = red
	var g = green
	var b = blue

	return "\033[38;2;" + strconv.Itoa(r) + ";" + strconv.Itoa(g) + ";" + strconv.Itoa(b) + "m"

}
