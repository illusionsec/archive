package color

import (
	"server/core/dependencies/gradient"
	"strconv"
	"strings"
)

func PresetGradient(gradient gradient.Gradient, s string) string {
	return gradient.Sprint(s)
}

func PresetGradientMulti(gradient gradient.Gradient, s string, c ...string) string {
	return gradient.Mutline(s)
}

func Gradient(s string, c ...string) string {
	g, err := gradient.NewGradient(c...)
	// if the passed colors are not valid an error is returned
	// supports all css valid colors
	if err != nil {
	}
	return g.Sprint(s)
}

func MultilineGradient(s string, c ...string) string {
	g, err := gradient.NewGradient(c...)
	// if the passed colors are not valid an error is returned
	// supports all css valid colors
	if err != nil {
	}
	return g.Mutline(s)
}

type Color struct {
	Red   int
	Green int
	Blue  int
}

func OtherGradient(StartColor Color, EndColor Color, text string, blacklistedChars []string, blacklistedCharColor string) string {

	/*
		Don't ask me why but without the conversion this won't work
	*/

	text = strings.ReplaceAll(text, "[2K[1m", "")

	var changeR = (EndColor.Red - StartColor.Red) / len(text)
	var changeG = (EndColor.Green - StartColor.Green) / len(text)
	var changeB = (EndColor.Blue - StartColor.Blue) / len(text)

	var finalText string

	var r = StartColor.Red
	var g = StartColor.Green
	var b = StartColor.Blue

	for _, c := range text {
		if ContainsChar(string(c), blacklistedChars) {
			finalText += "\033[39m" + string(c)
		} else {
			finalText += "\033[38;2;" + strconv.Itoa(r) + ";" + strconv.Itoa(g) + ";" + strconv.Itoa(b) + "m" + string(c) + "\033[0m"
			r += changeR
			g += changeG
			b += changeB
		}
	}
	return finalText
}

func ContainsChar(char string, blacklistedChars []string) bool {
	for _, blacklisted := range blacklistedChars {
		if char == blacklisted {
			return true
		}
	}
	return false
}
