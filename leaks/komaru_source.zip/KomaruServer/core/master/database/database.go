package database

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"log"
	"server/core/config"
)

type Database struct {
	Instance *sql.DB
}

var DatabaseConnection Database

func Serve() {
	db, err := sql.Open("mysql", fmt.Sprintf("%s:%s@tcp(%s)/%s",
		config.Config.MysqlUser,
		config.Config.MysqlPassword,
		config.Config.MysqlAddress,
		config.Config.MysqlDatabase))
	if err != nil {
		log.Println("Failed to open database connection.")
		return
	}
	DatabaseConnection = Database{db}
	log.Println("Connected to the database.")
}
