package database

import (
	"bytes"
	"encoding/hex"
	"errors"
	"fmt"
	"log"
	"server/core/master/encryption"
)

type User struct {
	Id       int
	Name     string
	Password string
	Pubkey   []byte

	Admin bool

	Devices  int
	Time     int
	Cooldown int

	Expiry   int
	Sessions int

	StartColor string
	EndColor   string

	Banned bool
}

func (database Database) VerifyCredentials(name, password string) error {
	rows, err := database.Instance.Query("SELECT password FROM users WHERE name=?", name)
	if err != nil {
		log.Println("Failed to verify the credentials.", err)
		return err
	}
	if rows.Next() {
		var passwordFromDB string
		rows.Scan(&passwordFromDB)
		if encryption.Compare(password, passwordFromDB) {
			return nil
		}
	}
	return errors.New("invalid credentials")
}

func (database Database) VerifyPubKey(name string, pubkey []byte) error {
	rows, err := database.Instance.Query("SELECT pubkey FROM users WHERE name=?", name)
	if err != nil {
		log.Println("Failed to verify the credentials.", err)
		return err
	}
	if rows.Next() {
		var key string
		rows.Scan(&key)
		if key == "nil" {
			fmt.Println("key unset")
			return errors.New("key unset")
		}
		hexkey, err := hex.DecodeString(key)
		if err != nil {
			return err
		}
		if bytes.Equal(hexkey, pubkey) {
			return nil
		}
	}
	return errors.New("invalid credentials")
}

func (database Database) GetInfoByName(name string) *User {
	rows, err := database.Instance.Query("SELECT * FROM users WHERE name=?", name)
	if err != nil {
		return nil
	}
	if rows.Next() {
		var user User
		err := rows.Scan(&user.Id, &user.Name, &user.Password, &user.Pubkey, &user.Admin, &user.Devices, &user.Time, &user.Cooldown, &user.Expiry, &user.Sessions, &user.StartColor, &user.EndColor, &user.Banned)
		if err != nil {
			return nil
		}
		return &user
	}
	return nil
}

func (database Database) ExistsByName(name string) bool {
	rows, err := database.Instance.Query("SELECT id FROm users WHERE name = ?", name)
	if err != nil {
		return false
	}
	return rows.Next()
}

func (database Database) ExistsById(id int) bool {
	rows, err := database.Instance.Query("SELECT id FROm users WHERE id = ?", id)
	if err != nil {
		return false
	}
	return rows.Next()
}

func (db *Database) SetUser(user *User) (User, error) {
	if db.ExistsById(user.Id) {
		_, err := db.Instance.Query("UPDATE `users` SET `name`=?, `password`=?, `pubkey`=?, `admin`=?, `devices`=?, `time`=?, `cooldown`=?, `expiry`=?, `startColor`=?, `endColor`=?, `banned`=? WHERE id=?", user.Name, user.Password, user.Pubkey, user.Admin, user.Devices, user.Time, user.Cooldown, user.Expiry, user.StartColor, user.EndColor, &user.Banned, user.Id)
		if err != nil {
			return User{}, err
		}
		return User{
			Id:         user.Id,
			Name:       user.Name,
			Password:   user.Password,
			Admin:      user.Admin,
			Devices:    user.Devices,
			Time:       user.Time,
			Cooldown:   user.Cooldown,
			Expiry:     user.Expiry,
			StartColor: user.StartColor,
			EndColor:   user.EndColor,
			Banned:     user.Banned,
		}, nil
	}
	return User{}, errors.New("user not found")
}

func (db *Database) AddUser(user User) error {
	if db.ExistsById(user.Id) {
		return errors.New("user already exists")
	}
	_, err := db.Instance.Query("INSERT INTO `users`(`name`, `password`, `admin`, `devices`, `time`, `cooldown`, `expiry`, `startColor`, `endColor`, `banned`) VALUES (?,?,?,?,?,?,?,?,?,?)", user.Name, user.Password, user.Admin, user.Devices, user.Time, user.Cooldown, user.Expiry, "", "", false)
	if err != nil {
		fmt.Println(err)
		return err
	}
	return nil
}

func (db *Database) DeleteUser(user User) error {
	if !db.ExistsById(user.Id) {
		return errors.New("user doesn't exist")
	}
	_, err := db.Instance.Query("DELETE FROM users WHERE name=?", user.Name)
	if err != nil {
		return err
	}
	return nil
}
