package master

import (
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"server/core/config"
	"server/core/master/attack"
	"server/core/master/command/registry"
	"server/core/master/database"
	"server/core/master/session/sshSession"
	"strconv"

	"golang.org/x/crypto/ssh"
)

var sshConfig *ssh.ServerConfig

func Serve() {
	registry.Init()
	attack.Init()

	sshConfig = &ssh.ServerConfig{
		PublicKeyCallback: func(conn ssh.ConnMetadata, key ssh.PublicKey) (*ssh.Permissions, error) {
			if err := database.DatabaseConnection.VerifyPubKey(conn.User(), key.Marshal()); err == nil {
				return &ssh.Permissions{Extensions: map[string]string{"pub-key": string(key.Marshal()), "authorized": "true"}}, nil
			}
			return &ssh.Permissions{Extensions: map[string]string{"pub-key": string(key.Marshal()), "authorized": "false"}}, nil
		},
		PasswordCallback: func(conn ssh.ConnMetadata, password []byte) (*ssh.Permissions, error) {
			return &ssh.Permissions{}, database.DatabaseConnection.VerifyCredentials(conn.User(), string(password))
		},
	}
	sshConfig.AddHostKey(parseKey("id_rsa"))

	listener, err := net.Listen("tcp", fmt.Sprintf(":%d", config.Config.MasterPort))
	if err != nil {
		log.Panic(err)
	}
	log.Println("Master server started on port", strconv.Itoa(config.Config.MasterPort)+".")
	for {
		accept, err := listener.Accept()
		go handleConnection(err, accept)
	}

}

func handleConnection(err error, conn net.Conn) {
	if err != nil {
		return
	}
	sshConn, channel, reqs, err := ssh.NewServerConn(conn, sshConfig)
	if err != nil {
		return
	}
	go ssh.DiscardRequests(reqs)
	for newChannel := range channel {
		go handleChannel(newChannel, *sshConn, conn)
	}
}

func handleChannel(newChannel ssh.NewChannel, conn ssh.ServerConn, netConn net.Conn) {
	channel, _, err := newChannel.Accept()
	if err != nil {
		fmt.Println(err)
		return
	}
	Master{
		SecureShellSession: sshSession.NewSecureShellSession(channel, netConn, conn),
		Channel:            channel,
	}.Handle()
}

func parseKey(name string) ssh.Signer {
	keyBytes, err := ioutil.ReadFile(name)
	if err != nil {
		log.Fatal("Failed to load the ssh key")
		return nil
	}
	parsedPrivateKey, err := ssh.ParsePrivateKey(keyBytes)
	if err != nil {
		log.Fatal("Failed to parse the ssh key")
		return nil
	}
	log.Println("Key", strconv.Quote(name), "has been loaded.")
	return parsedPrivateKey
}
