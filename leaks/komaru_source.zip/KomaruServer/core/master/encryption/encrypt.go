package encryption

import (
	"crypto/aes"
	"crypto/cipher"
	cryptorand "crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"io"
	"log"
	"math/rand"
	"server/core/master/utility/random"

	"golang.org/x/crypto/bcrypt"
)

func Hash(data string) string {
	akey := AesKey()
	a, err := aes.NewCipher([]byte(akey))
	if err != nil {
		log.Println("encrypt:21", err.Error())
		return ""
	}
	gcm, err := cipher.NewGCM(a)
	if err != nil {
		log.Println("encrypt:26", err.Error())
		return ""
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err = io.ReadFull(cryptorand.Reader, nonce); err != nil {
		log.Println("encrypt:31", err.Error())
		return ""
	}
	e1 := gcm.Seal(nonce, nonce, []byte(data), nil)
	in, err := cryptorand.Prime(cryptorand.Reader, rand.Intn(16))
	if err != nil {
		log.Println("encrypt:37", err.Error())
		return ""
	}

	xkey := random.String(int(in.Int64()))
	e2 := ""
	for i := 0; i < len(string(e1)); i++ {
		e2 += string(string(e1)[i] ^ xkey[i%len(xkey)])
	}
	e3 := hex.EncodeToString(sha256.New().Sum([]byte(e2)))
	e4, err := bcrypt.GenerateFromPassword([]byte(e3), bcrypt.MinCost)
	if err != nil {
		log.Println("encrypt:49", err.Error())
		return ""
	}
	return hex.EncodeToString([]byte(xkey + ":" + string(e4) + ":" + akey + ":" + string(nonce)))
}

func AesKey() string {
	key := rand.Intn(2)
	switch key {
	case 0:
		return random.String(16)
	case 1:
		return random.String(24)
	case 2:
		return random.String(32)
	default:
		return random.String(24)
	}
}
