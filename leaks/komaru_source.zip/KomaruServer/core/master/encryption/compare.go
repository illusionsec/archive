package encryption

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha256"
	"encoding/hex"
	"log"
	"strings"

	"golang.org/x/crypto/bcrypt"
)

func Compare(original, comparing string) bool {
	decoded, err := hex.DecodeString(comparing)
	if err != nil {
		log.Println("compare:17", err.Error())
		return false
	}
	data := strings.Split(string(decoded), ":")
	if len(data) < 4 {
		return false
	}
	a, err := aes.NewCipher([]byte(data[2]))
	if err != nil {
		log.Println("compare:27", err.Error())
		return false
	}
	gcm, err := cipher.NewGCM(a)
	if err != nil {
		log.Println("compare:32", err.Error())
		return false
	}
	nonce := []byte(data[3])
	e1 := gcm.Seal(nonce, nonce, []byte(original), nil)
	e2 := ""
	for i := 0; i < len(string(e1)); i++ {
		e2 += string(string(e1)[i] ^ data[0][i%len(data[0])])
	}
	e3 := hex.EncodeToString(sha256.New().Sum([]byte(e2)))
	err = bcrypt.CompareHashAndPassword([]byte(strings.Split(string(decoded), ":")[1]), []byte(e3))
	if err != nil {
		log.Println("compare:44", err.Error())
		return false
	}
	return err == nil
}
