package attack

type Method struct {
	Id          int
	Name        string
	Type        int
	Description string
	//Flags []uint8
}

var (
	// sessions - Sessions map, where all the online sessions are saved.
	methods = make(map[string]*Method)
)

func New(method *Method) {
	if _, exists := methods[method.Name]; exists {
		return
	}
	methods[method.Name] = method
	return
}

func Init() {
	New(&Method{
		Id:          0,
		Name:        "udp",
		Description: "udp flood",
	})
	New(&Method{
		Id:          1,
		Name:        "udphex",
		Description: "udp flood with hex strings",
	})
	New(&Method{
		Id:          2,
		Name:        "syn",
		Description: "syn flood",
	})
	New(&Method{
		Id:          3,
		Name:        "ack",
		Description: "ack flood",
	})
	New(&Method{
		Id:          4,
		Name:        "handshake",
		Type:        1,
		Description: "tcp 3-way handshake",
	})
	New(&Method{
		Id:          5,
		Name:        "flood",
		Description: "http(s) flood",
	})
	New(&Method{
		Id:          6,
		Name:        "socket",
		Description: "http socket flood",
	})
}

func Get(name string) *Method {
	method, exists := methods[name]
	if !exists {
		return nil
	}
	return method
}

func Clone() []*Method {
	var list []*Method
	for _, method := range methods {
		list = append(list, method)
	}
	return list
}
