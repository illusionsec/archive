package admin

import (
	"log"
	"server/core/master/session/sessions"
	"strings"
)

func Register() {
	log.Println("Admin commands registered.")
}

func retroGradient(text string, blacklist string, charColor string, session *sessions.Session) string {
	return strings.ReplaceAll(text, blacklist, charColor+blacklist)
}
