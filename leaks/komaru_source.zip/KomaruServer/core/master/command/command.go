package command

import (
	"log"
	"server/core/master/database"
	"server/core/master/session/sessions"
)

var (
	// commands - Commands map, where all the commands are saved.
	commands = make(map[string]*Command)
)

// Command - Structure of the command
type Command struct {
	Aliases     []string
	Description string
	Admin       bool
	Executor    func(args []string, session *sessions.Session)
}

// Register - Registers the command
func Register(command *Command) {
	if _, exists := commands[command.Aliases[0]]; exists {
		log.Fatal("command already exists")
	}
	commands[command.Aliases[0]] = command
}

// Get - Gets the command from the map
func Get(alias string) *Command {
	for _, command := range commands {
		for _, s := range command.Aliases {
			if alias == s {
				return command
			}
		}
	}
	return nil
}

// Clone - Gets all commands in a slice
func Clone() []*Command {
	var commandSlice []*Command
	for _, cmd := range commands {
		commandSlice = append(commandSlice, cmd)
	}
	return commandSlice
}

// HasPermission - Checks if the user has the permissions to run the command if not a simple message will occur.
func (command *Command) HasPermission(user *database.User) bool {
	if command.Admin && !user.Admin {
		return false
	}
	return true
}
