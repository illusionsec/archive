package all

import (
	"server/core/master/command"
	"server/core/master/event"
	"server/core/master/session/sessions"
)

func init() {
	command.Register(&command.Command{
		Aliases:     []string{"test"},
		Description: "xd",
		Admin:       false,
		Executor: func(args []string, session *sessions.Session) {
			session.Println("\033[91mcatto's arrow detector")
			event.EventHandler.On("key.up", func() error {
				session.Println("-> arrow up")
				return nil
			})
			event.EventHandler.On("key.down", func() error {
				session.Println("-> arrow down")
				return nil
			})
			event.EventHandler.On("key.left", func() error {
				session.Println("-> arrow left")
				return nil
			})
			event.EventHandler.On("key.right", func() error {
				session.Println("-> arrow right")
				return nil
			})
			session.Read("")
			event.EventHandler.Remove("key.up")
			event.EventHandler.Remove("key.down")
			event.EventHandler.Remove("key.left")
			event.EventHandler.Remove("key.right")
		},
	})
}
