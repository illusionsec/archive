package all

import (
	"fmt"
	"server/core/master/command"
	"server/core/master/database"
	"server/core/master/encryption"
	"server/core/master/session/sessions"
)

func init() {
	command.Register(&command.Command{
		Aliases:     []string{"passwd", "changepass", "passchange"},
		Description: "Changes the password.",
		Admin:       false,
		Executor: func(args []string, session *sessions.Session) {
			var tries = 0
			pass := session.Read("New Password: ")
			for tries <= 3 {
				repeat := session.Read("Repeat Password: ")
				if pass == repeat {
					session.User.Password = encryption.Hash(pass)
					_, err := database.DatabaseConnection.SetUser(session.User)
					if err != nil {
						session.Println(err.Error())
						return
					}
					session.Println("Password successfully changed.")
					return
				}
				if 3-tries == 1 {
					session.Println(fmt.Sprintf("Repeated password is not the same. There is %d try left.", 3-tries))
				} else {
					session.Println(fmt.Sprintf("Repeated password is not the same. There are %d tries left.", 3-tries))
				}
				tries++
			}

		},
	})
}
