package all

import (
	"server/core/master/color"
	"server/core/master/command"
	"server/core/master/session/sessions"
	"strings"
)

func init() {
	command.Register(&command.Command{
		Aliases:     []string{"help", "?"},
		Description: "Lists all commands",
		Admin:       false,
		Executor: func(args []string, session *sessions.Session) {
			session.Println()
			session.Println(" \033[97mudpflood\033[91m: \033[97mudp flood")
			session.Println(" \033[97mflood\033[91m: \033[97mhttp/2.0 flood")
			session.Println()
		},
	})
}

func retroGradient(text string, blacklist string, charColor string, session sessions.Session) string {
	return strings.ReplaceAll(color.MultilineGradient(text, session.User.StartColor, session.User.EndColor), blacklist, charColor+blacklist)
}
