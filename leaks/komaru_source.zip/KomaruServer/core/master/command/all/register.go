package all

import "log"

func Register() {
	log.Println("User commands registered.")
}
