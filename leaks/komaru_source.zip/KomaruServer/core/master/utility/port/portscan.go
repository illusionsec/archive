package portScan

import (
	"fmt"
	"net"
	"sync"
	"time"
)

func PortScan(start int, end int, ip string) []int {
	var ports []int
	wg := sync.WaitGroup{}
	for i := start; i <= end; i++ {
		targetHostWithPort := fmt.Sprintf("%s:%d", ip, i)
		wg.Add(1)
		i := i
		go func() {
			defer wg.Done()
			if isTcpPortOpen(targetHostWithPort, 1) {
				ports = append(ports, i)
			}
		}()
	}
	wg.Wait()
	return ports
}

func isTcpPortOpen(targetHostWithPort string, portTimeout int) bool {
	_, err := net.DialTimeout("tcp", targetHostWithPort, time.Second*time.Duration(portTimeout))
	if err == nil {
		return true
	}
	return false
}
