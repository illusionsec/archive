package format

import "strings"

func ClientName(original string) string {
	if strings.HasSuffix(original, "KiTTY") {
		return "KiTTY"
	}
	if strings.Contains(original, "PuTTY") {
		return "PuTTY"
	}
	if strings.Contains(original, "OpenSSH") {
		return "OpenSSH"
	}
	return "UNK"
}
