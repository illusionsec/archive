package event

import "server/core/dependencies/event"

var (
	EventHandler = event.New()
)
