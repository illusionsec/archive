package slave

var (
	VERIFY_MESSAGE string = "0x00"
	PING_MESSAGE   string = "0x01"
	PONG_MESSAGE   string = "0x02"
)
